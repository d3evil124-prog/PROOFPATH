// @ts-nocheck
// Preserved from the supplied archive for the legacy compatibility adapter only.
// The live ProofPath UI uses authenticated tRPC records and does not load these fixtures.
import type {
  AssessmentSummary,
  ChangeEvent,
  EvidenceCitation,
  JobPosting,
  MonitoringStatus,
  Repository,
  SkillAssessment,
} from "@/types/domain";

export const demoJob: JobPosting = {
  id: "job-se-intern-01",
  title: "Software Engineering Intern",
  company: "Northstar Labs",
  sourceUrl:
    "https://careers.northstarlabs.example/roles/software-engineering-intern",
  retrievedAt: "Oct 14, 2026 · 10:42 AM",
  method: "sample",
  requirements: [
    {
      id: "typescript",
      wording:
        "Build maintainable web applications using JavaScript or TypeScript.",
      skill: "TypeScript",
      priority: "Required",
    },
    {
      id: "rest",
      wording: "Design and integrate RESTful APIs for product features.",
      skill: "REST APIs",
      priority: "Required",
    },
    {
      id: "sql",
      wording: "Work with relational databases and write SQL queries.",
      skill: "SQL",
      priority: "Required",
    },
    {
      id: "testing",
      wording: "Write automated tests for reliable application behavior.",
      skill: "Testing",
      priority: "Required",
    },
    {
      id: "ci",
      wording: "Use CI workflows to validate and deliver code changes.",
      skill: "CI workflows",
      priority: "Preferred",
    },
  ],
};
export const demoRepository: Repository = {
  id: "repo-portfolio-api",
  owner: "maya-chen",
  name: "campus-events-api",
  url: "https://github.com/maya-chen/campus-events-api",
  branch: "main",
  visibility: "public",
  access: "connected",
  lastAnalyzedSha: "a81f92c",
  lastAnalyzedAt: "Oct 16, 2026 · 9:14 AM",
};
export const skillAssessments: SkillAssessment[] = [
  {
    requirementId: "typescript",
    status: "demonstrated",
    explanation:
      "Typed request and response models are used across the event routes. The cited implementation is direct evidence in this repository scope.",
    citationIds: ["ev-ts-1"],
    coverage: "2 relevant files inspected",
    lastChanged: "Oct 16, 2026",
  },
  {
    requirementId: "rest",
    status: "demonstrated",
    explanation:
      "The repository defines resource-oriented endpoints with explicit HTTP methods and validation. This supports API implementation in the inspected code.",
    citationIds: ["ev-rest-1"],
    coverage: "3 relevant files inspected",
    lastChanged: "Oct 16, 2026",
  },
  {
    requirementId: "sql",
    status: "partial_or_needs_review",
    explanation:
      "A parameterized query is present, but the inspected scope does not show broader query coverage or database migration practice.",
    citationIds: ["ev-sql-1"],
    coverage: "1 query file inspected",
    lastChanged: "Oct 15, 2026",
  },
  {
    requirementId: "testing",
    status: "partial_or_needs_review",
    explanation:
      "A route test covers the happy path. Error and boundary-case coverage was not found in this inspection.",
    citationIds: ["ev-test-1"],
    coverage: "1 test file inspected",
    lastChanged: "Oct 16, 2026",
  },
  {
    requirementId: "ci",
    status: "not_demonstrated_in_analyzed_scope",
    explanation:
      "No CI workflow file was present in the bounded files inspected. This is a scope observation, not evidence that the skill is absent.",
    citationIds: [],
    coverage: "Workflow configuration not found in inspected scope",
    lastChanged: "Oct 14, 2026",
  },
];
export const citations: EvidenceCitation[] = [
  {
    id: "ev-ts-1",
    requirementId: "typescript",
    repositoryId: demoRepository.id,
    path: "src/routes/events.ts",
    lineStart: 12,
    lineEnd: 18,
    commitSha: "a81f92c",
    commitUrl: `${demoRepository.url}/blob/a81f92c/src/routes/events.ts#L12-L18`,
    type: "implementation",
    excerpt: [
      "type EventInput = {",
      "  title: string;",
      "  startsAt: Date;",
      "  capacity: number;",
      "};",
      "",
      "export async function createEvent(input: EventInput) {",
    ],
    explanation:
      "The request handler accepts a typed input model and uses it in the create path.",
    confidence: "high",
    demo: true,
  },
  {
    id: "ev-rest-1",
    requirementId: "rest",
    repositoryId: demoRepository.id,
    path: "src/routes/events.ts",
    lineStart: 31,
    lineEnd: 36,
    commitSha: "a81f92c",
    commitUrl: `${demoRepository.url}/blob/a81f92c/src/routes/events.ts#L31-L36`,
    type: "implementation",
    excerpt: [
      'router.get("/events", listEvents);',
      'router.post("/events", validate(createEventSchema), createEvent);',
      'router.get("/events/:id", getEvent);',
      'router.delete("/events/:id", requireOwner, deleteEvent);',
    ],
    explanation:
      "Resource-oriented routes and method-specific handlers are visible in the cited excerpt.",
    confidence: "high",
    demo: true,
  },
  {
    id: "ev-sql-1",
    requirementId: "sql",
    repositoryId: demoRepository.id,
    path: "src/db/queries.ts",
    lineStart: 44,
    lineEnd: 48,
    commitSha: "d41e6b8",
    commitUrl: `${demoRepository.url}/blob/d41e6b8/src/db/queries.ts#L44-L48`,
    type: "implementation",
    excerpt: [
      "export async function findUpcomingEvents(db: Db, after: Date) {",
      '  return db.query("SELECT id, title, starts_at FROM events WHERE starts_at > ?", [after]);',
      "}",
    ],
    explanation:
      "One parameterized relational query is visible; broader SQL coverage is not established by this excerpt.",
    confidence: "medium",
    demo: true,
  },
  {
    id: "ev-test-1",
    requirementId: "testing",
    repositoryId: demoRepository.id,
    path: "src/routes/events.test.ts",
    lineStart: 22,
    lineEnd: 27,
    commitSha: "a81f92c",
    commitUrl: `${demoRepository.url}/blob/a81f92c/src/routes/events.test.ts#L22-L27`,
    type: "test",
    excerpt: [
      'it("creates an event for a valid payload", async () => {',
      '  const response = await request(app).post("/events").send(validEvent);',
      "  expect(response.status).toBe(201);",
      "  expect(response.body.title).toBe(validEvent.title);",
      "});",
    ],
    explanation:
      "The test exercises a successful create request; error and boundary cases were not found in this inspection.",
    confidence: "medium",
    demo: true,
  },
];
export const assessment: AssessmentSummary = {
  id: "assessment-v4",
  jobId: demoJob.id,
  repositoryId: demoRepository.id,
  commitSha: "a81f92c",
  createdAt: "Oct 16, 2026 · 9:14 AM",
  state: "completed",
  skills: skillAssessments,
  filesInspected: 42,
  filesExcluded: 18,
  testsDiscovered: true,
  testsExecuted: false,
};
export const monitoring: MonitoringStatus = {
  state: "active",
  lastChecked: "Oct 16, 2026 · 9:20 AM",
  latestObservedCommit: "a81f92c",
  lastAssessedCommit: "a81f92c",
  pendingEvents: 0,
};
export const ledger: ChangeEvent[] = [
  {
    id: "event-4",
    timestamp: "Oct 16, 2026 · 9:14 AM",
    sha: "a81f92c",
    message: "Add typed event route validation",
    files: [
      { path: "src/routes/events.ts", change: "modified" },
      { path: "src/routes/events.test.ts", change: "added" },
    ],
    state: "completed",
    affected: ["TypeScript", "REST APIs", "Testing"],
    before: "partial_or_needs_review",
    after: "demonstrated",
    statusChanges: [
      {
        skill: "TypeScript",
        before: "partial_or_needs_review",
        after: "demonstrated",
      },
      {
        skill: "REST APIs",
        before: "partial_or_needs_review",
        after: "demonstrated",
      },
      {
        skill: "Testing",
        before: "not_demonstrated_in_analyzed_scope",
        after: "partial_or_needs_review",
      },
    ],
    evidenceAdded: 3,
    evidenceRemoved: 0,
    explanation:
      "The new typed route implementation and request test added direct evidence for API and TypeScript requirements. The assessment did not change SQL or CI coverage.",
    unchanged: ["SQL", "CI workflows"],
  },
  {
    id: "event-3",
    timestamp: "Oct 15, 2026 · 4:38 PM",
    sha: "d41e6b8",
    message: "Add event query helper",
    files: [{ path: "src/db/queries.ts", change: "modified" }],
    state: "completed",
    affected: ["SQL"],
    before: "not_demonstrated_in_analyzed_scope",
    after: "partial_or_needs_review",
    statusChanges: [
      {
        skill: "SQL",
        before: "not_demonstrated_in_analyzed_scope",
        after: "partial_or_needs_review",
      },
    ],
    evidenceAdded: 1,
    evidenceRemoved: 0,
    explanation:
      "A parameterized query was added, so SQL moved to partial. Broader database work remains outside this evidence.",
    unchanged: ["TypeScript", "REST APIs", "Testing", "CI workflows"],
  },
  {
    id: "event-2",
    timestamp: "Oct 14, 2026 · 11:02 AM",
    sha: "9c72ab1",
    message: "Remove legacy event test fixture",
    files: [{ path: "src/routes/events.test.ts", change: "removed" }],
    state: "completed",
    affected: ["Testing"],
    before: "demonstrated",
    after: "not_demonstrated_in_analyzed_scope",
    statusChanges: [
      {
        skill: "Testing",
        before: "demonstrated",
        after: "not_demonstrated_in_analyzed_scope",
      },
    ],
    evidenceAdded: 0,
    evidenceRemoved: 1,
    explanation:
      "Removing the only test fixture removed the cited test evidence. The status was downgraded for this inspected scope; it does not establish that testing ability is absent.",
    unchanged: ["TypeScript", "REST APIs", "SQL", "CI workflows"],
  },
  {
    id: "event-1",
    timestamp: "Oct 14, 2026 · 10:42 AM",
    sha: "6b3e2af",
    message: "Initial portfolio assessment",
    files: [
      { path: "src/routes/events.ts", change: "added" },
      { path: "src/db/queries.ts", change: "added" },
      { path: "src/routes/events.test.ts", change: "added" },
    ],
    state: "completed",
    affected: ["TypeScript", "REST APIs", "SQL", "Testing", "CI workflows"],
    before: "unable_to_assess",
    after: "partial_or_needs_review",
    statusChanges: [
      {
        skill: "TypeScript",
        before: "unable_to_assess",
        after: "partial_or_needs_review",
      },
      {
        skill: "REST APIs",
        before: "unable_to_assess",
        after: "partial_or_needs_review",
      },
      {
        skill: "SQL",
        before: "unable_to_assess",
        after: "not_demonstrated_in_analyzed_scope",
      },
      {
        skill: "Testing",
        before: "unable_to_assess",
        after: "demonstrated",
      },
      {
        skill: "CI workflows",
        before: "unable_to_assess",
        after: "not_demonstrated_in_analyzed_scope",
      },
    ],
    evidenceAdded: 3,
    evidenceRemoved: 0,
    explanation:
      "The first bounded inspection created a baseline assessment. No CI workflow was found in the inspected scope.",
    unchanged: [],
  },
];
export const demoCandidates = [
  {
    id: "maya-chen",
    name: "Maya Chen",
    role: "Software Engineering Intern",
    repo: "maya-chen/campus-events-api",
    coverage: "2 demonstrated · 2 partial · 1 not in scope",
    updated: "Today, 9:14 AM",
    initials: "MC",
    department: "Computer Science",
    year: "2027",
    consent: true,
    assessmentStatus: "recent",
  },
  {
    id: "leo-martin",
    name: "Leo Martin",
    role: "Frontend Engineer Intern",
    repo: "leo-martin/field-notes",
    coverage: "2 demonstrated · 2 partial · 1 unable to assess",
    updated: "Yesterday",
    initials: "LM",
    department: "Software Engineering",
    year: "2026",
    consent: true,
    assessmentStatus: "stale",
  },
  {
    id: "amira-jones",
    name: "Amira Jones",
    role: "Software Engineering Intern",
    repo: "amira-jones/greenroute",
    coverage: "2 demonstrated · 1 partial · 2 not in scope",
    updated: "Oct 12, 2026",
    initials: "AJ",
    department: "Computer Science",
    year: "2027",
    consent: false,
    assessmentStatus: "needs-review",
  },
];
export const demoCohort = {
  enrolled: 128,
  connected: 84,
  recent: 67,
  needsSupport: 19,
  roleCoverage: [
    { role: "Software Engineering", coverage: 68 },
    { role: "Frontend Engineering", coverage: 74 },
    { role: "Data Engineering", coverage: 51 },
  ],
};
