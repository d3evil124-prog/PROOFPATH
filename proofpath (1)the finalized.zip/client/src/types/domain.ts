export type UserRole = "student" | "recruiter" | "tpo";
export type AssessmentStatus =
  | "demonstrated"
  | "partial_or_needs_review"
  | "not_demonstrated_in_analyzed_scope"
  | "unable_to_assess";
export type OperationalState =
  | "queued"
  | "running"
  | "detected"
  | "analyzing"
  | "completed"
  | "failed"
  | "stale";
export type EvidenceType =
  | "implementation"
  | "test"
  | "configuration"
  | "documentation";
export type JobSourceKind = "pasted" | "fetched";

export interface JobRequirement {
  id: string;
  wording: string;
  skill: string;
  priority: "Required" | "Preferred";
}
export interface JobPosting {
  id: string;
  title: string;
  company: string;
  sourceUrl: string | null;
  retrievedAt: string | null;
  method: JobSourceKind;
  requirements: JobRequirement[];
}
export interface Repository {
  id: string;
  owner: string;
  name: string;
  url: string;
  branch: string;
  visibility: "public" | "private" | "unknown";
  access: "connected" | "not_connected" | "needs_authorization";
  lastAnalyzedSha: string | null;
  lastAnalyzedAt: string | null;
}
export interface EvidenceCitation {
  id: string;
  requirementId: string;
  repositoryId: string;
  path: string;
  lineStart: number;
  lineEnd: number;
  commitSha: string;
  commitUrl: string;
  type: EvidenceType;
  excerpt: string[];
  explanation: string;
  confidence: "medium" | "high";
}
export interface SkillAssessment {
  requirementId: string;
  status: AssessmentStatus;
  explanation: string;
  citationIds: string[];
  coverage: string;
  lastChanged: string | null;
}
export interface AssessmentSummary {
  id: string;
  jobId: string;
  repositoryId: string;
  commitSha: string;
  createdAt: string;
  state: OperationalState;
  skills: SkillAssessment[];
  filesInspected: number;
  filesExcluded: number;
  testsDiscovered: boolean;
  testsExecuted: boolean;
}
export interface ChangeEvent {
  id: string;
  timestamp: string;
  sha: string;
  message: string;
  files: {
    path: string;
    change: "modified" | "added" | "removed" | "renamed";
  }[];
  state: OperationalState;
  affected: string[];
  statusChanges?: {
    skill: string;
    before: AssessmentStatus | null;
    after: AssessmentStatus;
  }[];
  evidenceAdded: number;
  evidenceRemoved: number;
  explanation: string;
  unchanged: string[];
}
export interface MonitoringStatus {
  state: "active" | "paused" | "failed" | "stale";
  lastChecked: string | null;
  latestObservedCommit: string | null;
  lastAssessedCommit: string | null;
  pendingEvents: number;
}
export interface PortfolioReport {
  cohortSize: number;
  connectedPortfolios: number;
  requirementsCovered: number;
  evidenceGaps: number;
  coverageLimitations: string[];
  generatedAt: string;
}
