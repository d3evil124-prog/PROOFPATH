import { LockKeyhole, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { AppShell } from "@/components/AppShell";
import { EmptyState, PageTitle } from "@/components/SharedUI";

export default function TeamPages() {
  return <AppShell title="Organization access"><PageTitle title="Organization access" subtitle="Candidate and cohort views are hidden unless an organization workspace is explicitly authorized." /><section className="card card-pad"><EmptyState icon="warning" title="No organization access is configured" description="ProofPath does not preload candidate profiles, student records, cohort metrics, or reports. Sign in to your private student workspace, or contact your organization administrator about an authorized workspace." action={<Link className="button button-outline button-small" href="/student/dashboard"><ShieldCheck size={13} /> Open my workspace</Link>} /><div className="organization-access-note"><LockKeyhole size={15} /><span>Public GitHub repositories do not grant access to a person's employment or institutional profile.</span></div></section></AppShell>;
}
