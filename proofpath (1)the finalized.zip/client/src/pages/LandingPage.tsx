import { ArrowDownRight, ArrowRight, ArrowUpRight, Code2, GitCommitHorizontal, GitFork, Menu, ShieldCheck, Target, X } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function LandingPage() {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <main className="landing">
      <nav className="marketing-nav wrap" aria-label="Main navigation">
        <Link href="/" className="brand"><span className="brand-symbol"><GitFork size={18} strokeWidth={2.4} /><i /></span><span>proofpath</span></Link>
        <div className={`nav-links ${mobileOpen ? "open" : ""}`}>
          <a href="#product" onClick={() => setMobileOpen(false)}>Product</a>
          <a href="#how" onClick={() => setMobileOpen(false)}>How it works</a>
          <a href="#students" onClick={() => setMobileOpen(false)}>For students</a>
          <a href="#organizations" onClick={() => setMobileOpen(false)}>For organizations</a>
        </div>
        <div className="nav-actions"><Link href="/login" className="nav-signin">Sign in</Link><Link className="button button-primary button-small" href="/student/setup">Analyze my portfolio <ArrowRight size={15} /></Link></div>
        <button className="mobile-menu" aria-label={mobileOpen ? "Close navigation" : "Open navigation"} onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <Menu />}</button>
      </nav>
      <section className="hero wrap" id="product">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" />PORTFOLIO EVIDENCE, NOT GUESSWORK</div>
          <h1>Your code tells a story.<br /><span>Make the evidence visible.</span></h1>
          <p>Compare your GitHub portfolio with real job requirements. See the skills your code demonstrates, understand the gaps, and follow changes against the exact commits that were inspected.</p>
          <div className="hero-actions"><Link className="button button-primary" href="/student/setup">Analyze my portfolio <ArrowRight size={16} /></Link><a className="button button-quiet" href="#how">How it works <ArrowUpRight size={15} /></a></div>
          <div className="hero-note"><ShieldCheck size={15} />Claims link back to source evidence. Missing evidence is not a verdict.</div>
        </div>
        <div className="hero-preview connect-preview" aria-label="Product connection preview">
          <div className="preview-top"><div className="preview-breadcrumb"><span className="repo-glyph">⌘</span><span>Your portfolio workspace</span></div><span className="pill pill-amber">Connect to begin</span></div>
          <div className="connect-empty"><div className="connect-mark"><GitFork size={21} /></div><span className="mini-label">NO PORTFOLIO DATA YET</span><h3>Your evidence starts with your sources.</h3><p>Add a job posting, upload your resume, then choose a repository you authorize. Your results use only the sources you provide.</p><div className="connect-sequence"><span><Target size={13} /> Real job</span><span><Code2 size={13} /> Authorized code</span><span><GitCommitHorizontal size={13} /> Commit history</span></div></div>
          <div className="preview-foot"><span>Assessments are tied to a selected repository revision.</span><span>Evidence first</span></div>
        </div>
        <div className="hero-evidence-3d" aria-hidden="true">
          <svg viewBox="0 0 520 360" role="presentation">
            <path d="M30 270 145 190 235 230 330 112 478 72M145 190 180 80 330 112M235 230 292 310 420 220 478 72" />
            <path className="hero-evidence-dash" d="M30 270 145 190 235 230 330 112 478 72" />
            <circle cx="30" cy="270" r="7" /><circle cx="145" cy="190" r="9" />
            <circle cx="235" cy="230" r="6" /><circle cx="330" cy="112" r="10" />
            <circle cx="478" cy="72" r="7" /><circle cx="292" cy="310" r="6" />
            <circle cx="420" cy="220" r="7" />
          </svg>
        </div>
        <div className="hero-grid" aria-hidden="true" />
      </section>
      <section className="trust-strip wrap"><div><span className="trust-icon"><ShieldCheck size={17} /></span><div><b>Evidence, not guesses.</b><small>See what was inspected and what was not.</small></div></div><div><span className="trust-icon"><Code2 size={17} /></span><div><b>Every claim traceable to code.</b><small>Open the commit-pinned citation.</small></div></div><div><span className="trust-icon"><GitCommitHorizontal size={17} /></span><div><b>Assessment that evolves.</b><small>Changes are grounded in new commits.</small></div></div></section>
      <section className="how-section" id="how"><div className="wrap"><div className="section-heading"><span className="eyebrow">A CLEARER WAY TO SHOW YOUR WORK</span><h2>From a job description to<br />evidence you can point to.</h2></div><div className="steps"><div className="step"><span>01</span><div className="step-icon"><Target size={19} /></div><h3>Choose a real job</h3><p>Import a public posting or paste its exact description, then review the extracted requirements.</p></div><div className="step"><span>02</span><div className="step-icon"><GitFork size={19} /></div><h3>Add your resume</h3><p>Resume details add context; they never count as proof of a technical skill.</p></div><div className="step"><span>03</span><div className="step-icon"><Code2 size={19} /></div><h3>Authorize a repository</h3><p>Choose the GitHub project and branch you want ProofPath to inspect.</p></div><div className="step"><span>04</span><div className="step-icon"><GitCommitHorizontal size={19} /></div><h3>Follow evidence changes</h3><p>See how each assessed commit changed the supported evidence record.</p></div></div></div></section>
      <section className="role-section wrap" id="students"><div className="role-heading"><div><span className="eyebrow">BUILT AROUND EVIDENCE</span><h2>One portfolio. A clearer<br />view for every role.</h2></div><span>Organization workspaces are available<br />only when explicitly authorized.</span></div><div className="role-cards" id="organizations"><Link href="/student/setup" className="role-card"><span className="role-icon"><Code2 size={19} /></span><span className="role-tag">Private workspace</span><h3>Student</h3><p>Understand what your submitted portfolio demonstrates—and what to build next.</p><span className="role-link">Analyze your portfolio <ArrowRight size={14} /></span></Link><Link href="/recruiter/dashboard" className="role-card"><span className="role-icon"><Target size={19} /></span><span className="role-tag">Access required</span><h3>Recruiter</h3><p>Organization access requires an authorized account. No candidate records are preloaded.</p><span className="role-link">View access information <ArrowRight size={14} /></span></Link><Link href="/tpo/dashboard" className="role-card"><span className="role-icon"><GitFork size={19} /></span><span className="role-tag">Access required</span><h3>College T&amp;P</h3><p>Institutional workspaces require explicit authorization. No cohort data is preloaded.</p><span className="role-link">View access information <ArrowRight size={14} /></span></Link></div></section>
      <section className="cta-band wrap"><div className="cta-icon"><ShieldCheck size={18} /></div><div><span className="eyebrow">A PORTFOLIO IS MORE THAN A SCORE</span><h2>Show the work behind the skill.</h2></div><Link href="/student/setup" className="button button-primary">Connect your sources <ArrowRight size={15} /></Link><ArrowDownRight className="cta-decoration" size={82} /></section>
      <footer className="marketing-footer wrap"><Link href="/" className="brand"><span className="brand-symbol"><GitFork size={17} /><i /></span><span>proofpath</span></Link><div className="footer-links"><a href="#product">Product</a><a href="#how">How it works</a><Link href="/student/settings">Privacy &amp; limitations</Link><Link href="/login">Sign in</Link><a href="https://github.com" target="_blank" rel="noreferrer">GitHub</a></div><span>© 2026 ProofPath</span></footer>
    </main>
  );
}
