import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useLocation, useRoute } from "wouter";
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Check,
  Clock3,
  Code2,
  FileCheck2,
  FileClock,
  GitBranch,
  GitCommitHorizontal,
  GitFork,
  Info,
  LoaderCircle,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  Upload,
  X,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import {
  EmptyState,
  PageTitle,
  SectionTitle,
  StatusBadge,
} from "@/components/SharedUI";
import { COOKIE_NAME } from "@/const";
import { trpc } from "@/lib/trpc";

function prettyDate(value?: string | Date | null) {
  if (!value) return "Not yet available";
  const date = new Date(value);
  return Number.isNaN(date.valueOf())
    ? "Not yet available"
    : date.toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      });
}
function compactSha(value?: string | null) {
  return value ? value.slice(0, 7) : "—";
}
function ErrorNotice({ children }: { children: ReactNode }) {
  return (
    <div className="live-error" role="alert">
      <Info size={15} />
      {children}
    </div>
  );
}
function LoadingBlock() {
  return (
    <div className="live-loading" role="status">
      <LoaderCircle size={16} className="spin" />
      Loading your records…
    </div>
  );
}
function DataError({
  error,
  retry,
}: {
  error?: { message: string } | null;
  retry?: () => void;
}) {
  if (!error) return null;
  return (
    <div className="live-error" role="alert">
      <Info size={15} />
      <span>{error.message}</span>
      {retry && (
        <button className="text-button" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}
function CurrentSelection({
  jobs,
  repositories,
  jobId,
  repositoryId,
  onJob,
  onRepository,
}: {
  jobs: { id: number; title: string }[];
  repositories: { id: number; fullName: string }[];
  jobId?: number;
  repositoryId?: number;
  onJob: (value: number | undefined) => void;
  onRepository: (value: number | undefined) => void;
}) {
  return (
    <div className="live-selection">
      <label>
        <span>Job posting</span>
        <select
          aria-label="Select job posting"
          value={jobId ?? ""}
          onChange={event =>
            onJob(event.target.value ? Number(event.target.value) : undefined)
          }
        >
          <option value="">Select a job</option>
          {jobs.map(job => (
            <option key={job.id} value={job.id}>
              {job.title}
            </option>
          ))}
        </select>
      </label>
      <label>
        <span>Repository</span>
        <select
          aria-label="Select repository"
          value={repositoryId ?? ""}
          onChange={event =>
            onRepository(
              event.target.value ? Number(event.target.value) : undefined
            )
          }
        >
          <option value="">Select a repository</option>
          {repositories.map(repo => (
            <option key={repo.id} value={repo.id}>
              {repo.fullName}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}
function CommitLink({
  owner,
  name,
  sha,
  path,
  start,
  end,
}: {
  owner: string;
  name: string;
  sha: string;
  path?: string;
  start?: number;
  end?: number;
}) {
  const url = `https://github.com/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/blob/${encodeURIComponent(sha)}${path ? `/${path.split("/").map(encodeURIComponent).join("/")}` : ""}${start ? `#L${start}${end ? `-L${end}` : ""}` : ""}`;
  return (
    <a className="link-indigo" href={url} target="_blank" rel="noreferrer">
      Open at inspected commit <ArrowUpRight size={12} />
    </a>
  );
}

function SetupPage() {
  const utils = trpc.useUtils();
  const jobsQuery = trpc.proofpath.jobs.list.useQuery();
  const reposQuery = trpc.proofpath.github.repositories.useQuery();
  const resumeQuery = trpc.proofpath.resume.latest.useQuery();
  const removeResume = trpc.proofpath.resume.remove.useMutation({
    onSuccess: async () => {
      await resumeQuery.refetch();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const [path, setPath] = useLocation();
  const [jobId, setJobId] = useState<number>();
  const [repositoryId, setRepositoryId] = useState<number>();
  const [newPosting, setNewPosting] = useState(false);
  const [sourceMode, setSourceMode] = useState<"url" | "pasted">("url");
  const [jobUrl, setJobUrl] = useState("");
  const [jobText, setJobText] = useState("");
  const [importedJobId, setImportedJobId] = useState<number>();
  const [title, setTitle] = useState("");
  const [company, setCompany] = useState("");
  const [requirements, setRequirements] = useState<
    {
      originalWording: string;
      skill: string;
      priority: "required" | "preferred";
    }[]
  >([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [uploadMessage, setUploadMessage] = useState("");
  const [assessmentError, setAssessmentError] = useState("");
  const [branchByRepo, setBranchByRepo] = useState<Record<number, string>>({});
  const [publicRepoUrl, setPublicRepoUrl] = useState("");
  const jobs = jobsQuery.data ?? [];
  const repositories = reposQuery.data?.repositories ?? [];
  const selectedJob =
    jobs.find(job => job.id === (importedJobId ?? jobId)) ?? jobs[0];
  const selectedRepository =
    repositories.find(repo => repo.id === repositoryId) ??
    repositories.find(repo => repo.selected) ??
    repositories[0];
  const reviewJob = importedJobId
    ? jobs.find(job => job.id === importedJobId)
    : selectedJob;
  const importJob = trpc.proofpath.jobs.import.useMutation({
    onSuccess: async result => {
      setImportedJobId(result.id);
      setNewPosting(false);
      setJobId(result.id);
      setTitle(result.title);
      setCompany(result.company ?? "");
      setRequirements(
        result.requirements.map(item => ({
          originalWording: item.originalWording,
          skill: item.skill,
          priority: item.priority,
        }))
      );
      await utils.proofpath.jobs.list.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const saveReview = trpc.proofpath.jobs.review.useMutation({
    onSuccess: async result => {
      setImportedJobId(undefined);
      setNewPosting(false);
      setJobId(result?.id);
      await utils.proofpath.jobs.list.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const selectRepo = trpc.proofpath.github.select.useMutation({
    onSuccess: async result => {
      setRepositoryId(result.id);
      await utils.proofpath.github.repositories.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const addPublicRepo = trpc.proofpath.github.addPublicLink.useMutation({
    onSuccess: async result => {
      setRepositoryId(result.id);
      setPublicRepoUrl("");
      await utils.proofpath.github.repositories.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const addTokenRepo = trpc.proofpath.github.addTokenRepository.useMutation({
    onSuccess: async result => {
      setRepositoryId(result.id);
      setPublicRepoUrl("");
      await utils.proofpath.github.repositories.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const startAssessment = trpc.proofpath.assessment.start.useMutation({
    onSuccess: async () => {
      await utils.proofpath.assessment.latest.invalidate();
      await utils.proofpath.dashboard.invalidate();
      setPath("/student/assessment");
    },
    onError: error => setAssessmentError(error.message),
  });

  useEffect(() => {
    if (!jobId && jobs[0]) setJobId(jobs[0].id);
  }, [jobId, jobs]);
  useEffect(() => {
    if (!repositoryId && repositories.find(repo => repo.selected))
      setRepositoryId(repositories.find(repo => repo.selected)!.id);
  }, [repositoryId, repositories]);
  useEffect(() => {
    const pending = jobs.find(
      job => job.id === jobId && job.extractionStatus === "needs_review"
    );
    if (pending && !newPosting && !importedJobId) setImportedJobId(pending.id);
  }, [jobs, jobId, newPosting, importedJobId]);
  useEffect(() => {
    const job = importedJobId
      ? jobs.find(item => item.id === importedJobId)
      : jobs.find(item => item.id === jobId);
    if (job) {
      setTitle(job.title);
      setCompany(job.company ?? "");
      setRequirements(
        job.requirements.map(item => ({
          originalWording: item.originalWording,
          skill: item.skill,
          priority: item.priority,
        }))
      );
    }
  }, [jobs, importedJobId, jobId]);

  async function uploadResume(file?: File) {
    if (!file) return;
    setUploadError("");
    setUploadMessage("");
    if (file.size > 5 * 1024 * 1024) {
      setUploadError("Choose a PDF or DOCX smaller than 5 MB.");
      return;
    }
    const mime =
      file.type ||
      (file.name.toLowerCase().endsWith(".pdf")
        ? "application/pdf"
        : file.name.toLowerCase().endsWith(".docx")
          ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          : "");
    if (
      mime !== "application/pdf" &&
      mime !==
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      setUploadError("Unsupported format. Choose a PDF or DOCX file.");
      return;
    }
    setUploading(true);
    try {
      const headers: Record<string, string> = {
        "Content-Type": mime,
        "X-Resume-Mime": mime,
        "X-File-Name": encodeURIComponent(file.name),
      };
      try {
        const raw = sessionStorage.getItem("manus-cookie");
        const pair = raw
          ?.split(";")
          .find(value => value.trim().startsWith(`${COOKIE_NAME}=`));
        const token = pair?.trim().slice(`${COOKIE_NAME}=`.length);
        if (token) headers.Authorization = `Bearer ${token}`;
      } catch {
        /* Browser cookies remain available when session storage is unavailable. */
      }
      const response = await fetch("/api/resumes/upload", {
        method: "POST",
        headers,
        credentials: "include",
        body: file,
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error ?? "Resume upload failed.");
      setUploadMessage(
        `Uploaded and parsed ${data.resume.originalName}. Review its extracted information below.`
      );
      await resumeQuery.refetch();
      await utils.proofpath.dashboard.invalidate();
    } catch (error) {
      setUploadError(
        error instanceof Error ? error.message : "Resume upload failed."
      );
    } finally {
      setUploading(false);
    }
  }

  return (
    <AppShell title="Portfolio setup">
      <PageTitle
        title="Build your evidence record"
        subtitle="Connect your own sources. Only the jobs, resumes, repositories, and results you add appear here."
      />
      <DataError
        error={jobsQuery.error ?? reposQuery.error ?? resumeQuery.error}
        retry={() => {
          void jobsQuery.refetch();
          void reposQuery.refetch();
          void resumeQuery.refetch();
        }}
      />
      <section className="setup-step-card card card-pad">
        <div className="live-step-heading">
          <span className="live-step-number">01</span>
          <div>
            <span className="section-label">JOB REQUIREMENTS</span>
            <h2>Choose a real job posting</h2>
            <p>
              Import an accessible public URL or paste the exact text. Review
              every extracted requirement before confirming.
            </p>
          </div>
          <StatusBadge
            status={
              selectedJob?.extractionStatus === "confirmed"
                ? "completed"
                : selectedJob
                  ? "queued"
                  : "stale"
            }
            label={
              selectedJob?.extractionStatus === "confirmed"
                ? "Requirements confirmed"
                : selectedJob
                  ? "Review required"
                  : "No job added"
            }
          />
        </div>
        {selectedJob &&
        selectedJob.extractionStatus === "confirmed" &&
        !importedJobId &&
        !newPosting ? (
          <div className="live-current-source">
            <Check size={15} />
            <span>
              <b>{selectedJob.title}</b>
              <small>
                {selectedJob.sourceKind === "fetched"
                  ? selectedJob.sourceUrl
                  : "Pasted job description"}{" "}
                · {selectedJob.requirements.length} requirements
              </small>
            </span>
            <button
              className="button button-outline button-small"
              onClick={() => {
                setImportedJobId(selectedJob.id);
              }}
            >
              Review job
            </button>
            <button
              className="button button-outline button-small"
              onClick={() => {
                setNewPosting(true);
              }}
            >
              Add another job
            </button>
          </div>
        ) : null}
        {(newPosting ||
          !selectedJob ||
          selectedJob.extractionStatus !== "confirmed" ||
          importedJobId) && (
          <div className="live-form-grid">
            {!importedJobId && (
              <div className="live-form-panel">
                <div className="live-toggle">
                  <button
                    className={sourceMode === "url" ? "selected" : ""}
                    onClick={() => setSourceMode("url")}
                  >
                    Public URL
                  </button>
                  <button
                    className={sourceMode === "pasted" ? "selected" : ""}
                    onClick={() => setSourceMode("pasted")}
                  >
                    Paste description
                  </button>
                </div>
                {sourceMode === "url" ? (
                  <label className="live-field">
                    <span>Job posting URL</span>
                    <input
                      type="url"
                      placeholder="https://company.example/jobs/role"
                      value={jobUrl}
                      onChange={event => setJobUrl(event.target.value)}
                      autoComplete="url"
                    />
                    <small>
                      Only an accessible public page is fetched. If the site
                      blocks access, paste its exact description instead.
                    </small>
                  </label>
                ) : (
                  <label className="live-field">
                    <span>Exact job description</span>
                    <textarea
                      rows={6}
                      placeholder="Paste the job description text here…"
                      value={jobText}
                      onChange={event => setJobText(event.target.value)}
                    />
                    <small>
                      The text is sent to the configured analysis service to
                      extract requirements.
                    </small>
                  </label>
                )}
                <button
                  className="button button-primary"
                  disabled={
                    importJob.isPending ||
                    (sourceMode === "url"
                      ? !jobUrl.trim()
                      : jobText.trim().length < 120)
                  }
                  onClick={() =>
                    importJob.mutate(
                      sourceMode === "url"
                        ? { url: jobUrl.trim() }
                        : { description: jobText.trim() }
                    )
                  }
                >
                  {importJob.isPending ? (
                    <>
                      <LoaderCircle size={14} className="spin" />
                      Fetching and extracting…
                    </>
                  ) : (
                    <>
                      Fetch and extract requirements <ArrowRight size={14} />
                    </>
                  )}
                </button>
                {importJob.error && (
                  <ErrorNotice>{importJob.error.message}</ErrorNotice>
                )}
                {newPosting && (
                  <button
                    className="text-button"
                    onClick={() => setNewPosting(false)}
                  >
                    Cancel new posting
                  </button>
                )}
              </div>
            )}
            {importedJobId && (
              <div className="live-form-panel live-review-panel">
                <label className="live-field">
                  <span>Job title</span>
                  <input
                    value={title}
                    onChange={event => setTitle(event.target.value)}
                  />
                </label>
                <label className="live-field">
                  <span>Company, if identified</span>
                  <input
                    value={company}
                    onChange={event => setCompany(event.target.value)}
                    placeholder="Not identified"
                  />
                </label>
                <div className="live-req-list">
                  <b>Review extracted requirements</b>
                  {requirements.map((requirement, index) => (
                    <div
                      className="live-req-edit"
                      key={`${index}-${requirement.skill}`}
                    >
                      <label className="live-field">
                        <span>Skill</span>
                        <input
                          value={requirement.skill}
                          onChange={event =>
                            setRequirements(current =>
                              current.map((item, i) =>
                                i === index
                                  ? { ...item, skill: event.target.value }
                                  : item
                              )
                            )
                          }
                        />
                      </label>
                      <label className="live-field">
                        <span>Original wording</span>
                        <textarea
                          rows={2}
                          value={requirement.originalWording}
                          onChange={event =>
                            setRequirements(current =>
                              current.map((item, i) =>
                                i === index
                                  ? {
                                      ...item,
                                      originalWording: event.target.value,
                                    }
                                  : item
                              )
                            )
                          }
                        />
                      </label>
                      <label className="live-field">
                        <span>Priority</span>
                        <select
                          value={requirement.priority}
                          onChange={event =>
                            setRequirements(current =>
                              current.map((item, i) =>
                                i === index
                                  ? {
                                      ...item,
                                      priority: event.target.value as
                                        | "required"
                                        | "preferred",
                                    }
                                  : item
                              )
                            )
                          }
                        >
                          <option value="required">Required</option>
                          <option value="preferred">Preferred</option>
                        </select>
                      </label>
                      <button
                        className="icon-button"
                        aria-label={`Remove ${requirement.skill}`}
                        onClick={() =>
                          setRequirements(current =>
                            current.filter((_, i) => i !== index)
                          )
                        }
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  <button
                    className="button button-outline button-small"
                    onClick={() =>
                      setRequirements(current => [
                        ...current,
                        {
                          originalWording: "",
                          skill: "",
                          priority: "required",
                        },
                      ])
                    }
                  >
                    Add requirement
                  </button>
                </div>
                <div className="live-actions">
                  <button
                    className="button button-outline"
                    onClick={() => setImportedJobId(undefined)}
                  >
                    Cancel review
                  </button>
                  <button
                    className="button button-primary"
                    disabled={
                      saveReview.isPending ||
                      !title.trim() ||
                      requirements.length < 1 ||
                      requirements.some(
                        item =>
                          !item.skill.trim() ||
                          item.originalWording.trim().length < 8
                      )
                    }
                    onClick={() =>
                      saveReview.mutate({
                        jobId: importedJobId,
                        title,
                        company: company.trim() || null,
                        requirements,
                      })
                    }
                  >
                    {saveReview.isPending ? "Saving…" : "Confirm requirements"}
                  </button>
                </div>
                {saveReview.error && (
                  <ErrorNotice>{saveReview.error.message}</ErrorNotice>
                )}
              </div>
            )}
          </div>
        )}
        {selectedJob && selectedJob.sourceUrl && (
          <div className="live-source-meta">
            Source{" "}
            <a href={selectedJob.sourceUrl} target="_blank" rel="noreferrer">
              {selectedJob.sourceUrl}
              <ArrowUpRight size={11} />
            </a>{" "}
            · retrieved {prettyDate(selectedJob.retrievedAt)}
          </div>
        )}
      </section>

      <section className="setup-step-card card card-pad">
        <div className="live-step-heading">
          <span className="live-step-number">02</span>
          <div>
            <span className="section-label">RESUME CONTEXT</span>
            <h2>Upload your resume</h2>
            <p>
              PDF and DOCX are supported. Extracted mentions add context; they
              are not evidence of demonstrated technical ability.
            </p>
          </div>
          <StatusBadge
            status={resumeQuery.data ? "completed" : "stale"}
            label={resumeQuery.data ? "Resume available" : "No resume uploaded"}
          />
        </div>
        <div className="live-upload-row">
          <label className="button button-outline upload-button">
            <Upload size={14} />
            {uploading ? "Uploading and parsing…" : "Choose PDF or DOCX"}
            <input
              type="file"
              accept="application/pdf,.pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.docx"
              disabled={uploading}
              onChange={event => {
                void uploadResume(event.currentTarget.files?.[0]);
                event.currentTarget.value = "";
              }}
            />
          </label>
          <span className="muted small">
            Maximum file size: 5 MiB. ProofPath encrypts it on the server before database storage—you do not need to configure a key. Only extracted structured context is returned to your browser.
          </span>
        </div>
        {uploading && (
          <div className="live-progress" role="status">
            <LoaderCircle size={14} className="spin" />
            Validating, parsing and extracting resume context…
          </div>
        )}
        {uploadError && <ErrorNotice>{uploadError}</ErrorNotice>}
        {uploadMessage && (
          <div className="live-success">
            <Check size={14} />
            {uploadMessage}
          </div>
        )}
        {resumeQuery.data && (
          <div className="resume-profile">
            <div className="resume-profile-head">
              <div>
                <b>{resumeQuery.data.originalName}</b>
                <small>
                  Uploaded {prettyDate(resumeQuery.data.uploadedAt)} ·{" "}
                  {resumeQuery.data.mimeType}
                </small>
              </div>
              <button
                className="text-button"
                onClick={() => {
                  if (
                    window.confirm(
                      "Remove this resume, its encrypted original, extracted profile, and RAG passages from your ProofPath account? Assessment history will remain without resume context."
                    )
                  )
                    removeResume.mutate({ id: resumeQuery.data!.id });
                }}
              >
                Remove resume
              </button>
            </div>
            <details className="resume-review">
              <summary>Review extracted resume information</summary>
              <div className="resume-review-section">
                <b>Technical skills</b>
                <div className="resume-tags">
                  {resumeQuery.data.parsedProfile.technicalSkills.map(skill => (
                    <span className="pill" key={skill}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div className="resume-review-section">
                <b>Projects</b>
                {resumeQuery.data.parsedProfile.projects.length ? (
                  resumeQuery.data.parsedProfile.projects.map(
                    (project, index) => (
                      <p key={`${project.name}-${index}`}>
                        <strong>{project.name}</strong> — {project.summary}{" "}
                        <span className="muted">
                          {project.technologies.join(" · ")}
                        </span>
                      </p>
                    )
                  )
                ) : (
                  <p className="muted">No projects extracted.</p>
                )}
              </div>
              <div className="resume-review-section">
                <b>Work experience</b>
                {resumeQuery.data.parsedProfile.experience.length ? (
                  resumeQuery.data.parsedProfile.experience.map(
                    (item, index) => (
                      <p key={`${item.organization}-${index}`}>
                        <strong>{item.title}</strong> · {item.organization} —{" "}
                        {item.summary}
                      </p>
                    )
                  )
                ) : (
                  <p className="muted">No experience extracted.</p>
                )}
              </div>
              <div className="resume-review-section">
                <b>Education</b>
                {resumeQuery.data.parsedProfile.education.length ? (
                  resumeQuery.data.parsedProfile.education.map(
                    (item, index) => (
                      <p key={`${item.institution}-${index}`}>
                        <strong>{item.qualification}</strong> ·{" "}
                        {item.institution} — {item.summary}
                      </p>
                    )
                  )
                ) : (
                  <p className="muted">No education extracted.</p>
                )}
              </div>
              <div className="resume-review-section">
                <b>Certifications</b>
                <p>
                  {resumeQuery.data.parsedProfile.certifications.join(" · ") ||
                    "No certifications extracted."}
                </p>
              </div>
            </details>
            <div className="resume-context-warning">
              <ShieldCheck size={13} />
              Resume mentions are unverified context, not technical-skill proof.
            </div>
          </div>
        )}
        <div className="resume-skip-note">
          You may continue without a resume; absent resume information is not
          treated as a skill gap.
        </div>
      </section>

      <section className="setup-step-card card card-pad">
        <div className="live-step-heading">
          <span className="live-step-number">03</span>
          <div>
            <span className="section-label">AUTHORIZED SOURCE</span>
            <h2>Connect GitHub and select a repository</h2>
            <p>
              Paste a public GitHub repository link; no GitHub App setup or account grant is needed for public code. Private repositories still need explicit authorization. Repository contents are never executed.
            </p>
          </div>
          <StatusBadge
            status={selectedRepository?.selected ? "completed" : "paused"}
            label={selectedRepository?.selected ? "Repository selected" : repositories.length ? "Choose a repository" : "No repository selected"}
          />
        </div>
        <div className="live-integration-block">
          <GitFork size={17} />
          <div className="live-public-repo-form">
            <label className="live-field">
              <span>
                {reposQuery.data?.tokenConfigured
                  ? "GitHub repository URL"
                  : "Public GitHub repository URL"}
              </span>
              <input
                type="url"
                value={publicRepoUrl}
                onChange={event => setPublicRepoUrl(event.target.value)}
                placeholder="https://github.com/owner/repository"
                autoComplete="url"
              />
            </label>
            <p>
              {reposQuery.data?.tokenConfigured
                ? "Use the protected server token for a private repository, or verify a public link without account access. The token never reaches the browser."
                : "ProofPath verifies public reachability, then lets you choose a branch. A link does not verify that you own or control the repository."}
            </p>
            <button
              className="button button-primary button-small"
              disabled={!publicRepoUrl.trim() || addPublicRepo.isPending}
              onClick={() => addPublicRepo.mutate({ url: publicRepoUrl.trim() })}
            >
              {addPublicRepo.isPending ? "Verifying repository…" : "Verify and add repository"}
            </button>
            {addPublicRepo.error && <ErrorNotice>{addPublicRepo.error.message}</ErrorNotice>}
            {reposQuery.data?.tokenConfigured && (
              <>
                <button
                  className="button button-outline button-small"
                  disabled={!publicRepoUrl.trim() || addTokenRepo.isPending}
                  onClick={() => addTokenRepo.mutate({ url: publicRepoUrl.trim() })}
                >
                  {addTokenRepo.isPending
                    ? "Verifying with server token…"
                    : "Verify private repository with token"}
                </button>
                {addTokenRepo.error && <ErrorNotice>{addTokenRepo.error.message}</ErrorNotice>}
              </>
            )}
          </div>
        </div>
        {!reposQuery.data?.configured && !repositories.length ? (
          <div className="live-integration-block">
            <LockKeyhole size={17} />
            <div>
              <b>GitHub account is not connected</b>
              <p>
                For the fastest path, add a public repository link above—no GitHub App or account connection is required. Private repositories need an administrator-configured GitHub App.
              </p>
            </div>
          </div>
        ) : reposQuery.data?.connected || repositories.length > 0 ? (
          <div className="live-repository-select">
            <label className="live-field">
              <span>Authorized repository</span>
              <select
                value={selectedRepository?.id ?? ""}
                onChange={event =>
                  setRepositoryId(
                    event.target.value ? Number(event.target.value) : undefined
                  )
                }
              >
                <option value="">Choose a repository</option>
                {repositories.map(repo => (
                  <option value={repo.id} key={repo.id}>
                    {repo.fullName}
                    {repo.private ? " · private" : " · public"}
                  </option>
                ))}
              </select>
            </label>
            {selectedRepository && (
              <RepositoryBranchSelector
                repository={selectedRepository}
                selectedBranch={
                  branchByRepo[selectedRepository.id] ??
                  selectedRepository.branch ??
                  selectedRepository.defaultBranch
                }
                onBranch={branch =>
                  setBranchByRepo(current => ({
                    ...current,
                    [selectedRepository.id]: branch,
                  }))
                }
              />
            )}
            <div className="live-actions">
              {reposQuery.data?.connected && <button
                className="button button-outline"
                onClick={() => { window.location.href = "/api/github/connect"; }}
              >Refresh authorized repository list</button>}
              <button
                className="button button-primary"
                disabled={!selectedRepository || selectRepo.isPending}
                onClick={() =>
                  selectedRepository &&
                  selectRepo.mutate({
                    repositoryId: selectedRepository.id,
                    branch:
                      branchByRepo[selectedRepository.id] ??
                      selectedRepository.branch ??
                      selectedRepository.defaultBranch,
                  })
                }
              >
                {selectRepo.isPending
                  ? "Saving…"
                  : "Select repository and branch"}
              </button>
            </div>
            {selectRepo.error && (
              <ErrorNotice>{selectRepo.error.message}</ErrorNotice>
            )}
          </div>
        ) : (
          <div className="live-integration-block">
            <GitFork size={17} />
            <div>
              <b>
                {reposQuery.data?.tokenConfigured
                  ? "Server token access is ready"
                  : "Connect your GitHub account"}
              </b>
              <p>
                {reposQuery.data?.tokenConfigured
                  ? "Paste a private repository URL above and verify it with the protected token, then choose its branch."
                  : "GitHub authorization is a separate, explicit step. ProofPath will request read access only to repositories you authorize."}
              </p>
            </div>
            {!reposQuery.data?.tokenConfigured && (
              <button
                className="button button-primary button-small"
                onClick={() => {
                  window.location.href = "/api/github/connect";
                }}
              >
                Authorize GitHub
              </button>
            )}
          </div>
        )}
        {repositories.length === 0 && reposQuery.data?.connected && (
          <EmptyState
            title="No authorized repositories yet"
            description="Add a public repository link above, or connect an account only if you need private repository access."
            action={
              reposQuery.data.installationUrl ? (
                <a
                  className="button button-outline button-small"
                  href={reposQuery.data.installationUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  Install or configure repository access{" "}
                  <ArrowUpRight size={13} />
                </a>
              ) : undefined
            }
          />
        )}
        {selectedRepository?.selected && (
          <div className="live-repo-meta">
            <GitBranch size={13} />
            <span>
              {selectedRepository.fullName} ·{" "}
              {branchByRepo[selectedRepository.id] ??
                selectedRepository.branch ??
                selectedRepository.defaultBranch}
            </span>
            <span>
              Observed commit {compactSha(selectedRepository.latestObservedSha)}
            </span>
            <StatusBadge status={selectedRepository.watcherStatus} />
          </div>
        )}
      </section>

      <section className="setup-step-card card card-pad">
        <div className="live-step-heading">
          <span className="live-step-number">04</span>
          <div>
            <span className="section-label">SOURCE-BOUND ASSESSMENT</span>
            <h2>Inspect the selected portfolio</h2>
            <p>
              ProofPath inspects bounded source, tests, configuration and SQL at
              an exact commit. It does not execute repository code or claim
              tests were run.
            </p>
          </div>
        </div>
        <div className="scope-callout">
          <ShieldCheck size={15} />
          <span>
            Assessment claims link to the commit and validated file lines. If no
            evidence is found, the result says “Not demonstrated in this
            scope”—not that the skill is absent.
          </span>
        </div>
        {assessmentError && <ErrorNotice>{assessmentError}</ErrorNotice>}
        <button
          className="button button-primary"
          disabled={
            !selectedJob ||
            selectedJob.extractionStatus !== "confirmed" ||
            !selectedRepository?.selected ||
            startAssessment.isPending
          }
          onClick={() => {
            setAssessmentError("");
            if (selectedJob && selectedRepository)
              startAssessment.mutate({
                jobId: selectedJob.id,
                repositoryId: selectedRepository.id,
              });
          }}
        >
          {startAssessment.isPending ? (
            <>
              <LoaderCircle size={14} className="spin" />
              Queueing assessment…
            </>
          ) : (
            <>
              Analyze current commit <ArrowRight size={14} />
            </>
          )}
        </button>
        <small className="live-footnote">
          This queues a server-side current-commit analysis job. The previous
          completed assessment remains visible until a new result succeeds;
          progress refreshes automatically while the worker inspects files.
        </small>
      </section>
    </AppShell>
  );
}

function RepositoryBranchSelector({
  repository,
  selectedBranch,
  onBranch,
}: {
  repository: { id: number; defaultBranch: string };
  selectedBranch: string;
  onBranch: (branch: string) => void;
}) {
  const query = trpc.proofpath.github.branches.useQuery(
    { repositoryId: repository.id },
    { enabled: true, staleTime: 30_000 }
  );
  const branches = query.data ?? [];
  return (
    <label className="live-field">
      <span>Tracked branch</span>
      {query.isLoading ? (
        <span className="muted">Loading branches…</span>
      ) : query.error ? (
        <span className="muted">{query.error.message}</span>
      ) : (
        <select
          value={selectedBranch}
          onChange={event => onBranch(event.target.value)}
        >
          {branches.length ? (
            branches.map(branch => (
              <option key={branch} value={branch}>
                {branch}
              </option>
            ))
          ) : (
            <option value={repository.defaultBranch}>
              {repository.defaultBranch}
            </option>
          )}
        </select>
      )}
      <small>Only pushes to this branch are monitored.</small>
    </label>
  );
}

function DashboardPage() {
  const query = trpc.proofpath.dashboard.useQuery(undefined, {
    refetchInterval: 15_000,
    refetchIntervalInBackground: false,
  });
  const [, setPath] = useLocation();
  if (query.isLoading)
    return (
      <AppShell title="Overview">
        <PageTitle title="Your portfolio evidence" />
        <LoadingBlock />
      </AppShell>
    );
  const data = query.data;
  return (
    <AppShell title="Overview">
      <PageTitle
        title="Your portfolio evidence"
        subtitle="A private view of your submitted job, resume context, selected repository, and assessed evidence."
        action={
          <button
            className="button button-primary button-small"
            onClick={() => setPath("/student/setup")}
          >
            Continue setup <ArrowRight size={13} />
          </button>
        }
      />
      <DataError error={query.error} retry={() => void query.refetch()} />
      {!data?.jobs.length ? (
        <section className="card card-pad">
          <EmptyState
            icon="help"
            title="Start with your own sources"
            description="Import a real job posting, optionally upload a resume, authorize GitHub, and choose the repository and branch you want assessed."
            action={
              <button
                className="button button-primary button-small"
                onClick={() => setPath("/student/setup")}
              >
                Set up a portfolio <ArrowRight size={13} />
              </button>
            }
          />
        </section>
      ) : (
        <>
          <div className="live-summary-grid">
            <div className="card live-summary-card">
              <span>Job comparisons</span>
              <b>{data.jobs.length}</b>
              <small>Saved to your account</small>
            </div>
            <div className="card live-summary-card">
              <span>Selected repositories</span>
              <b>{data.repositories.length}</b>
              <small>Explicitly authorized</small>
            </div>
            <div className="card live-summary-card">
              <span>Resume context</span>
              <b>{data.resume ? "Available" : "Not added"}</b>
              <small>Not treated as proof</small>
            </div>
            <div className="card live-summary-card">
              <span>GitHub connection</span>
              <b>
                {data.github.connected
                  ? "GitHub account connected"
                  : data.github.selectedRepositoryAccess === "public_link"
                    ? "Public repo mode"
                    : data.github.selectedRepositoryAccess === "token"
                      ? "Server token mode"
                    : "Not connected"}
              </b>
              <small>
                {data.github.connected
                  ? `Last checked ${prettyDate(data.github.lastCheckedAt)}`
                  : data.github.selectedRepositoryAccess === "public_link"
                    ? `${data.github.selectedRepository?.fullName ?? "Public repository"} · no account grant needed`
                    : data.github.selectedRepositoryAccess === "token"
                      ? `${data.github.selectedRepository?.fullName ?? "Private repository"} · token stays server-side`
                    : "No repositories accessed"}
              </small>
            </div>
          </div>
          <div className="live-dashboard-grid">
            <section className="card card-pad">
              <SectionTitle
                title="Your job comparisons"
                subtitle="Only job sources and requirements you submitted are shown."
                action={
                  <button
                    className="link-indigo"
                    onClick={() => setPath("/student/setup")}
                  >
                    Add a posting <ArrowRight size={12} />
                  </button>
                }
              />
              {data.jobs.map(row => (
                <div className="live-job-row" key={row.job.id}>
                  <div className="live-job-icon">
                    <FileCheck2 size={15} />
                  </div>
                  <div className="live-job-main">
                    <b>{row.job.title}</b>
                    <small>
                      {row.job.company || "Company not identified"} ·{" "}
                      {row.job.sourceKind} source · {row.requirements.length}{" "}
                      requirements
                    </small>
                  </div>
                  <StatusBadge
                    status={
                      row.job.extractionStatus === "confirmed"
                        ? "completed"
                        : "queued"
                    }
                    label={
                      row.job.extractionStatus === "confirmed"
                        ? "Confirmed"
                        : "Review required"
                    }
                  />
                  <button
                    className="icon-button"
                    aria-label={`Open ${row.job.title}`}
                    onClick={() => setPath("/student/setup")}
                  >
                    <ArrowRight size={14} />
                  </button>
                </div>
              ))}
            </section>
            <section className="card card-pad">
              <SectionTitle
                title="Selected repository"
                subtitle="Connection and sync status from GitHub."
              />
              {data.repositories.length ? (
                data.repositories.map(repo => (
                  <div className="live-repo-row" key={repo.id}>
                    <GitFork size={16} />
                    <div>
                      <b>
                        {repo.repositoryOwner}/{repo.repositoryName}
                      </b>
                      <small>
                        <GitBranch size={11} />{" "}
                        {repo.branch ?? repo.defaultBranch} · last synced{" "}
                        {prettyDate(repo.lastSyncedAt)}
                      </small>
                      <small>
                        Latest observed commit{" "}
                        <code>{compactSha(repo.latestObservedSha)}</code>
                      </small>
                    </div>
                    <StatusBadge status={repo.watcherStatus} />
                  </div>
                ))
              ) : (
                <EmptyState
                  title="No selected repository"
                  description="Choose a GitHub repository and tracked branch in portfolio setup."
                  action={
                    <button
                      className="button button-outline button-small"
                      onClick={() => setPath("/student/setup")}
                    >
                      Open setup
                    </button>
                  }
                />
              )}
            </section>
          </div>
          <section className="card card-pad">
            <SectionTitle
              title="Latest assessment"
              subtitle="The current result is tied to a specific saved repository revision."
              action={
                <button
                  className="link-indigo"
                  onClick={() => setPath("/student/assessment")}
                >
                  Open assessment <ArrowRight size={12} />
                </button>
              }
            />
            {data.jobs.map(row =>
              row.assessment ? (
                <div className="live-assessment-row" key={row.assessment.id}>
                  <div>
                    <b>{row.job.title}</b>
                    <small>
                      {row.repository
                        ? `${row.repository.repositoryOwner}/${row.repository.repositoryName}`
                        : "Repository"}{" "}
                      · commit{" "}
                      <code>{compactSha(row.assessment.commitSha)}</code> ·{" "}
                      {prettyDate(row.assessment.completedAt)}
                    </small>
                  </div>
                  <StatusBadge
                    status={
                      row.assessment.latestAttempt?.state ??
                      row.assessment.state
                    }
                  />
                  {row.assessment.latestAttempt?.state === "failed" && (
                    <ErrorNotice>
                      Newer commit{" "}
                      {compactSha(row.assessment.latestAttempt.commitSha)}{" "}
                      failed. Showing the last successful assessment at{" "}
                      {compactSha(row.assessment.commitSha)}.
                    </ErrorNotice>
                  )}
                  {row.assessment.latestAttempt &&
                    (row.assessment.latestAttempt.state === "queued" ||
                      row.assessment.latestAttempt.state === "running") && (
                      <div className="live-progress" role="status">
                        Newer commit{" "}
                        {compactSha(row.assessment.latestAttempt.commitSha)} is{" "}
                        {row.assessment.latestAttempt.state}; this saved result
                        is pinned to {compactSha(row.assessment.commitSha)}.
                      </div>
                    )}
                  <span className="pill">
                    {row.assessment.filesInspected} files inspected
                  </span>
                </div>
              ) : (
                <div className="live-job-row" key={row.job.id}>
                  <div>
                    <b>{row.job.title}</b>
                    <small>No assessment has completed for this job yet.</small>
                  </div>
                  <StatusBadge status="stale" label="Not assessed" />
                  <button
                    className="button button-outline button-small"
                    onClick={() => setPath("/student/setup")}
                  >
                    Continue setup
                  </button>
                </div>
              )
            )}
          </section>
          <div className="scope-callout">
            <ShieldCheck size={15} />
            <span>
              ProofPath evaluates what your inspected portfolio demonstrates. It
              does not establish complete skill mastery or predict hiring
              outcomes.
            </span>
          </div>
        </>
      )}
    </AppShell>
  );
}

function useSelections() {
  const dashboard = trpc.proofpath.dashboard.useQuery(undefined, {
    refetchInterval: 3_000,
    refetchIntervalInBackground: false,
  });
  const [jobId, setJobId] = useState<number>();
  const [repositoryId, setRepositoryId] = useState<number>();
  const jobs = dashboard.data?.jobs.map(row => row.job) ?? [];
  const repositories = dashboard.data?.repositories ?? [];
  useEffect(() => {
    if (!jobId && jobs[0]) setJobId(jobs[0].id);
  }, [jobId, jobs]);
  useEffect(() => {
    if (!repositoryId && repositories.find(repo => repo.selected))
      setRepositoryId(repositories.find(repo => repo.selected)!.id);
  }, [repositoryId, repositories]);
  return {
    dashboard,
    jobs,
    repositories,
    jobId,
    repositoryId,
    setJobId,
    setRepositoryId,
  };
}

function AssessmentPage() {
  const {
    dashboard,
    jobs,
    repositories,
    jobId,
    repositoryId,
    setJobId,
    setRepositoryId,
  } = useSelections();
  const utils = trpc.useUtils();
  const query = trpc.proofpath.assessment.latest.useQuery(
    { jobId: jobId ?? 0, repositoryId: repositoryId ?? 0 },
    {
      enabled: Boolean(jobId && repositoryId),
      refetchInterval: query => {
        const current = query.state.data;
        const state = current?.latestAttempt?.state ?? current?.state;
        return state === "queued" || state === "running" ? 2000 : false;
      },
    }
  );
  const start = trpc.proofpath.assessment.start.useMutation({
    onSuccess: () => {
      void query.refetch();
      void utils.proofpath.dashboard.invalidate();
    },
  });
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("priority");
  const result = query.data;
  const skills = [...(result?.skills ?? [])]
    .filter(skill => filter === "all" || skill.status === filter)
    .sort((a, b) =>
      sort === "priority"
        ? (a.requirement?.priority ?? "").localeCompare(
            b.requirement?.priority ?? ""
          )
        : sort === "status"
          ? a.status.localeCompare(b.status)
          : new Date(b.createdAt).valueOf() - new Date(a.createdAt).valueOf()
    );
  return (
    <AppShell title="Skill assessment">
      <PageTitle
        title="Skill assessment"
        subtitle="Every claim is tied to a requirement and a validated repository citation."
        action={
          <button
            className="button button-outline button-small"
            disabled={!jobId || !repositoryId || start.isPending}
            onClick={() =>
              jobId && repositoryId && start.mutate({ jobId, repositoryId })
            }
          >
            <RefreshCw size={13} />
            Reassess current commit
          </button>
        }
      />
      <DataError
        error={dashboard.error ?? query.error}
        retry={() => void query.refetch()}
      />
      <CurrentSelection
        jobs={jobs.map(job => ({ id: job.id, title: job.title }))}
        repositories={repositories.map(repo => ({
          id: repo.id,
          fullName: `${repo.repositoryOwner}/${repo.repositoryName}`,
        }))}
        jobId={jobId}
        repositoryId={repositoryId}
        onJob={setJobId}
        onRepository={setRepositoryId}
      />
      {start.error && <ErrorNotice>{start.error.message}</ErrorNotice>}
      {!jobId || !repositoryId ? (
        <section className="card card-pad">
          <EmptyState
            title="Select a confirmed job and repository"
            description="The assessment compares a reviewed job posting with a repository and branch you explicitly selected."
            action={
              <a
                className="button button-outline button-small"
                href="/student/setup"
              >
                Open portfolio setup <ArrowRight size={13} />
              </a>
            }
          />
        </section>
      ) : !result ? (
        <section className="card card-pad">
          <EmptyState
            title="No assessment is saved for this selection"
            description="Queue the current branch commit for server-side inspection. Job requirements must be confirmed first."
            action={
              <button
                className="button button-primary button-small"
                disabled={start.isPending}
                onClick={() => start.mutate({ jobId, repositoryId })}
              >
                Analyze repository <ArrowRight size={13} />
              </button>
            }
          />
          {query.isLoading && <LoadingBlock />}
        </section>
      ) : (
        <>
          <section className="card card-pad">
            <div className="live-assessment-header">
              <div>
                <span className="section-label">
                  {result.jobId ? "ASSESSMENT VERSION" : "ASSESSMENT"}
                </span>
                <h2>
                  {result.state === "completed"
                    ? "Portfolio evidence at a specific commit"
                    : "Assessment processing"}
                </h2>
                <p>
                  Commit <code>{result.commitSha}</code> · branch{" "}
                  {result.branch} · saved{" "}
                  {prettyDate(result.completedAt ?? result.createdAt)}
                </p>
              </div>
              <StatusBadge status={result.state} />
              {result.latestAttempt && (
                <StatusBadge
                  status={result.latestAttempt.state}
                  label={`Newer commit · ${compactSha(result.latestAttempt.commitSha)}`}
                />
              )}
            </div>
            {result.latestAttempt?.state === "failed" ? (
              <ErrorNotice>
                Assessment of newer commit{" "}
                {compactSha(result.latestAttempt.commitSha)} failed:{" "}
                {result.latestAttempt.errorMessage ?? "processing failed"}. The
                last successful assessment at {compactSha(result.commitSha)}{" "}
                remains available; this failure is not shown as a new skill
                result.
              </ErrorNotice>
            ) : result.latestAttempt &&
              (result.latestAttempt.state === "queued" ||
                result.latestAttempt.state === "running") ? (
              <div className="live-progress" role="status">
                Commit {compactSha(result.latestAttempt.commitSha)} is{" "}
                {result.latestAttempt.state}. The last successful evidence at{" "}
                {compactSha(result.commitSha)} remains visible until
                reassessment succeeds.
              </div>
            ) : null}
            {result.state === "failed" && (
              <ErrorNotice>
                {result.errorMessage ??
                  "This assessment failed. No successful result is available yet."}
              </ErrorNotice>
            )}
            {result.state === "queued" || result.state === "running" ? (
              <div className="live-progress">
                <LoaderCircle size={14} className="spin" />
                The server is inspecting the selected commit. This page
                refreshes the processing status.
              </div>
            ) : null}
            <div className="live-coverage-grid">
              <div>
                <b>{result.filesInspected}</b>
                <small>files inspected</small>
              </div>
              <div>
                <b>{result.filesExcluded}</b>
                <small>files excluded</small>
              </div>
              <div>
                <b>
                  {result.testsDiscovered ? "Discovered" : "Not discovered"}
                </b>
                <small>tests identified</small>
              </div>
              <div>
                <b>{result.testsExecuted ? "Yes" : "No"}</b>
                <small>tests executed by ProofPath</small>
              </div>
            </div>
            <details className="scope-details">
              <summary>Inspection scope and limitations</summary>
              <p>
                Inspected files are limited to the code excerpts sent for this
                assessment. Excluded paths and reasons are recorded; repository
                code is not executed.
              </p>
              <ul>
                {result.scopeSummary?.excluded
                  ?.slice(0, 12)
                  .map(
                    (item: { path: string; reason: string }, index: number) => (
                      <li key={`${item.path}-${index}`}>
                        <code>{item.path}</code> — {item.reason}
                      </li>
                    )
                  )}
              </ul>
            </details>
          </section>
          <section className="card card-pad">
            <div className="live-filter-row">
              <SectionTitle
                title="Requirement-by-requirement results"
                subtitle="A missing signal means “Not demonstrated in this scope,” not proof that a skill is absent."
              />
              <div className="live-filter-controls">
                <label>
                  <span>Status</span>
                  <select
                    value={filter}
                    onChange={event => setFilter(event.target.value)}
                  >
                    <option value="all">All statuses</option>
                    <option value="demonstrated">Demonstrated</option>
                    <option value="partial_or_needs_review">
                      Partial / review
                    </option>
                    <option value="not_demonstrated_in_analyzed_scope">
                      Not demonstrated in scope
                    </option>
                    <option value="unable_to_assess">Unable to assess</option>
                  </select>
                </label>
                <label>
                  <span>Sort</span>
                  <select
                    value={sort}
                    onChange={event => setSort(event.target.value)}
                  >
                    <option value="priority">Priority</option>
                    <option value="status">Status</option>
                    <option value="updated">Recently changed</option>
                  </select>
                </label>
              </div>
            </div>
            {skills.length === 0 ? (
              <EmptyState
                title="No requirement results yet"
                description="Results appear after the server-side assessment completes."
              />
            ) : (
              <div className="live-skill-list">
                {skills.map(skill => (
                  <article className="live-skill-row" key={skill.id}>
                    <div className="live-skill-main">
                      <div className="live-skill-top">
                        <div>
                          <span className="section-label">
                            {skill.requirement?.priority ?? "Requirement"}
                          </span>
                          <h3>{skill.requirement?.skill ?? "Requirement"}</h3>
                        </div>
                        <StatusBadge status={skill.status} />
                      </div>
                      <p className="live-original-wording">
                        “{skill.requirement?.originalWording}”
                      </p>
                      <p>{skill.explanation}</p>
                      {skill.resumeMentioned && (
                        <div className="resume-context-warning">
                          <ShieldCheck size={13} />
                          {skill.resumeSupport} · not verified by code
                        </div>
                      )}
                      {skill.citations.length > 0 ? (
                        <div className="live-citation-list">
                          {skill.citations.map(citation => (
                            <div
                              className="live-citation-card"
                              key={citation.id}
                            >
                              <div>
                                <Code2 size={13} />
                                <code>{citation.path}</code>
                                <span>
                                  Lines {citation.lineStart}–{citation.lineEnd}
                                </span>
                              </div>
                              <pre>{citation.excerpt}</pre>
                              <p>{citation.explanation}</p>
                              <CommitLink
                                owner={
                                  repositories.find(
                                    repo => repo.id === repositoryId
                                  )?.repositoryOwner ?? ""
                                }
                                name={
                                  repositories.find(
                                    repo => repo.id === repositoryId
                                  )?.repositoryName ?? ""
                                }
                                sha={citation.commitSha}
                                path={citation.path}
                                start={citation.lineStart}
                                end={citation.lineEnd}
                              />
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="live-no-citation">
                          No repository citation supports a positive claim.{" "}
                          {skill.recommendation}
                        </div>
                      )}
                      {skill.recommendation && (
                        <div className="live-recommendation">
                          <b>Possible next step</b>
                          <span>{skill.recommendation}</span>
                        </div>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
          <div className="scope-callout">
            <ShieldCheck size={15} />
            <span>
              ProofPath evaluates what your inspected portfolio demonstrates. It
              does not establish complete skill mastery or predict hiring
              outcomes.
            </span>
          </div>
        </>
      )}
    </AppShell>
  );
}

function EvidencePage() {
  const {
    dashboard,
    jobs,
    repositories,
    jobId,
    repositoryId,
    setJobId,
    setRepositoryId,
  } = useSelections();
  const query = trpc.proofpath.assessment.latest.useQuery(
    { jobId: jobId ?? 0, repositoryId: repositoryId ?? 0 },
    {
      enabled: Boolean(jobId && repositoryId),
      refetchInterval: 15_000,
      refetchIntervalInBackground: false,
    }
  );
  const params = new URLSearchParams(window.location.search);
  const [skillId, setSkillId] = useState<number>(
    () => Number(params.get("skill")) || 0
  );
  useEffect(() => {
    if (!skillId && query.data?.skills[0]) setSkillId(query.data.skills[0].id);
  }, [skillId, query.data]);
  const selected =
    query.data?.skills.find(skill => skill.id === skillId) ??
    query.data?.skills[0];
  const repo = repositories.find(item => item.id === repositoryId);
  return (
    <AppShell title="Evidence inspector">
      <PageTitle
        title="Evidence inspector"
        subtitle="Source-linked excerpts are pinned to the exact commit that ProofPath assessed."
      />
      <DataError error={dashboard.error ?? query.error} />
      <CurrentSelection
        jobs={jobs.map(job => ({ id: job.id, title: job.title }))}
        repositories={repositories.map(item => ({
          id: item.id,
          fullName: `${item.repositoryOwner}/${item.repositoryName}`,
        }))}
        jobId={jobId}
        repositoryId={repositoryId}
        onJob={setJobId}
        onRepository={setRepositoryId}
      />
      {!query.data || !selected ? (
        <section className="card card-pad">
          <EmptyState
            title="No evidence to inspect yet"
            description="Select a job and repository with a completed assessment. Evidence appears only when a valid source citation was saved."
          />
        </section>
      ) : (
        <div className="live-inspector-layout">
          <nav
            className="card live-requirement-nav"
            aria-label="Select a requirement"
          >
            {query.data.skills.map(skill => (
              <button
                key={skill.id}
                className={skill.id === selected.id ? "active" : ""}
                onClick={() => {
                  setSkillId(skill.id);
                  const next = new URL(window.location.href);
                  next.searchParams.set("skill", String(skill.id));
                  window.history.replaceState({}, "", next);
                }}
              >
                <span>{skill.requirement?.skill}</span>
                <StatusBadge status={skill.status} />
              </button>
            ))}
          </nav>
          <section className="card card-pad live-inspector-detail">
            <div className="live-assessment-header">
              <div>
                <span className="section-label">JOB REQUIREMENT</span>
                <h2>{selected.requirement?.skill}</h2>
                <p>{selected.requirement?.originalWording}</p>
              </div>
              <StatusBadge status={selected.status} />
            </div>
            <p>{selected.explanation}</p>
            {selected.resumeMentioned && (
              <div className="resume-context-warning">
                <ShieldCheck size={13} />
                {selected.resumeSupport} · resume context is unverified
              </div>
            )}
            {selected.citations.length ? (
              selected.citations.map(citation => (
                <article className="live-citation-card" key={citation.id}>
                  <div className="live-citation-meta">
                    <div>
                      <span className="section-label">
                        {citation.evidenceType}
                      </span>
                      <h3>
                        <Code2 size={14} />
                        <code>{citation.path}</code>
                      </h3>
                      <small>
                        Lines {citation.lineStart}–{citation.lineEnd} · commit{" "}
                        {compactSha(citation.commitSha)} · {citation.confidence}{" "}
                        confidence
                      </small>
                    </div>
                    <CommitLink
                      owner={repo?.repositoryOwner ?? ""}
                      name={repo?.repositoryName ?? ""}
                      sha={citation.commitSha}
                      path={citation.path}
                      start={citation.lineStart}
                      end={citation.lineEnd}
                    />
                  </div>
                  <pre>{citation.excerpt}</pre>
                  <p>{citation.explanation}</p>
                  <small>
                    Repository {repo?.repositoryOwner}/{repo?.repositoryName} ·
                    branch {query.data?.branch ?? ""}
                  </small>
                </article>
              ))
            ) : (
              <div className="live-no-citation">
                No code citation is stored for this result. This result cannot
                be interpreted as demonstrated skill.
              </div>
            )}
            <div className="scope-callout">
              <Info size={14} />
              <span>
                Only the cited source lines and recorded scope were inspected.
                This does not establish complete skill mastery.
              </span>
            </div>
          </section>
        </div>
      )}
    </AppShell>
  );
}

function HistoryPage({ ledgerOnly = false }: { ledgerOnly?: boolean }) {
  const {
    dashboard,
    jobs,
    repositories,
    jobId,
    repositoryId,
    setJobId,
    setRepositoryId,
  } = useSelections();
  const query = trpc.proofpath.assessment.history.useQuery(
    { jobId: jobId ?? 0, repositoryId: repositoryId ?? 0 },
    {
      enabled: Boolean(jobId && repositoryId),
      refetchInterval: 3_000,
      refetchIntervalInBackground: false,
    }
  );
  const entries = query.data?.events ?? [];
  const versions = query.data?.versions ?? [];
  const [eventFilter, setEventFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("");
  const filtered = entries.filter(event => {
    const type = event.processingState;
    const typeMatch = eventFilter === "all" || type === eventFilter;
    const statusMatch =
      statusFilter === "all" ||
      event.statusChanges.some(
        change =>
          change.after === statusFilter || change.before === statusFilter
      );
    const dateMatch =
      !dateFilter ||
      new Date(event.createdAt).toISOString().slice(0, 10) === dateFilter;
    return typeMatch && statusMatch && dateMatch;
  });
  return (
    <AppShell title={ledgerOnly ? "Change ledger" : "Activity history"}>
      <PageTitle
        title={
          ledgerOnly ? "Evidence Change Ledger" : "Assessment activity history"
        }
        subtitle={
          ledgerOnly
            ? "A durable, per-requirement record of what changed after each tracked commit."
            : "A record of saved assessment versions, repository events, and processing outcomes."
        }
      />
      <DataError error={dashboard.error ?? query.error} />
      <CurrentSelection
        jobs={jobs.map(job => ({ id: job.id, title: job.title }))}
        repositories={repositories.map(repo => ({
          id: repo.id,
          fullName: `${repo.repositoryOwner}/${repo.repositoryName}`,
        }))}
        jobId={jobId}
        repositoryId={repositoryId}
        onJob={setJobId}
        onRepository={setRepositoryId}
      />
      {!jobId || !repositoryId ? (
        <section className="card card-pad">
          <EmptyState
            title="Select a job and repository"
            description="History is isolated to a specific job and selected repository."
          />
        </section>
      ) : (
        <>
          {ledgerOnly && (
            <section className="card card-pad live-monitor-card">
              <div>
                <span className="section-label">REPOSITORY MONITORING</span>
                <h2>
                  {repositories.find(repo => repo.id === repositoryId)
                    ?.repositoryName ?? "Tracked repository"}
                </h2>
                <p>
                  Tracked branch{" "}
                  {repositories.find(repo => repo.id === repositoryId)
                    ?.branch ??
                    repositories.find(repo => repo.id === repositoryId)
                      ?.defaultBranch}{" "}
                  · latest observed{" "}
                  {compactSha(
                    repositories.find(repo => repo.id === repositoryId)
                      ?.latestObservedSha
                  )}{" "}
                  · last checked{" "}
                  {prettyDate(
                    repositories.find(repo => repo.id === repositoryId)
                      ?.lastSyncedAt
                  )}
                </p>
              </div>
              <StatusBadge
                status={
                  repositories.find(repo => repo.id === repositoryId)
                    ?.watcherStatus ?? "stale"
                }
              />
            </section>
          )}
          <div className="live-filter-row live-history-filters">
            <label>
              <span>Event state</span>
              <select
                value={eventFilter}
                onChange={event => setEventFilter(event.target.value)}
              >
                <option value="all">All events</option>
                <option value="detected">Detected</option>
                <option value="analyzing">Analyzing</option>
                <option value="completed">Completed</option>
                <option value="failed">Failed</option>
              </select>
            </label>
            <label>
              <span>Skill status</span>
              <select
                value={statusFilter}
                onChange={event => setStatusFilter(event.target.value)}
              >
                <option value="all">All statuses</option>
                <option value="demonstrated">Demonstrated</option>
                <option value="partial_or_needs_review">Partial</option>
                <option value="not_demonstrated_in_analyzed_scope">
                  Not demonstrated in scope
                </option>
                <option value="unable_to_assess">Unable to assess</option>
              </select>
            </label>
            <label>
              <span>Event date</span>
              <input
                type="date"
                value={dateFilter}
                onChange={event => setDateFilter(event.target.value)}
              />
            </label>
          </div>
          {ledgerOnly && entries.length === 0 ? (
            <section className="card card-pad">
              <EmptyState
                icon="help"
                title="No assessed repository changes yet"
                description="Once a commit on the tracked branch is detected and its assessment completes, its changed paths and per-skill before/after record will appear here. Unrelated changes may leave all skills unchanged."
              />
            </section>
          ) : !ledgerOnly && versions.length === 0 && entries.length === 0 ? (
            <section className="card card-pad">
              <EmptyState
                title="No activity has been recorded"
                description="Import a job and assess an authorized repository to create the first durable activity record."
              />
            </section>
          ) : (
            <div className="live-history-layout">
              <section className="live-timeline">
                {ledgerOnly && filtered.length === 0 ? (
                  <section className="card card-pad">
                    <EmptyState
                      title="No events match these filters"
                      description="Change the event state, skill status, or date filter."
                    />
                  </section>
                ) : (
                  filtered.map(event => (
                    <article className="card live-event-card" key={event.id}>
                      <div className="live-event-line">
                        <span className="live-event-icon">
                          <GitCommitHorizontal size={14} />
                        </span>
                        <div className="live-event-content">
                          <div className="live-event-head">
                            <div>
                              <span className="section-label">
                                {event.processingState.toUpperCase()} ·{" "}
                                {prettyDate(event.createdAt)}
                              </span>
                              <h3>
                                {event.commitMessage || "Repository commit"}
                              </h3>
                              <p>
                                <code>{compactSha(event.commitSha)}</code> ·{" "}
                                {event.branch}
                              </p>
                            </div>
                            <StatusBadge status={event.processingState} />
                          </div>
                          {event.errorMessage && (
                            <ErrorNotice>{event.errorMessage}</ErrorNotice>
                          )}
                          {event.changedFiles.length > 0 && (
                            <details className="changed-files">
                              <summary>
                                {event.changedFiles.length} changed paths
                              </summary>
                              <ul>
                                {event.changedFiles
                                  .slice(0, 50)
                                  .map((file, index) => (
                                    <li key={`${file.path}-${index}`}>
                                      <code>{file.path}</code>
                                      <span>{file.status}</span>
                                    </li>
                                  ))}
                              </ul>
                            </details>
                          )}
                          {event.statusChanges.length > 0 ? (
                            <div className="live-transition-list">
                              <b>Requirement changes</b>
                              {event.statusChanges.map((change, index) => (
                                <div
                                  className="live-transition"
                                  key={`${change.requirementId}-${index}`}
                                >
                                  <b>{change.skill}</b>
                                  <span>
                                    {change.before ?? "No prior assessment"}
                                  </span>
                                  <ArrowRight size={12} />
                                  <span>{change.after}</span>
                                  <small>{change.explanation}</small>
                                </div>
                              ))}
                            </div>
                          ) : event.processingState === "completed" ? (
                            <div className="live-unchanged">
                              <Check size={13} />
                              No requirement status changes recorded for this
                              commit.
                            </div>
                          ) : null}
                          <div className="live-event-foot">
                            <span>
                              {event.evidenceAdded} citations added ·{" "}
                              {event.evidenceRemoved} removed
                            </span>
                            <span>
                              Assessed commit{" "}
                              <code>{compactSha(event.commitSha)}</code>
                            </span>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))
                )}
              </section>
              {!ledgerOnly && (
                <aside className="card card-pad live-version-list">
                  <SectionTitle
                    title="Assessment versions"
                    subtitle="A failed version does not replace the last successful result."
                  />
                  {versions.map(version => (
                    <div className="live-version-row" key={version.id}>
                      <span className="live-version-dot" />
                      <div>
                        <b>Version {version.version}</b>
                        <small>
                          <code>{compactSha(version.commitSha)}</code> ·{" "}
                          {version.branch}
                        </small>
                        <small>
                          {prettyDate(version.completedAt ?? version.createdAt)}
                        </small>
                      </div>
                      <StatusBadge status={version.state} />
                    </div>
                  ))}
                </aside>
              )}
            </div>
          )}
          <div className="scope-callout">
            <ShieldCheck size={14} />
            <span>
              Assessment results remain tied to their source commit. Deleted or
              weakened code can remove or downgrade evidence; unrelated files do
              not automatically improve an unrelated skill.
            </span>
          </div>
        </>
      )}
    </AppShell>
  );
}

function RoadmapPage() {
  const {
    dashboard,
    jobs,
    repositories,
    jobId,
    repositoryId,
    setJobId,
    setRepositoryId,
  } = useSelections();
  const query = trpc.proofpath.assessment.latest.useQuery(
    { jobId: jobId ?? 0, repositoryId: repositoryId ?? 0 },
    {
      enabled: Boolean(jobId && repositoryId),
      refetchInterval: 15_000,
      refetchIntervalInBackground: false,
    }
  );
  const rows = (query.data?.skills ?? []).filter(
    skill => skill.status !== "demonstrated"
  );
  return (
    <AppShell title="Portfolio roadmap">
      <PageTitle
        title="Evidence-grounded next steps"
        subtitle="Suggestions are tied to requirements that your inspected portfolio does not yet demonstrate; they are not hiring guarantees."
      />
      <DataError error={dashboard.error ?? query.error} />
      <CurrentSelection
        jobs={jobs.map(job => ({ id: job.id, title: job.title }))}
        repositories={repositories.map(repo => ({
          id: repo.id,
          fullName: `${repo.repositoryOwner}/${repo.repositoryName}`,
        }))}
        jobId={jobId}
        repositoryId={repositoryId}
        onJob={setJobId}
        onRepository={setRepositoryId}
      />
      {!query.data ? (
        <section className="card card-pad">
          <EmptyState
            title="No assessment available"
            description="Complete a real portfolio assessment before building an evidence-grounded roadmap."
          />
        </section>
      ) : rows.length === 0 ? (
        <section className="card card-pad">
          <EmptyState
            title="No evidence gaps are recorded"
            description="Every requirement in this assessment is currently marked demonstrated. This is not a hiring outcome or a guarantee of full mastery."
          />
        </section>
      ) : (
        <section className="live-roadmap-list">
          {rows.map(skill => (
            <article className="card card-pad live-roadmap-card" key={skill.id}>
              <div className="live-roadmap-heading">
                <span className="live-step-number">
                  <Code2 size={15} />
                </span>
                <div>
                  <span className="section-label">
                    {skill.requirement?.priority} REQUIREMENT
                  </span>
                  <h2>{skill.requirement?.skill}</h2>
                </div>
                <StatusBadge status={skill.status} />
              </div>
              <p>{skill.explanation}</p>
              <div className="live-recommendation">
                <b>Possible portfolio improvement</b>
                <span>{skill.recommendation}</span>
              </div>
              <p className="muted small">
                Expected reassessment evidence depends on the code you choose to
                create and the new commit ProofPath can inspect.
              </p>
            </article>
          ))}
        </section>
      )}
    </AppShell>
  );
}

function ProfilePage() {
  const utils = trpc.useUtils();
  const account = trpc.auth.me.useQuery();
  const profile = trpc.proofpath.profile.current.useQuery();
  const history = trpc.proofpath.profile.history.useQuery();
  const resumes = trpc.proofpath.resume.list.useQuery();
  const jobs = trpc.proofpath.jobs.list.useQuery();
  const [firstResumeId, setFirstResumeId] = useState<number>();
  const [secondResumeId, setSecondResumeId] = useState<number>();
  const [compareJobId, setCompareJobId] = useState<number>();
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    displayName: "", headline: "", targetRole: "", location: "", bio: "",
    websiteUrl: "", linkedinUrl: "", githubUrl: "",
  });
  useEffect(() => {
    if (profile.data) setForm({
      displayName: profile.data.displayName ?? "",
      headline: profile.data.headline ?? "",
      targetRole: profile.data.targetRole ?? "",
      location: profile.data.location ?? "",
      bio: profile.data.bio ?? "",
      websiteUrl: profile.data.websiteUrl ?? "",
      linkedinUrl: profile.data.linkedinUrl ?? "",
      githubUrl: profile.data.githubUrl ?? "",
    });
  }, [profile.data]);
  useEffect(() => {
    const items = resumes.data ?? [];
    if (!firstResumeId && items[0]) setFirstResumeId(items[0].id);
    if (!secondResumeId && items[1]) setSecondResumeId(items[1].id);
    if (!compareJobId && jobs.data?.[0]) setCompareJobId(jobs.data[0].id);
  }, [resumes.data, jobs.data, firstResumeId, secondResumeId, compareJobId]);
  const update = trpc.proofpath.profile.update.useMutation({
    onSuccess: async () => {
      setSaved(true);
      await utils.proofpath.profile.current.invalidate();
    },
  });
  const comparison = trpc.proofpath.resume.compare.useQuery({
    firstResumeId: firstResumeId ?? 0,
    secondResumeId: secondResumeId ?? 0,
    jobId: compareJobId ?? 0,
  }, { enabled: Boolean(firstResumeId && secondResumeId && compareJobId && firstResumeId !== secondResumeId) });
  const setField = (key: keyof typeof form, value: string) => {
    setSaved(false);
    setForm(current => ({ ...current, [key]: value }));
  };
  const submit = () => update.mutate({
    displayName: form.displayName.trim() || null,
    headline: form.headline.trim() || null,
    targetRole: form.targetRole.trim() || null,
    location: form.location.trim() || null,
    bio: form.bio.trim() || null,
    websiteUrl: form.websiteUrl.trim() || null,
    linkedinUrl: form.linkedinUrl.trim() || null,
    githubUrl: form.githubUrl.trim() || null,
    resumeContextEnabled: profile.data?.resumeContextEnabled ?? true,
  });
  const field = (key: keyof typeof form, label: string, placeholder = "") => (
    <label className="live-field" key={key}>
      <span>{label}</span>
      <input value={form[key]} placeholder={placeholder} onChange={event => setField(key, event.target.value)} />
    </label>
  );
  const v1Skills = new Set(comparison.data?.first.parsedProfile.technicalSkills.map(item => item.toLowerCase()) ?? []);
  const v2Skills = new Set(comparison.data?.second.parsedProfile.technicalSkills.map(item => item.toLowerCase()) ?? []);
  const addedSkills = [...v2Skills].filter(skill => !v1Skills.has(skill));
  const removedSkills = [...v1Skills].filter(skill => !v2Skills.has(skill));
  return (
    <AppShell title="Profile">
      <PageTitle title="Your profile" subtitle="Edit personal details and review your own resume and assessment history. Account identity is shown separately from editable profile details." />
      <DataError error={profile.error ?? account.error ?? history.error ?? resumes.error ?? jobs.error} />
      <div className="settings-stack">
        <section className="card card-pad">
          <SectionTitle title="Account identity" subtitle="Provided by your signed-in Manus account; this is not an editable or independently verified identity." />
          <div className="settings-value"><span>Account name</span><b>{account.data?.name || "Not provided"}</b></div>
          <div className="settings-value"><span>Email</span><b>{account.data?.email || "Not provided"}</b></div>
        </section>
        <section className="card card-pad">
          <SectionTitle title="Personal details" subtitle="These details belong only to your ProofPath account and are not shared as an employer profile." />
          <div className="live-selection">
            {field("displayName", "Display name", "Name shown in your workspace")}
            {field("headline", "Headline", "e.g. Computer science student")}
            {field("targetRole", "Target role", "e.g. Backend developer")}
            {field("location", "Location", "City or region")}
          </div>
          <label className="live-field"><span>About you</span><textarea value={form.bio} maxLength={1000} rows={4} onChange={event => setField("bio", event.target.value)} /></label>
          <div className="live-selection">
            {field("websiteUrl", "Website", "https://")}
            {field("linkedinUrl", "LinkedIn", "https://linkedin.com/in/…")}
            {field("githubUrl", "GitHub", "https://github.com/…")}
          </div>
          <div className="live-actions"><button className="button button-primary" disabled={update.isPending} onClick={submit}>{update.isPending ? "Saving…" : "Save profile"}</button>{saved && <span className="live-success"><Check size={14} />Saved</span>}</div>
          {update.error && <ErrorNotice>{update.error.message}</ErrorNotice>}
        </section>
        <section className="card card-pad">
          <SectionTitle title="Resume version comparison" subtitle="Compare retrieved passages from two of your own resume versions against one saved job. These are self-reported context, not code evidence." />
          <div className="live-selection">
            <label className="live-field"><span>Earlier version</span><select value={firstResumeId ?? ""} onChange={event => setFirstResumeId(Number(event.target.value) || undefined)}><option value="">Choose resume</option>{(resumes.data ?? []).map(item => <option key={item.id} value={item.id}>{item.originalName} · {prettyDate(item.uploadedAt)}</option>)}</select></label>
            <label className="live-field"><span>Later version</span><select value={secondResumeId ?? ""} onChange={event => setSecondResumeId(Number(event.target.value) || undefined)}><option value="">Choose resume</option>{(resumes.data ?? []).map(item => <option key={item.id} value={item.id}>{item.originalName} · {prettyDate(item.uploadedAt)}</option>)}</select></label>
            <label className="live-field"><span>Compare against job</span><select value={compareJobId ?? ""} onChange={event => setCompareJobId(Number(event.target.value) || undefined)}><option value="">Choose job</option>{(jobs.data ?? []).map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
          </div>
          {resumes.data && resumes.data.length < 2 ? <p className="muted">Upload a second resume version to compare changes.</p> : null}
          {comparison.error && <ErrorNotice>{comparison.error.message}</ErrorNotice>}
          {comparison.data && <>
            <p><b>Profile changes:</b> {addedSkills.length ? `Added: ${addedSkills.join(", ")}. ` : "No new extracted skills. "}{removedSkills.length ? `No longer listed: ${removedSkills.join(", ")}.` : "No extracted skills removed."}</p>
            {comparison.data.requirements.map(requirement => <div className="resume-review-section" key={requirement.id}><b>{requirement.skill}</b><p className="muted">{requirement.originalWording}</p><div className="live-selection"><div><small>Earlier resume</small>{requirement.firstMatches.length ? requirement.firstMatches.map(item => <blockquote key={item.chunkId}>Resume passage {item.chunkIndex + 1} · relevance {item.score}<br />{item.text}</blockquote>) : <p className="muted">No relevant passage retrieved.</p>}</div><div><small>Later resume</small>{requirement.secondMatches.length ? requirement.secondMatches.map(item => <blockquote key={item.chunkId}>Resume passage {item.chunkIndex + 1} · relevance {item.score}<br />{item.text}</blockquote>) : <p className="muted">No relevant passage retrieved.</p>}</div></div></div>)}
          </>}
        </section>
        <section className="card card-pad">
          <SectionTitle title="Your activity history" subtitle="Only records associated with your signed-in account are shown." />
          {history.isLoading ? <LoadingBlock /> : history.data?.length ? history.data.map(item => <div className="settings-value" key={item.id}><span>{item.title}<small>{item.detail}</small></span><b>{prettyDate(item.occurredAt)}</b></div>) : <p className="muted">No resume or assessment activity yet. Your history will appear here as you use ProofPath.</p>}
        </section>
      </div>
    </AppShell>
  );
}

function SettingsPage() {
  const utils = trpc.useUtils();
  const dashboard = trpc.proofpath.dashboard.useQuery();
  const status = trpc.proofpath.github.status.useQuery();
  const resume = trpc.proofpath.resume.latest.useQuery();
  const profile = trpc.proofpath.profile.current.useQuery();
  const repositories = dashboard.data?.repositories ?? [];
  const remove = trpc.proofpath.resume.remove.useMutation({
    onSuccess: async () => {
      await resume.refetch();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const pause = trpc.proofpath.github.pause.useMutation({
    onSuccess: async () => {
      await utils.proofpath.github.repositories.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const resumeMonitoring = trpc.proofpath.github.select.useMutation({
    onSuccess: async () => {
      await utils.proofpath.github.repositories.invalidate();
      await utils.proofpath.dashboard.invalidate();
    },
  });
  const savePrivacy = trpc.proofpath.profile.update.useMutation({
    onSuccess: async () => { await utils.proofpath.profile.current.invalidate(); },
  });
  return (
    <AppShell title="Privacy & connections">
      <PageTitle
        title="Privacy and connections"
        subtitle="Your records stay private to your account. Change resume use and repository monitoring here; edit personal details in Profile."
      />
      <DataError error={dashboard.error ?? status.error ?? resume.error ?? profile.error} />
      <div className="settings-stack">
        <section className="card card-pad">
          <SectionTitle
            title="Account"
            subtitle="The existing Manus sign-in is used for this workspace."
          />
          <div className="settings-value">
            <span>GitHub account</span>
            <b>
              {status.data?.connected
                ? "GitHub account connected"
                : "Not connected"}
            </b>
          </div>
          <div className="settings-value">
            <span>Connection status</span>
            <b>{status.data?.status ?? "Not connected"}</b>
          </div>
          <a className="button button-outline button-small" href="/student/profile">Edit personal details in Profile</a>
          {status.data?.configured && !status.data.connected && (
            <button
              className="button button-outline button-small"
              onClick={() => {
                window.location.href = "/api/github/connect";
              }}
            >
              Authorize GitHub
            </button>
          )}
          {!status.data?.configured && (
            <p className="muted small">
              Public repository links work without a GitHub App. App authorization is optional and only needed for private repositories.
            </p>
          )}
          {status.data?.connected && (
            <p className="muted small">
              <a
                href="https://github.com/settings/installations"
                target="_blank"
                rel="noreferrer"
              >
                Review or revoke ProofPath access in GitHub settings{" "}
                <ArrowUpRight size={11} />
              </a>
            </p>
          )}
        </section>
        <section className="card card-pad">
          <SectionTitle title="Resume context" subtitle="Choose whether your latest resume is included as supporting context in future assessments. It never proves a demonstrated skill." />
          <label className="settings-value" style={{ cursor: "pointer" }}>
            <span>Use my resume for future assessments</span>
            <input
              type="checkbox"
              checked={profile.data?.resumeContextEnabled ?? true}
              disabled={!profile.data || savePrivacy.isPending}
              onChange={event => {
                const current = profile.data;
                if (!current) return;
                savePrivacy.mutate({
                  displayName: current.displayName,
                  headline: current.headline,
                  targetRole: current.targetRole,
                  location: current.location,
                  bio: current.bio,
                  websiteUrl: current.websiteUrl,
                  linkedinUrl: current.linkedinUrl,
                  githubUrl: current.githubUrl,
                  resumeContextEnabled: event.target.checked,
                });
              }}
            />
          </label>
          {savePrivacy.error && <ErrorNotice>{savePrivacy.error.message}</ErrorNotice>}
          <p className="muted small">Applies to assessments started after the setting is saved. Previously saved history is unchanged.</p>
        </section>
        <section className="card card-pad">
          <SectionTitle
            title="Selected repositories"
            subtitle="Pause a repository to stop polling and future assessment queueing."
          />
          {repositories.length ? (
            repositories.map(repo => (
              <div className="live-repo-row" key={repo.id}>
                <GitFork size={16} />
                <div>
                  <b>
                    {repo.repositoryOwner}/{repo.repositoryName}
                  </b>
                  <small>
                    Tracked {repo.branch ?? repo.defaultBranch} ·{" "}
                    {repo.watcherStatus}
                  </small>
                </div>
                <button
                  className="button button-outline button-small"
                  disabled={pause.isPending || resumeMonitoring.isPending}
                  onClick={() =>
                    repo.selected
                      ? pause.mutate({ repositoryId: repo.id })
                      : resumeMonitoring.mutate({
                          repositoryId: repo.id,
                          branch: repo.branch ?? repo.defaultBranch,
                        })
                  }
                >
                  {repo.selected ? "Pause monitoring" : "Resume monitoring"}
                </button>
              </div>
            ))
          ) : (
            <p className="muted">No repository has been selected.</p>
          )}
          {pause.error && <ErrorNotice>{pause.error.message}</ErrorNotice>}
          {resumeMonitoring.error && (
            <ErrorNotice>{resumeMonitoring.error.message}</ErrorNotice>
          )}
        </section>
        <section className="card card-pad">
          <SectionTitle
            title="Resume"
            subtitle="Only structured extracted context is displayed in this workspace."
          />
          {resume.data ? (
            <div className="settings-value">
              <span>{resume.data.originalName}</span>
              <button
                className="button button-danger button-small"
                disabled={remove.isPending}
                onClick={() => {
                  if (
                    window.confirm(
                      "Remove this resume, its encrypted original, extracted profile, and RAG passages from your ProofPath account? Assessment history will remain without resume context."
                    )
                  )
                    remove.mutate({ id: resume.data!.id });
                }}
              >
                Remove resume
              </button>
            </div>
          ) : (
            <p className="muted">No resume is stored.</p>
          )}
          {remove.error && <ErrorNotice>{remove.error.message}</ErrorNotice>}
        </section>
        <section className="card card-pad">
          <SectionTitle title="Assessment limitations" />
          <ul className="privacy-list">
            <li>Repository code is never executed by ProofPath.</li>
            <li>
              A resume mention is unverified context, not proof of technical
              ability.
            </li>
            <li>
              Only recorded source files and line ranges support assessment
              claims.
            </li>
            <li>
              “Not demonstrated in this scope” does not mean that you lack the
              skill.
            </li>
            <li>
              Assessments do not predict hiring, placement, or complete mastery.
            </li>
            <li>
              Job and repository contents are sent to the configured analysis
              service for extraction and assessment.
            </li>
          </ul>
          <div className="scope-callout">
            <LockKeyhole size={14} />
            <span>
              Never place API keys or private credentials in your job
              description or repository. Candidate and cohort data is not shared
              with organization workspaces.
            </span>
          </div>
        </section>
      </div>
    </AppShell>
  );
}

export default function StudentPages() {
  const [, params] = useRoute("/student/:page");
  const page = params?.page;
  if (page === "setup") return <SetupPage />;
  if (page === "assessment") return <AssessmentPage />;
  if (page === "evidence") return <EvidencePage />;
  if (page === "ledger") return <HistoryPage ledgerOnly />;
  if (page === "activity") return <HistoryPage />;
  if (page === "roadmap") return <RoadmapPage />;
  if (page === "profile") return <ProfilePage />;
  if (page === "settings") return <SettingsPage />;
  if (page === "dashboard") return <DashboardPage />;
  return (
    <AppShell title="Page not found">
      <PageTitle
        title="Page not found"
        subtitle="This student workspace page is not part of ProofPath."
      />
      <EmptyState
        title="Choose a workspace page"
        description="Use the workspace navigation to open one of the available pages."
      />
    </AppShell>
  );
}
