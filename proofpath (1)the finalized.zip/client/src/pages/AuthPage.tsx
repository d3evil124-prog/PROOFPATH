import { ArrowLeft, GitFork, ShieldCheck } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function AuthPage({ mode = "login" }: { mode?: "login" | "signup" | "not-found" }) {
  const [, setPath] = useLocation();
  const auth = useAuth();
  const [loginError, setLoginError] = useState("");
  useEffect(() => { if (auth.user && mode !== "not-found") setPath("/student/dashboard"); }, [auth.user, mode, setPath]);
  const title = mode === "signup" ? "Create your ProofPath account" : mode === "not-found" ? "Page not found" : "Sign in to ProofPath";
  const description = mode === "not-found"
    ? "That page is not available. Return to ProofPath or open your workspace."
    : "Use your Manus account to open your private workspace. Your submitted job, resume and selected repository are not shared with other users.";
  return (
    <main className="entry-page">
      <div className="entry-orb entry-orb-one" /><div className="entry-orb entry-orb-two" />
      <div className="entry-top"><Link href="/" className="brand"><span className="brand-symbol"><GitFork size={16} /><i /></span><span>proofpath</span></Link><Link href="/" className="text-button"><ArrowLeft size={13} />Back to home</Link></div>
      <section className="entry-card">
        <div className="entry-mark"><GitFork size={20} /></div>
        <span className="eyebrow">PRIVATE PORTFOLIO WORKSPACE</span>
        <h1>{title}</h1><p className="entry-desc">{description}</p>
        {mode !== "not-found" ? <>
          <div className="entry-alert"><ShieldCheck size={15} /><span>ProofPath uses the existing Manus sign-in. GitHub is a separate authorization that you initiate only when connecting a repository.</span></div>
          <button className="button button-primary auth-continue" disabled={auth.loading} onClick={() => { try { setLoginError(""); startLogin(); } catch (error) { setLoginError(error instanceof Error ? error.message : "Manus sign-in is unavailable."); } }}>{auth.loading ? "Checking session…" : "Continue with Manus"}</button>
          {loginError && <div className="live-error" role="alert">{loginError}</div>}
          {mode === "login" ? <p className="auth-secondary">New to ProofPath? <Link href="/signup">Create an account</Link></p> : <p className="auth-secondary">Already have a workspace? <Link href="/login">Sign in</Link></p>}
        </> : <button className="button button-primary auth-continue" onClick={() => setPath("/")}>Return to ProofPath</button>}
        <div className="entry-bottom"><span>Evidence is not a hiring verdict.</span><span>ProofPath · 2026</span></div>
      </section>
    </main>
  );
}
