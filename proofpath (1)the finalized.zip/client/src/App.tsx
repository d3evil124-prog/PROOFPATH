import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import LandingPage from "./pages/LandingPage";
import StudentPages from "./pages/StudentPages";
import TeamPages from "./pages/TeamPages";
import AuthPage from "./pages/AuthPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={() => <AuthPage mode="login" />} />
      <Route path="/signup" component={() => <AuthPage mode="signup" />} />

      <Route path="/student/dashboard" component={StudentPages} />
      <Route path="/student/setup" component={StudentPages} />
      <Route path="/student/assessment" component={StudentPages} />
      <Route path="/student/evidence" component={StudentPages} />
      <Route path="/student/activity" component={StudentPages} />
      <Route path="/student/ledger" component={StudentPages} />
      <Route path="/student/roadmap" component={StudentPages} />
      <Route path="/student/profile" component={StudentPages} />
      <Route path="/student/settings" component={StudentPages} />

      <Route path="/recruiter/dashboard" component={TeamPages} />
      <Route path="/recruiter/candidates" component={TeamPages} />
      <Route path="/recruiter/candidates/:id" component={TeamPages} />
      <Route path="/recruiter/roles" component={TeamPages} />
      <Route path="/recruiter/settings" component={TeamPages} />

      <Route path="/tpo/dashboard" component={TeamPages} />
      <Route path="/tpo/students" component={TeamPages} />
      <Route path="/tpo/readiness" component={TeamPages} />
      <Route path="/tpo/reports" component={TeamPages} />
      <Route path="/tpo/settings" component={TeamPages} />

      <Route component={() => <AuthPage mode="not-found" />} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <Router />
    </ErrorBoundary>
  );
}
