import type { ReactNode } from "react";
import { AlertTriangle, Check, CircleHelp, X } from "lucide-react";
import type { AssessmentStatus, OperationalState } from "@/types/domain";

export function StatusBadge({
  status,
  label,
}: {
  status:
    | AssessmentStatus
    | OperationalState
    | "active"
    | "paused"
    | "detected"
    | "analyzing"
    | "failed"
    | "stale";
  label?: string;
}) {
  const map: Record<string, { text: string; cls: string; mark: string }> = {
    demonstrated: { text: "Demonstrated", cls: "status-verified", mark: "✓" },
    partial_or_needs_review: {
      text: "Partial · needs review",
      cls: "status-partial",
      mark: "◐",
    },
    not_demonstrated_in_analyzed_scope: {
      text: "Not in inspected scope",
      cls: "status-missing",
      mark: "—",
    },
    unable_to_assess: {
      text: "Unable to assess",
      cls: "status-unknown",
      mark: "?",
    },
    completed: { text: "Completed", cls: "status-verified", mark: "✓" },
    running: { text: "Analyzing", cls: "status-partial", mark: "◌" },
    analyzing: { text: "Analyzing", cls: "status-partial", mark: "◌" },
    queued: { text: "Queued", cls: "status-unknown", mark: "·" },
    failed: { text: "Failed", cls: "status-error", mark: "!" },
    stale: { text: "Stale", cls: "status-partial", mark: "◷" },
    detected: { text: "Detected", cls: "status-unknown", mark: "·" },
    active: { text: "Monitoring active", cls: "status-verified", mark: "●" },
    paused: { text: "Paused", cls: "status-unknown", mark: "Ⅱ" },
  };
  const item = map[status] ?? map.unable_to_assess;
  return (
    <span className={`status ${item.cls}`} aria-label={label ?? item.text}>
      <span aria-hidden="true">{item.mark}</span>
      {label ?? item.text}
    </span>
  );
}
export function PageTitle({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="page-title-row">
      <div>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {action && <div className="page-actions">{action}</div>}
    </div>
  );
}
export function SectionTitle({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="card-title">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
export function Modal({
  title,
  subtitle,
  onClose,
  children,
  wide = false,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={e => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section
        className="modal"
        style={wide ? { width: "min(760px,100%)" } : undefined}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="modal-header">
          <div>
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Close dialog"
          >
            <X size={15} />
          </button>
        </div>
        <div style={{ marginTop: 17 }}>{children}</div>
      </section>
    </div>
  );
}
export function Drawer({
  title,
  subtitle,
  eyebrow,
  onClose,
  children,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} aria-hidden="true" />
      <aside
        className="drawer"
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="drawer-header">
          <div>
            {eyebrow && <div className="section-label">{eyebrow}</div>}
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Close evidence panel"
          >
            <X size={15} />
          </button>
        </div>
        {children}
      </aside>
    </>
  );
}
export function EmptyState({
  title,
  description,
  action,
  icon = "info",
}: {
  title: string;
  description: string;
  action?: ReactNode;
  icon?: "info" | "help" | "warning";
}) {
  const Icon =
    icon === "warning" ? AlertTriangle : icon === "help" ? CircleHelp : Check;
  return (
    <div className="empty-state">
      <span className="empty-icon">
        <Icon size={17} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}
export function ProgressBar({
  value,
  label,
}: {
  value: number;
  label: string;
}) {
  return (
    <div aria-label={`${label}: ${value}%`}>
      <div className="meter">
        <span style={{ width: `${Math.max(0, Math.min(value, 100))}%` }} />
      </div>
    </div>
  );
}
