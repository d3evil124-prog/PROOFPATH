import { useState } from "react";
import { Activity, BookOpenCheck, ChevronRight, Code2, FileCheck2, FileClock, GitFork, LayoutDashboard, Menu, Settings2, ShieldCheck, UserRound, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import type { ReactNode } from "react";
import { useAuth } from "@/_core/hooks/useAuth";

const items = [
  { path: "/student/dashboard", name: "Overview", icon: LayoutDashboard },
  { path: "/student/setup", name: "Portfolio setup", icon: GitFork },
  { path: "/student/assessment", name: "Skill assessment", icon: FileCheck2 },
  { path: "/student/evidence", name: "Evidence inspector", icon: Code2 },
  { path: "/student/ledger", name: "Change ledger", icon: FileClock },
  { path: "/student/activity", name: "Activity history", icon: Activity },
  { path: "/student/roadmap", name: "Portfolio roadmap", icon: BookOpenCheck },
  { path: "/student/profile", name: "Profile", icon: UserRound },
  { path: "/student/settings", name: "Privacy & connections", icon: Settings2 },
];

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]?.toUpperCase() ?? "").join("") || "U";
}

export function AppShell({ title, children }: { title: string; children: ReactNode }) {
  const [path, setPath] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const auth = useAuth({ redirectOnUnauthenticated: true });
  const fullName = auth.user?.name?.trim() || auth.user?.email || "Your account";
  const mark = initials(fullName);

  if (auth.loading || !auth.user) {
    return <main className="auth-loading" aria-live="polite"><span className="loading-spinner" />Checking your ProofPath session…</main>;
  }

  const closeMenu = () => setMobileOpen(false);
  return (
    <div className="app-shell">
      <div className={`mobile-overlay ${mobileOpen ? "open" : ""}`} onClick={closeMenu} aria-hidden="true" />
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`} aria-label="Student workspace">
        <div className="sidebar-brand">
          <Link href="/" className="brand"><span className="brand-symbol"><GitFork size={16} /><i /></span><span>proofpath</span></Link>
        </div>
        <div className="workspace-label">Your workspace</div>
        <div className="account-workspace"><span className="role-avatar">{mark}</span><span className="role-switch-info"><b>Portfolio evidence</b><small>Private to your account</small></span></div>
        <nav className="sidebar-nav" aria-label="Student navigation">
          {items.map(({ path: itemPath, name, icon: Icon }) => (
            <Link key={itemPath} href={itemPath} className={`sidebar-link ${path === itemPath ? "active" : ""}`} onClick={closeMenu}>
              <Icon size={15} />{name}
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-note"><b><ShieldCheck size={12} style={{ verticalAlign: "-2px", marginRight: 4 }} />Evidence, not a verdict</b><p>A gap in inspected scope is not proof that a skill is absent.</p></div>
          <div className="profile-chip"><span className="avatar">{mark}</span><div><b>{fullName}</b><small>{auth.user.email || "Signed in"}</small></div><ChevronRight size={13} style={{ marginLeft: "auto", color: "#9aa3b2" }} /></div>
        </div>
      </aside>
      <div className="shell-main">
        <div className="mobile-top">
          <button onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? "Close menu" : "Open menu"}>{mobileOpen ? <X size={16} /> : <Menu size={16} />}</button>
          <Link href="/" className="brand"><span className="brand-symbol"><GitFork size={14} /><i /></span><span>proofpath</span></Link>
        </div>
        <header className="topbar">
          <div className="breadcrumb"><Link href="/student/dashboard">Workspace</Link><span>/</span><b>{title}</b></div>
          <div className="topbar-actions"><span className="pill pill-teal"><span className="dot" />Private workspace</span><button className="text-button" onClick={async () => { await auth.logout(); setPath("/"); }}>Sign out</button><button className="topbar-avatar" onClick={() => setPath("/student/profile")} aria-label="Open profile">{mark}</button></div>
        </header>
        <main className="app-content">
          {children}
          <div className="app-footnote"><ShieldCheck size={12} /> ProofPath evaluates inspected portfolio evidence—not complete mastery or hiring outcomes.</div>
        </main>
      </div>
    </div>
  );
}
