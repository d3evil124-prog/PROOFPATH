import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = { children: ReactNode };
type State = { error: Error | null };

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[ProofPath] UI error", error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <main className="entry-page">
        <section className="entry-card" role="alert">
          <span className="eyebrow">PROOFPath WORKSPACE ERROR</span>
          <h1>Something interrupted this view.</h1>
          <p className="entry-desc">Refresh the page and try again. No assessment result was changed by this display error.</p>
          <button className="button button-primary" onClick={() => window.location.reload()}>Refresh ProofPath</button>
        </section>
      </main>
    );
  }
}
