export const COOKIE_NAME = "webdev_app_session";
export const OAUTH_STATE_COOKIE = "__Host-manus_oauth_state";
export const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;
export const AXIOS_TIMEOUT_MS = 10_000;
export const UNAUTHED_ERR_MSG = "UNAUTHORIZED";
export const NOT_ADMIN_ERR_MSG = "FORBIDDEN";

type OAuthState = { redirectUri: string; nonce: string };

function encodeBase64Url(value: string): string {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return globalThis.btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/g, "");
}

function decodeBase64Url(value: string): string {
  const padded = value.replaceAll("-", "+").replaceAll("_", "/") + "=".repeat((4 - (value.length % 4)) % 4);
  const binary = globalThis.atob(padded);
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

export function encodeOAuthState(state: OAuthState): string {
  return encodeBase64Url(JSON.stringify(state));
}

export function decodeOAuthState(value: string): OAuthState {
  const parsed: unknown = JSON.parse(decodeBase64Url(value));
  if (!parsed || typeof parsed !== "object") throw new Error("Invalid OAuth state");
  const state = parsed as Partial<OAuthState>;
  if (typeof state.redirectUri !== "string" || typeof state.nonce !== "string") {
    throw new Error("Invalid OAuth state");
  }
  return { redirectUri: state.redirectUri, nonce: state.nonce };
}
