# ProofPath delivery outcomes

Validation status: the restored app, managed database migration sequence, TypeScript diagnostics, supplied tests, production build, Preview routes, and production-runtime health path have been verified. External OAuth/GitHub/LLM flows remain configuration-dependent and are not claimed as end-to-end tested.

- [x] **Restore and run the supplied full-stack application.** Import the attached archive without replacing it with a simplified mockup. The frontend, backend, database schema/migrations, authentication, API routes, workers, assets, and every supplied function must be present under the intended project structure and be runnable through the managed server.

- [ ] **Authenticated persistence and ownership isolation.** Use the existing Express/tRPC, Manus OAuth, Drizzle and MySQL architecture. Persist product records instead of using frontend state or hardcoded arrays as the source of truth. Enforce backend authorization and owner-scoped access for jobs, resumes, repositories, assessments, evidence, events, settings, and profile data. Do not seed fake product records.

- [ ] **Public job URL import and requirement review.** Allow a real job posting URL or exact pasted text. Fetch and parse only permitted public pages, extract technical skills/tools/qualifications, let the user review requirements, preserve source URL and retrieval time, and handle inaccessible or malformed sources without inventing or silently substituting a job.

- [ ] **Resume upload, encryption, extraction, storage, review, and removal.** Support PDF and DOCX uploads with the supplied 5 MiB validation and bounded extraction. Extract technical skills, projects, experience, education, and certifications; show progress and useful failures; let the user review extracted information; store encrypted original/profile/chunks in owner-scoped database rows; and remove those rows safely. Resume information is supporting context, not automatic skill proof, and the platform session secret is used without asking the user for another key.

- [ ] **Public GitHub URL verification and code inspection without a required GitHub App.** Accept canonical public GitHub repository URLs, verify owner/repository through the unauthenticated GitHub API, reject private/nonexistent repositories, list branches, require explicit repository/branch selection, persist owner-scoped public-link access, and use exact-commit inspection without executing repository contents or implicitly reusing another OAuth token. Explain that a URL verifies public reachability, not uploader identity or ownership.

- [ ] **Evidence-based assessment and history.** Compare confirmed job requirements with resume context and selected repository code. Identify demonstrated, insufficient, and unavailable evidence; show exact repository/branch/commit/path/line citations where available; distinguish resume mentions from code proof; explain uncertainty and next evidence; preserve “Not demonstrated in this scope” semantics; and never fabricate findings, paths, commits, citations, or explanations.

- [ ] **Change detection and resilient processing.** Preserve webhook support where configured plus honest public-link polling fallback. Detect changed commits/files, reassess affected requirements, save commit-linked versions, update history, handle duplicates/rate limits/retries/failures/stale states, use durable lease/idempotency behavior, and retain the last successful assessment when a source or model fails.

- [ ] **Resume RAG and same-user version comparison.** Persist bounded encrypted chunks per resume version, retrieve relevant passages per confirmed requirement, supply them only as unverified supporting context, allow comparison of two same-user resume versions against a selected job, show passage provenance and extracted-profile additions/removals, and honor the resume-context preference without exposing another user’s data.

- [ ] **Editable profile and history.** Provide `/student/profile`, an explicit navigation entry, authenticated account identity separate from editable values, editable display name/headline/target role/location/bio/HTTPS links, validation and owner-scoped persistence, plus resume/assessment/commit history and same-user comparison.

- [ ] **Interactive privacy and connections.** Keep profile editing separate from settings. Provide resume-context enable/disable, public repository status, monitoring pause/resume, resume history/removal, saved/error/empty states, private-by-default explanations, and destructive-action safeguards. Do not present unauthorized organization sharing as available.

- [ ] **Honest public job-source intake.** Support public listing URLs from AICTE, Internshala, Naukri, or compatible sites through the supplied SSRF-safe bounded importer; preserve exact attribution and retrieval time; provide pasted-description fallback; and do not log into external accounts, bypass CAPTCHAs/anti-bot protections/paywalls, or claim certification that was not verified.

- [ ] **Product-relevant landing treatment.** Preserve the supplied low-contrast evidence-path landing animation with readable foreground, fallback behavior, reduced-motion support, and no unrelated artwork or heavy dependency.

- [x] **Documentation, migrations, diagnostics, tests, and build.** Keep the supplied README/API/setup/security/runtime documentation, `.env.example`, schema/migrations, route manifest, and source assets. Run diagnostics, `pnpm check`, supplied tests, production build, `git diff --check`, health/route-manifest checks, and an independent authorization/data-flow review. Do not claim third-party end-to-end tests unless they were actually run.
