import {
  bigint,
  boolean,
  index,
  int,
  json,
  longtext,
  mysqlEnum,
  mysqlTable,
  timestamp,
  text,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the existing Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const userProfiles = mysqlTable(
  "user_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    displayName: varchar("displayName", { length: 120 }),
    headline: varchar("headline", { length: 160 }),
    targetRole: varchar("targetRole", { length: 160 }),
    location: varchar("location", { length: 120 }),
    bio: varchar("bio", { length: 1000 }),
    websiteUrl: varchar("websiteUrl", { length: 2048 }),
    linkedinUrl: varchar("linkedinUrl", { length: 2048 }),
    githubUrl: varchar("githubUrl", { length: 2048 }),
    resumeContextEnabled: boolean("resumeContextEnabled").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("user_profiles_owner_uq").on(table.ownerId)],
);

export const jobPostings = mysqlTable(
  "job_postings",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    sourceKind: mysqlEnum("sourceKind", ["fetched", "pasted"]).notNull(),
    sourceUrl: varchar("sourceUrl", { length: 2048 }),
    retrievedAt: timestamp("retrievedAt"),
    title: varchar("title", { length: 255 }).notNull(),
    company: varchar("company", { length: 255 }),
    description: longtext("description").notNull(),
    extractionStatus: mysqlEnum("extractionStatus", ["needs_review", "confirmed"]).default("needs_review").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("job_postings_owner_updated_idx").on(table.ownerId, table.updatedAt)],
);

export const jobRequirements = mysqlTable(
  "job_requirements",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    jobId: int("jobId").notNull().references(() => jobPostings.id, { onDelete: "cascade" }),
    originalWording: varchar("originalWording", { length: 1000 }).notNull(),
    skill: varchar("skill", { length: 160 }).notNull(),
    skillKey: varchar("skillKey", { length: 180 }).notNull(),
    priority: mysqlEnum("priority", ["required", "preferred"]).default("required").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("job_requirements_owner_job_idx").on(table.ownerId, table.jobId)],
);

export type ResumeProfileData = {
  technicalSkills: string[];
  projects: { name: string; summary: string; technologies: string[] }[];
  experience: { title: string; organization: string; summary: string }[];
  education: { qualification: string; institution: string; summary: string }[];
  certifications: string[];
};

export const resumes = mysqlTable(
  "resumes",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    originalName: varchar("originalName", { length: 255 }).notNull(),
    mimeType: mysqlEnum("mimeType", ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]).notNull(),
    byteSize: int("byteSize", { unsigned: true }).notNull(),
    fileSha256: varchar("fileSha256", { length: 64 }).notNull(),
    encryptedObjectKey: varchar("encryptedObjectKey", { length: 255 }),
    encryptionSaltHex: varchar("encryptionSaltHex", { length: 32 }).notNull(),
    encryptedFile: longtext("encryptedFile"),
    profileCiphertext: longtext("profileCiphertext"),
    parsedProfile: json("parsedProfile").$type<ResumeProfileData>().notNull(),
    uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  },
  table => [index("resumes_owner_uploaded_idx").on(table.ownerId, table.uploadedAt)],
);

export const resumeChunks = mysqlTable(
  "resume_chunks",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    resumeId: int("resumeId").notNull().references(() => resumes.id, { onDelete: "cascade" }),
    chunkIndex: int("chunkIndex", { unsigned: true }).notNull(),
    encryptedContent: longtext("encryptedContent").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("resume_chunks_resume_index_uq").on(table.ownerId, table.resumeId, table.chunkIndex),
    index("resume_chunks_owner_resume_idx").on(table.ownerId, table.resumeId),
  ],
);

export const githubConnections = mysqlTable(
  "github_connections",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    githubUserId: bigint("githubUserId", { mode: "number", unsigned: true }).notNull(),
    login: varchar("login", { length: 100 }).notNull(),
    encryptedAccessToken: longtext("encryptedAccessToken").notNull(),
    encryptedRefreshToken: longtext("encryptedRefreshToken"),
    accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
    refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
    status: mysqlEnum("status", ["connected", "needs_reauthorization", "revoked"]).default("connected").notNull(),
    connectedAt: timestamp("connectedAt").defaultNow().notNull(),
    lastCheckedAt: timestamp("lastCheckedAt"),
  },
  table => [
    uniqueIndex("github_connections_owner_user_uq").on(table.ownerId, table.githubUserId),
    index("github_connections_owner_status_idx").on(table.ownerId, table.status),
  ],
);

export const githubInstallations = mysqlTable(
  "github_installations",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    connectionId: int("connectionId").notNull().references(() => githubConnections.id, { onDelete: "cascade" }),
    installationId: bigint("installationId", { mode: "number", unsigned: true }).notNull(),
    accountLogin: varchar("accountLogin", { length: 100 }).notNull(),
    accountType: varchar("accountType", { length: 32 }).notNull(),
    refreshedAt: timestamp("refreshedAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("github_install_owner_install_uq").on(table.ownerId, table.installationId),
    index("github_install_connection_idx").on(table.ownerId, table.connectionId),
  ],
);

export const githubRepositories = mysqlTable(
  "github_repositories",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    connectionId: int("connectionId").references(() => githubConnections.id, { onDelete: "cascade" }),
    installationRowId: int("installationRowId").references(() => githubInstallations.id, { onDelete: "cascade" }),
    githubRepositoryId: bigint("githubRepositoryId", { mode: "number", unsigned: true }).notNull(),
    repositoryOwner: varchar("repositoryOwner", { length: 100 }).notNull(),
    repositoryName: varchar("repositoryName", { length: 100 }).notNull(),
    defaultBranch: varchar("defaultBranch", { length: 255 }).notNull(),
    isPrivate: boolean("isPrivate").notNull(),
    accessMode: mysqlEnum("accessMode", ["github_app", "public_link"]).default("github_app").notNull(),
    authorized: boolean("authorized").default(false).notNull(),
    selected: boolean("selected").default(false).notNull(),
    branch: varchar("branch", { length: 255 }),
    latestObservedSha: varchar("latestObservedSha", { length: 40 }),
    lastSyncedAt: timestamp("lastSyncedAt"),
    nextPollAt: timestamp("nextPollAt"),
    watcherStatus: mysqlEnum("watcherStatus", ["active", "paused", "failed", "stale"]).default("active").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("github_repos_owner_external_uq").on(table.ownerId, table.githubRepositoryId),
    index("github_repos_owner_selected_idx").on(table.ownerId, table.selected),
    index("github_repos_owner_authorized_selected_idx").on(table.ownerId, table.authorized, table.selected),
    index("github_repos_due_poll_idx").on(table.watcherStatus, table.nextPollAt),
  ],
);

export const assessmentVersions = mysqlTable(
  "assessment_versions",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    jobId: int("jobId").notNull().references(() => jobPostings.id, { onDelete: "cascade" }),
    repositoryId: int("repositoryId").notNull().references(() => githubRepositories.id, { onDelete: "cascade" }),
    resumeId: int("resumeId").references(() => resumes.id, { onDelete: "set null" }),
    resumeContextUsed: boolean("resumeContextUsed").default(false).notNull(),
    version: int("version", { unsigned: true }).notNull(),
    branch: varchar("branch", { length: 255 }).notNull(),
    commitSha: varchar("commitSha", { length: 40 }).notNull(),
    state: mysqlEnum("state", ["queued", "running", "completed", "failed", "stale"]).default("queued").notNull(),
    filesInspected: int("filesInspected", { unsigned: true }).default(0).notNull(),
    filesExcluded: int("filesExcluded", { unsigned: true }).default(0).notNull(),
    testsDiscovered: boolean("testsDiscovered").default(false).notNull(),
    testsExecuted: boolean("testsExecuted").default(false).notNull(),
    scopeSummary: json("scopeSummary").$type<{ inspected: string[]; excluded: { path: string; reason: string }[]; truncated: boolean }>().notNull(),
    errorMessage: varchar("errorMessage", { length: 1000 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => [
    uniqueIndex("assessment_versions_owner_job_repo_version_uq").on(table.ownerId, table.jobId, table.repositoryId, table.version),
    uniqueIndex("assessment_versions_owner_job_repo_commit_uq").on(table.ownerId, table.jobId, table.repositoryId, table.commitSha),
    index("assessment_versions_owner_job_repo_idx").on(table.ownerId, table.jobId, table.repositoryId, table.createdAt),
    index("assessment_versions_repo_commit_idx").on(table.ownerId, table.repositoryId, table.commitSha),
  ],
);

export const skillAssessments = mysqlTable(
  "skill_assessments",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    assessmentId: int("assessmentId").notNull().references(() => assessmentVersions.id, { onDelete: "cascade" }),
    requirementId: int("requirementId").notNull().references(() => jobRequirements.id, { onDelete: "cascade" }),
    status: mysqlEnum("status", ["demonstrated", "partial_or_needs_review", "not_demonstrated_in_analyzed_scope", "unable_to_assess"]).notNull(),
    explanation: longtext("explanation").notNull(),
    resumeMentioned: boolean("resumeMentioned").default(false).notNull(),
    resumeSupport: varchar("resumeSupport", { length: 1000 }),
    resumeChunkIds: json("resumeChunkIds").$type<number[]>(),
    recommendation: varchar("recommendation", { length: 1000 }).notNull(),
    confidence: mysqlEnum("confidence", ["low", "medium", "high"]).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("skill_assessment_version_requirement_uq").on(table.ownerId, table.assessmentId, table.requirementId),
    index("skill_assessments_owner_version_idx").on(table.ownerId, table.assessmentId),
  ],
);

export const evidenceCitations = mysqlTable(
  "evidence_citations",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    skillAssessmentId: int("skillAssessmentId").notNull().references(() => skillAssessments.id, { onDelete: "cascade" }),
    repositoryId: int("repositoryId").notNull().references(() => githubRepositories.id, { onDelete: "cascade" }),
    commitSha: varchar("commitSha", { length: 40 }).notNull(),
    path: varchar("path", { length: 1000 }).notNull(),
    lineStart: int("lineStart", { unsigned: true }).notNull(),
    lineEnd: int("lineEnd", { unsigned: true }).notNull(),
    evidenceType: mysqlEnum("evidenceType", ["implementation", "test", "configuration", "documentation"]).notNull(),
    excerpt: longtext("excerpt").notNull(),
    explanation: varchar("explanation", { length: 1000 }).notNull(),
    confidence: mysqlEnum("confidence", ["medium", "high"]).notNull(),
  },
  table => [index("evidence_citations_owner_skill_idx").on(table.ownerId, table.skillAssessmentId)],
);

export const changeEvents = mysqlTable(
  "change_events",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    repositoryId: int("repositoryId").notNull().references(() => githubRepositories.id, { onDelete: "cascade" }),
    jobId: int("jobId").notNull().references(() => jobPostings.id, { onDelete: "cascade" }),
    assessmentId: int("assessmentId").references(() => assessmentVersions.id, { onDelete: "set null" }),
    previousSha: varchar("previousSha", { length: 40 }),
    commitSha: varchar("commitSha", { length: 40 }).notNull(),
    branch: varchar("branch", { length: 255 }).notNull(),
    commitMessage: varchar("commitMessage", { length: 500 }),
    processingState: mysqlEnum("processingState", ["detected", "analyzing", "completed", "failed"]).default("detected").notNull(),
    changedFiles: json("changedFiles").$type<{ path: string; status: string; previousPath?: string }[]>().notNull(),
    statusChanges: json("statusChanges").$type<{ requirementId: number; skill: string; before: string | null; after: string; explanation: string }[]>().notNull(),
    evidenceAdded: int("evidenceAdded", { unsigned: true }).default(0).notNull(),
    evidenceRemoved: int("evidenceRemoved", { unsigned: true }).default(0).notNull(),
    errorMessage: varchar("errorMessage", { length: 1000 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => [
    uniqueIndex("change_events_owner_repo_job_sha_uq").on(table.ownerId, table.repositoryId, table.jobId, table.commitSha),
    index("change_events_owner_created_idx").on(table.ownerId, table.createdAt),
  ],
);

export const workItems = mysqlTable(
  "work_items",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    repositoryId: int("repositoryId").notNull().references(() => githubRepositories.id, { onDelete: "cascade" }),
    jobId: int("jobId").notNull().references(() => jobPostings.id, { onDelete: "cascade" }),
    assessmentId: int("assessmentId").references(() => assessmentVersions.id, { onDelete: "set null" }),
    changeEventId: int("changeEventId").references(() => changeEvents.id, { onDelete: "set null" }),
    commitSha: varchar("commitSha", { length: 40 }).notNull(),
    baseSha: varchar("baseSha", { length: 40 }),
    branch: varchar("branch", { length: 255 }).notNull(),
    status: mysqlEnum("status", ["queued", "running", "completed", "failed"]).default("queued").notNull(),
    attempts: int("attempts", { unsigned: true }).default(0).notNull(),
    availableAt: timestamp("availableAt").defaultNow().notNull(),
    leaseUntil: timestamp("leaseUntil"),
    leaseToken: varchar("leaseToken", { length: 36 }),
    lastError: varchar("lastError", { length: 1000 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("work_items_owner_repo_job_sha_uq").on(table.ownerId, table.repositoryId, table.jobId, table.commitSha),
    index("work_items_claim_idx").on(table.status, table.availableAt, table.leaseUntil),
  ],
);

export const githubWebhookDeliveries = mysqlTable(
  "github_webhook_deliveries",
  {
    deliveryId: varchar("deliveryId", { length: 64 }).primaryKey(),
    eventName: varchar("eventName", { length: 64 }).notNull(),
    githubRepositoryId: bigint("githubRepositoryId", { mode: "number", unsigned: true }),
    commitSha: varchar("commitSha", { length: 40 }),
    receivedAt: timestamp("receivedAt").defaultNow().notNull(),
    processedAt: timestamp("processedAt"),
    processingToken: varchar("processingToken", { length: 36 }),
    processingLeaseUntil: timestamp("processingLeaseUntil"),
  },
  table => [index("github_deliveries_repo_received_idx").on(table.githubRepositoryId, table.receivedAt)],
);

export const githubOAuthStates = mysqlTable(
  "github_oauth_states",
  {
    stateHash: varchar("stateHash", { length: 64 }).primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    encryptedVerifier: varchar("encryptedVerifier", { length: 300 }).notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("github_oauth_states_owner_expiry_idx").on(table.ownerId, table.expiresAt)],
);

export type JobPostingRow = typeof jobPostings.$inferSelect;
export type JobRequirementRow = typeof jobRequirements.$inferSelect;
export type ResumeRow = typeof resumes.$inferSelect;
export type GitHubConnectionRow = typeof githubConnections.$inferSelect;
export type GitHubRepositoryRow = typeof githubRepositories.$inferSelect;
export type AssessmentVersionRow = typeof assessmentVersions.$inferSelect;
export type SkillAssessmentRow = typeof skillAssessments.$inferSelect;
export type EvidenceCitationRow = typeof evidenceCitations.$inferSelect;
