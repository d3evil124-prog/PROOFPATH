ALTER TABLE `github_webhook_deliveries` ADD `processingToken` varchar(36);--> statement-breakpoint
ALTER TABLE `github_webhook_deliveries` ADD `processingLeaseUntil` timestamp;