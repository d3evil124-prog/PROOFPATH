CREATE TABLE `assessment_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`jobId` int NOT NULL,
	`repositoryId` int NOT NULL,
	`version` int unsigned NOT NULL,
	`branch` varchar(255) NOT NULL,
	`commitSha` varchar(40) NOT NULL,
	`state` enum('queued','running','completed','failed','stale') NOT NULL DEFAULT 'queued',
	`filesInspected` int unsigned NOT NULL DEFAULT 0,
	`filesExcluded` int unsigned NOT NULL DEFAULT 0,
	`testsDiscovered` boolean NOT NULL DEFAULT false,
	`testsExecuted` boolean NOT NULL DEFAULT false,
	`scopeSummary` json NOT NULL,
	`errorMessage` varchar(1000),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `assessment_versions_id` PRIMARY KEY(`id`),
	CONSTRAINT `assessment_versions_owner_job_repo_version_uq` UNIQUE(`ownerId`,`jobId`,`repositoryId`,`version`),
	CONSTRAINT `assessment_versions_owner_job_repo_commit_uq` UNIQUE(`ownerId`,`jobId`,`repositoryId`,`commitSha`)
);
--> statement-breakpoint
CREATE TABLE `change_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`repositoryId` int NOT NULL,
	`jobId` int NOT NULL,
	`assessmentId` int,
	`previousSha` varchar(40),
	`commitSha` varchar(40) NOT NULL,
	`branch` varchar(255) NOT NULL,
	`commitMessage` varchar(500),
	`processingState` enum('detected','analyzing','completed','failed') NOT NULL DEFAULT 'detected',
	`changedFiles` json NOT NULL,
	`statusChanges` json NOT NULL,
	`evidenceAdded` int unsigned NOT NULL DEFAULT 0,
	`evidenceRemoved` int unsigned NOT NULL DEFAULT 0,
	`errorMessage` varchar(1000),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `change_events_id` PRIMARY KEY(`id`),
	CONSTRAINT `change_events_owner_repo_job_sha_uq` UNIQUE(`ownerId`,`repositoryId`,`jobId`,`commitSha`)
);
--> statement-breakpoint
CREATE TABLE `evidence_citations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`skillAssessmentId` int NOT NULL,
	`repositoryId` int NOT NULL,
	`commitSha` varchar(40) NOT NULL,
	`path` varchar(1000) NOT NULL,
	`lineStart` int unsigned NOT NULL,
	`lineEnd` int unsigned NOT NULL,
	`evidenceType` enum('implementation','test','configuration','documentation') NOT NULL,
	`excerpt` longtext NOT NULL,
	`explanation` varchar(1000) NOT NULL,
	`confidence` enum('medium','high') NOT NULL,
	CONSTRAINT `evidence_citations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `github_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`githubUserId` bigint unsigned NOT NULL,
	`login` varchar(100) NOT NULL,
	`encryptedAccessToken` longtext NOT NULL,
	`encryptedRefreshToken` longtext,
	`accessTokenExpiresAt` timestamp,
	`refreshTokenExpiresAt` timestamp,
	`status` enum('connected','needs_reauthorization','revoked') NOT NULL DEFAULT 'connected',
	`connectedAt` timestamp NOT NULL DEFAULT (now()),
	`lastCheckedAt` timestamp,
	CONSTRAINT `github_connections_id` PRIMARY KEY(`id`),
	CONSTRAINT `github_connections_owner_user_uq` UNIQUE(`ownerId`,`githubUserId`)
);
--> statement-breakpoint
CREATE TABLE `github_installations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`connectionId` int NOT NULL,
	`installationId` bigint unsigned NOT NULL,
	`accountLogin` varchar(100) NOT NULL,
	`accountType` varchar(32) NOT NULL,
	`refreshedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `github_installations_id` PRIMARY KEY(`id`),
	CONSTRAINT `github_install_owner_install_uq` UNIQUE(`ownerId`,`installationId`)
);
--> statement-breakpoint
CREATE TABLE `github_oauth_states` (
	`stateHash` varchar(64) NOT NULL,
	`ownerId` int NOT NULL,
	`encryptedVerifier` varchar(300) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `github_oauth_states_stateHash` PRIMARY KEY(`stateHash`)
);
--> statement-breakpoint
CREATE TABLE `github_repositories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`connectionId` int NOT NULL,
	`installationRowId` int NOT NULL,
	`githubRepositoryId` bigint unsigned NOT NULL,
	`repositoryOwner` varchar(100) NOT NULL,
	`repositoryName` varchar(100) NOT NULL,
	`defaultBranch` varchar(255) NOT NULL,
	`isPrivate` boolean NOT NULL,
	`selected` boolean NOT NULL DEFAULT false,
	`branch` varchar(255),
	`latestObservedSha` varchar(40),
	`lastSyncedAt` timestamp,
	`nextPollAt` timestamp,
	`watcherStatus` enum('active','paused','failed','stale') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `github_repositories_id` PRIMARY KEY(`id`),
	CONSTRAINT `github_repos_owner_external_uq` UNIQUE(`ownerId`,`githubRepositoryId`)
);
--> statement-breakpoint
CREATE TABLE `github_webhook_deliveries` (
	`deliveryId` varchar(64) NOT NULL,
	`eventName` varchar(64) NOT NULL,
	`githubRepositoryId` bigint unsigned,
	`commitSha` varchar(40),
	`receivedAt` timestamp NOT NULL DEFAULT (now()),
	`processedAt` timestamp,
	CONSTRAINT `github_webhook_deliveries_deliveryId` PRIMARY KEY(`deliveryId`)
);
--> statement-breakpoint
CREATE TABLE `job_postings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`sourceKind` enum('fetched','pasted') NOT NULL,
	`sourceUrl` varchar(2048),
	`retrievedAt` timestamp,
	`title` varchar(255) NOT NULL,
	`company` varchar(255),
	`description` longtext NOT NULL,
	`extractionStatus` enum('needs_review','confirmed') NOT NULL DEFAULT 'needs_review',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `job_postings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `job_requirements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`jobId` int NOT NULL,
	`originalWording` varchar(1000) NOT NULL,
	`skill` varchar(160) NOT NULL,
	`skillKey` varchar(180) NOT NULL,
	`priority` enum('required','preferred') NOT NULL DEFAULT 'required',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `job_requirements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `resumes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`originalName` varchar(255) NOT NULL,
	`mimeType` enum('application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document') NOT NULL,
	`byteSize` int unsigned NOT NULL,
	`fileSha256` varchar(64) NOT NULL,
	`encryptedObjectKey` varchar(255) NOT NULL,
	`encryptionSaltHex` varchar(32) NOT NULL,
	`parsedProfile` json NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `resumes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skill_assessments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`assessmentId` int NOT NULL,
	`requirementId` int NOT NULL,
	`status` enum('demonstrated','partial_or_needs_review','not_demonstrated_in_analyzed_scope','unable_to_assess') NOT NULL,
	`explanation` longtext NOT NULL,
	`resumeMentioned` boolean NOT NULL DEFAULT false,
	`resumeSupport` varchar(1000),
	`recommendation` varchar(1000) NOT NULL,
	`confidence` enum('low','medium','high') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `skill_assessments_id` PRIMARY KEY(`id`),
	CONSTRAINT `skill_assessment_version_requirement_uq` UNIQUE(`ownerId`,`assessmentId`,`requirementId`)
);
--> statement-breakpoint
CREATE TABLE `work_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`repositoryId` int NOT NULL,
	`jobId` int NOT NULL,
	`assessmentId` int,
	`changeEventId` int,
	`commitSha` varchar(40) NOT NULL,
	`baseSha` varchar(40),
	`branch` varchar(255) NOT NULL,
	`status` enum('queued','running','completed','failed') NOT NULL DEFAULT 'queued',
	`attempts` int unsigned NOT NULL DEFAULT 0,
	`availableAt` timestamp NOT NULL DEFAULT (now()),
	`leaseUntil` timestamp,
	`leaseToken` varchar(36),
	`lastError` varchar(1000),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `work_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `work_items_owner_repo_job_sha_uq` UNIQUE(`ownerId`,`repositoryId`,`jobId`,`commitSha`)
);
--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD CONSTRAINT `assessment_versions_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD CONSTRAINT `assessment_versions_jobId_job_postings_id_fk` FOREIGN KEY (`jobId`) REFERENCES `job_postings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD CONSTRAINT `assessment_versions_repositoryId_github_repositories_id_fk` FOREIGN KEY (`repositoryId`) REFERENCES `github_repositories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `change_events` ADD CONSTRAINT `change_events_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `change_events` ADD CONSTRAINT `change_events_repositoryId_github_repositories_id_fk` FOREIGN KEY (`repositoryId`) REFERENCES `github_repositories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `change_events` ADD CONSTRAINT `change_events_jobId_job_postings_id_fk` FOREIGN KEY (`jobId`) REFERENCES `job_postings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `change_events` ADD CONSTRAINT `change_events_assessmentId_assessment_versions_id_fk` FOREIGN KEY (`assessmentId`) REFERENCES `assessment_versions`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `evidence_citations` ADD CONSTRAINT `evidence_citations_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `evidence_citations` ADD CONSTRAINT `evidence_citations_skillAssessmentId_skill_assessments_id_fk` FOREIGN KEY (`skillAssessmentId`) REFERENCES `skill_assessments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `evidence_citations` ADD CONSTRAINT `evidence_citations_repositoryId_github_repositories_id_fk` FOREIGN KEY (`repositoryId`) REFERENCES `github_repositories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_connections` ADD CONSTRAINT `github_connections_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_installations` ADD CONSTRAINT `github_installations_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_installations` ADD CONSTRAINT `github_installations_connectionId_github_connections_id_fk` FOREIGN KEY (`connectionId`) REFERENCES `github_connections`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_oauth_states` ADD CONSTRAINT `github_oauth_states_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_repositories` ADD CONSTRAINT `github_repositories_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_repositories` ADD CONSTRAINT `github_repositories_connectionId_github_connections_id_fk` FOREIGN KEY (`connectionId`) REFERENCES `github_connections`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `github_repositories` ADD CONSTRAINT `github_repositories_installationRowId_github_installations_id_fk` FOREIGN KEY (`installationRowId`) REFERENCES `github_installations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `job_postings` ADD CONSTRAINT `job_postings_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `job_requirements` ADD CONSTRAINT `job_requirements_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `job_requirements` ADD CONSTRAINT `job_requirements_jobId_job_postings_id_fk` FOREIGN KEY (`jobId`) REFERENCES `job_postings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `resumes` ADD CONSTRAINT `resumes_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `skill_assessments` ADD CONSTRAINT `skill_assessments_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `skill_assessments` ADD CONSTRAINT `skill_assessments_assessmentId_assessment_versions_id_fk` FOREIGN KEY (`assessmentId`) REFERENCES `assessment_versions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `skill_assessments` ADD CONSTRAINT `skill_assessments_requirementId_job_requirements_id_fk` FOREIGN KEY (`requirementId`) REFERENCES `job_requirements`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `work_items` ADD CONSTRAINT `work_items_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `work_items` ADD CONSTRAINT `work_items_repositoryId_github_repositories_id_fk` FOREIGN KEY (`repositoryId`) REFERENCES `github_repositories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `work_items` ADD CONSTRAINT `work_items_jobId_job_postings_id_fk` FOREIGN KEY (`jobId`) REFERENCES `job_postings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `work_items` ADD CONSTRAINT `work_items_assessmentId_assessment_versions_id_fk` FOREIGN KEY (`assessmentId`) REFERENCES `assessment_versions`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `work_items` ADD CONSTRAINT `work_items_changeEventId_change_events_id_fk` FOREIGN KEY (`changeEventId`) REFERENCES `change_events`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `assessment_versions_owner_job_repo_idx` ON `assessment_versions` (`ownerId`,`jobId`,`repositoryId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `assessment_versions_repo_commit_idx` ON `assessment_versions` (`ownerId`,`repositoryId`,`commitSha`);--> statement-breakpoint
CREATE INDEX `change_events_owner_created_idx` ON `change_events` (`ownerId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `evidence_citations_owner_skill_idx` ON `evidence_citations` (`ownerId`,`skillAssessmentId`);--> statement-breakpoint
CREATE INDEX `github_connections_owner_status_idx` ON `github_connections` (`ownerId`,`status`);--> statement-breakpoint
CREATE INDEX `github_install_connection_idx` ON `github_installations` (`ownerId`,`connectionId`);--> statement-breakpoint
CREATE INDEX `github_oauth_states_owner_expiry_idx` ON `github_oauth_states` (`ownerId`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `github_repos_owner_selected_idx` ON `github_repositories` (`ownerId`,`selected`);--> statement-breakpoint
CREATE INDEX `github_repos_due_poll_idx` ON `github_repositories` (`watcherStatus`,`nextPollAt`);--> statement-breakpoint
CREATE INDEX `github_deliveries_repo_received_idx` ON `github_webhook_deliveries` (`githubRepositoryId`,`receivedAt`);--> statement-breakpoint
CREATE INDEX `job_postings_owner_updated_idx` ON `job_postings` (`ownerId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `job_requirements_owner_job_idx` ON `job_requirements` (`ownerId`,`jobId`);--> statement-breakpoint
CREATE INDEX `resumes_owner_uploaded_idx` ON `resumes` (`ownerId`,`uploadedAt`);--> statement-breakpoint
CREATE INDEX `skill_assessments_owner_version_idx` ON `skill_assessments` (`ownerId`,`assessmentId`);--> statement-breakpoint
CREATE INDEX `work_items_claim_idx` ON `work_items` (`status`,`availableAt`,`leaseUntil`);