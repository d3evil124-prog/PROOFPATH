CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`displayName` varchar(120),
	`headline` varchar(160),
	`targetRole` varchar(160),
	`location` varchar(120),
	`bio` varchar(1000),
	`websiteUrl` varchar(2048),
	`linkedinUrl` varchar(2048),
	`githubUrl` varchar(2048),
	`resumeContextEnabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_profiles_owner_uq` UNIQUE(`ownerId`)
);
--> statement-breakpoint
ALTER TABLE `user_profiles` ADD CONSTRAINT `user_profiles_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `resumes` MODIFY COLUMN `encryptedObjectKey` varchar(255) NULL;
--> statement-breakpoint
ALTER TABLE `resumes` ADD `encryptedFile` longtext;
--> statement-breakpoint
ALTER TABLE `resumes` ADD `profileCiphertext` longtext;
--> statement-breakpoint
CREATE TABLE `resume_chunks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`resumeId` int NOT NULL,
	`chunkIndex` int unsigned NOT NULL,
	`encryptedContent` longtext NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `resume_chunks_id` PRIMARY KEY(`id`),
	CONSTRAINT `resume_chunks_resume_index_uq` UNIQUE(`ownerId`,`resumeId`,`chunkIndex`)
);
--> statement-breakpoint
ALTER TABLE `resume_chunks` ADD CONSTRAINT `resume_chunks_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `resume_chunks` ADD CONSTRAINT `resume_chunks_resumeId_resumes_id_fk` FOREIGN KEY (`resumeId`) REFERENCES `resumes`(`id`) ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX `resume_chunks_owner_resume_idx` ON `resume_chunks` (`ownerId`,`resumeId`);
--> statement-breakpoint
ALTER TABLE `github_repositories` MODIFY COLUMN `connectionId` int NULL;
--> statement-breakpoint
ALTER TABLE `github_repositories` MODIFY COLUMN `installationRowId` int NULL;
--> statement-breakpoint
ALTER TABLE `github_repositories` ADD `accessMode` enum('github_app','public_link') NOT NULL DEFAULT 'github_app';
--> statement-breakpoint
ALTER TABLE `github_repositories` ADD `authorized` boolean NOT NULL DEFAULT false;
--> statement-breakpoint
CREATE INDEX `github_repos_owner_authorized_selected_idx` ON `github_repositories` (`ownerId`,`authorized`,`selected`);
--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD `resumeId` int NULL;
--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD `resumeContextUsed` boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE `assessment_versions` ADD CONSTRAINT `assessment_versions_resumeId_resumes_id_fk` FOREIGN KEY (`resumeId`) REFERENCES `resumes`(`id`) ON DELETE set null ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `skill_assessments` ADD `resumeChunkIds` json;
