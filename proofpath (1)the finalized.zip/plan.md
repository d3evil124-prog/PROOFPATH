# ProofPath implementation plan

## Scope and approach

Import the supplied NEWONE.zip application as the source of truth. Restore its intended full-stack layout after the archive flattened directory names, while preserving the supplied React 19/Vite frontend, Express/tRPC backend, Drizzle/MySQL schema and migrations, OAuth session flow, public GitHub verification, resume extraction/encryption/RAG, assessment worker, job-source importer, profile/settings flows, route manifest, assets, tests, and documentation.

Only runtime glue that is referenced by the supplied code but absent from the flattened snapshot will be added: shared authentication constants, the typed client tRPC binding, the Express/Vite bridge, the minimal system router, the React error boundary, and the missing Manus OAuth type declarations. These are integration adapters, not a replacement product or a new feature set.

The managed project uses Server and Database. The server listens on the configured port and serves tRPC at `/api/trpc`, OAuth and GitHub callbacks, ProofPath HTTP endpoints, health, platform configuration, and Vite/static frontend assets. The database uses the supplied Drizzle schema and checked-in SQL migrations; no demo fixtures or test writes are added to the shared database. Server-only secrets remain in runtime environment variables.

## Project structure

- `client/src/`: supplied React application, routes, pages, shared UI, hooks, typed tRPC client, and styles.
- `client/public/`: supplied route manifest and brand mark.
- `server/_core/`: supplied Express entrypoint, Vite/static serving, OAuth/session/auth context, tRPC procedures, public platform config, LLM helper, and runtime environment access.
- `server/`: supplied database access, root tRPC router, storage helper, and server feature modules.
- `server/features/`: supplied job import, resume parsing/encryption/RAG, GitHub public-link/API/OAuth, assessment and worker logic, profile, webhook, policy, HTTP routes, and tests.
- `drizzle/`: supplied schema, relations, and checked-in migrations.
- `shared/`: shared constants and HTTP errors used by browser and server code.
- `attached_assets/`: supplied images and mark assets retained from the archive.
- `docs/`: supplied product, setup, API, security, runtime, and implementation notes.

## Design

### Reused movement
Calm developer-product editorial UI: warm neutral canvas, precise indigo structure, verified teal states, and amber review states. The supplied landing page and CSS remain authoritative.

### Core principles
1. Evidence before claims: every assessment surface points back to submitted sources.
2. Quiet rigor: restrained motion, crisp cards, readable code/evidence panels, and explicit limitations.
3. Ownership by default: authenticated user scope is enforced on the backend and explained in the UI.
4. Honest uncertainty: missing or unavailable evidence is never presented as a negative verdict.

### Color philosophy
Warm neutrals keep dense evidence views calm; indigo marks the navigational and analytical spine; teal communicates verified source-backed progress; amber flags review or incomplete coverage without implying failure.

### Layout paradigm
Editorial landing sections and asymmetric evidence panels lead into a practical workspace shell. Content stays left-anchored with clear source-to-result progression rather than a generic centered dashboard grid.

### Signature elements
- Branching-path ProofPath mark and thin evidence graph motif.
- Compact source/status pills that distinguish verified, review, stale, and unavailable states.
- Commit-pinned evidence cards with path, line range, SHA, and explanation.

### Interaction and animation
Interactions expose source state, loading, saved/error states, and ownership boundaries. The supplied landing evidence-path animation stays lightweight and low contrast, does not obscure copy, and respects reduced-motion preferences. No extra generated artwork or unrelated runtime dependency is introduced.

### Typography and voice
Use the supplied CSS typography system and hierarchy. The voice is calm, rigorous, and encouraging: “Add a public repository link; ProofPath checks it before reading.” and “Resume context can guide the comparison, but only cited code supports a demonstrated skill.”

### Brand
ProofPath is evidence-led career progress for developers, grounded in inspected code rather than opaque scores. Personality: calm, rigorous, encouraging. The branching mark is the wordmark’s source motif, and indigo is the signature brand color.

## Build workflow

1. Restore the archive tree and add only the referenced runtime adapters.
2. Install the pinned `pnpm@10.18.0` dependencies with the checked-in lifecycle policy.
3. Run managed TypeScript/JSON/CSS diagnostics, the supplied tests, type-check, and production build.
4. Start the supplied full-stack development server on the managed port, verify `/api/health` and `/manus-routes.json`, and inspect the public landing route.
5. Reconcile and apply the deterministic additive migration set to the confirmed empty managed database, rerun checks, and create a managed repository checkpoint when the canonical Git transport is available. Do not publish automatically and do not seed product fixtures; the current Sandbox snapshot has no `.git` metadata or canonical remote transport, so no checkpoint is claimed.
