# ProofPath fixes and verification

## Implemented in this source snapshot

- **Resume upload and storage:** retained the existing owner-scoped MySQL storage of encrypted originals, extracted resume profiles, and encrypted RAG chunks. The server uses the managed `MANUS_JWT_SECRET` for HKDF-derived AES-256-GCM keys; the upload does not ask users to create or paste a key. When that server setting is absent or too short, the response now identifies it as an administrator/runtime configuration issue instead of a vague retry message. The existing 5 MiB PDF/DOCX validation and progress/error UI remain in place.
- **Public GitHub repositories without a GitHub App:** added a public repository URL field, canonical `github.com` URL parsing, unauthenticated GitHub API verification, owner-scoped persistence, branch selection, and repository-aware anonymous API access for code inspection. App synchronization does not revoke or duplicate public links, and public links poll less frequently to respect anonymous API limits.
- **Verification boundary:** public API verification establishes that GitHub currently exposes the repository as public. A URL cannot prove the submitter owns the repository or that they authored the code. Private repositories still need an explicit authenticated GitHub grant. Public repository contents are never executed.
- **Profile:** added a visible `/student/profile` navigation item and route. The page shows the signed-in account identity separately from editable display name, headline, target role, location, biography, and HTTPS website/LinkedIn/GitHub links. It includes owner-scoped resume/assessment/commit history.
- **RAG and version comparison:** the existing assessment pipeline already retrieved per-requirement encrypted resume passages and treated them as supplemental—not code proof. Added a same-user comparison UI for two resume versions against a saved job, with retrieved passage provenance and extracted-skill additions/removals.
- **Privacy & connections:** made the settings page navigable, added a saved resume-context preference that controls future assessments, preserved pause/resume monitoring, and clarified resume removal. Personal details are edited in Profile.
- **Job sources:** public job-posting import and exact-description fallback were already present. This change intentionally did not duplicate them. Import is limited to public pages the safe fetcher can access; it does not sign into AICTE, Internshala, Naukri, bypass anti-bot protections/paywalls, or certify a site's claims.
- **Landing animation:** added a light, CSS/SVG 3D-style evidence-path motion treatment behind the homepage hero. It is intentionally not a generated video asset, to avoid unnecessary generation cost; reduced-motion users see a static treatment.
- **Regression coverage:** added security tests for minimum-length platform-key encryption and canonical/public GitHub URL checks.

## Database and credentials

The imported schema includes encrypted resume/profile/RAG fields, profile preferences, and the `public_link` repository access mode. During managed-project restoration, the archive's duplicate `0001` migration and missing journal were reconciled: `drizzle/0002_proofpath_current_schema.sql` now adds the current profile, encrypted resume, resume-chunk, public-link, assessment-context, and resume-citation fields, while `drizzle/0003_bumpy_roland_deschain.sql` adds webhook processing leases. The managed database was confirmed empty before applying the deterministic four-migration sequence, so no existing product data was changed. No GitHub App client ID, secret, or webhook secret is required to use a verified public repository URL.

The app runtime must still provide its existing server-only `MANUS_JWT_SECRET` (at least 16 UTF-8 bytes) for resume and token encryption. If it is missing in the actual deployment, code changes cannot manufacture a stable secret or decrypt existing data; the deployment administrator must restore the managed runtime secret. No secret was created, rotated, or exposed as part of this task.

## Verification and deployment status

- The restored project passes managed TypeScript/JSON/CSS diagnostics, `pnpm check`, all 31 supplied tests, and `pnpm build`.
- The Preview server and production bundle both return `GET /api/health` 200, serve the 22-route `manus-routes.json`, and serve the built landing page.
- The managed database was read-verified empty before migration, then `pnpm db:migrate` applied four ordered migrations. Read-only inspection confirmed all current tables, nullable public-link foreign keys, encrypted resume fields, profile/RAG tables, assessment context fields, and webhook lease fields.
- Browser smoke screenshots confirmed the supplied landing page, ProofPath sign-in handoff, and protected setup redirect render correctly. Live OAuth, GitHub, job-source, resume-upload, and LLM flows still require their configured external resources and are not claimed as end-to-end tested.
- The Sandbox project directory has no `.git` metadata or canonical remote transport in this session, so no Manus checkpoint/publish is claimed. The completed source remains available in the managed Preview project directory.
