# ProofPath — Evidence-led career coaching

React / Express / tRPC / Drizzle starter, adapted from the Sandbox web-db-user template.

- `pnpm dev`: development server; honors `PORT` (default 3000).
- `pnpm build` / `pnpm start`: build and serve `dist/index.js` and `dist/public/`.
- `pnpm db:migrate`: apply checked-in migrations.
- For schema changes, update `drizzle/schema.ts`, run `pnpm exec drizzle-kit generate`, review and commit the migration, then apply it with `pnpm db:migrate`. Avoid `pnpm db:push` on the shared managed database.
- `pnpm check` / `pnpm test`: types and application tests.

See [`docs/SETUP.md`](docs/SETUP.md) for runtime, database migration, privacy, deployment and optional GitHub App setup. See [`docs/API.md`](docs/API.md) for the authenticated tRPC procedures and HTTP endpoints.

No synthetic user/job/repository/assessment data is included in the running app. GitHub OAuth/webhooks remain unavailable until the protected GitHub App environment values are configured. `.env.example` contains names and placeholders only; never commit real credentials.

`server/_core/publicConfig.ts` exposes only named public runtime values. Private keys stay server-side. The platform serves managed `/manus-storage/` assets; the application does not register a second proxy.

Platform configuration is readable and editable through `webdev.config`. Default settings are initial values, not enforced constraints. The agent may modify the files, commands and configuration or follow the flexible guide for another stack.
