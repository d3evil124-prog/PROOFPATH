# ProofPath — implementation and design plan

## Scope and implementation approach

Continue the existing authenticated React 19 / TypeScript / Vite client and Express / tRPC / Drizzle / managed MySQL backend. Preserve the calm developer-focused ProofPath brand (warm neutral canvas, indigo, verified teal, amber review states), the no-fabricated-data rule, and server-side owner authorization. The platform-managed server and database are enabled; database DDL and writes affect the same managed database used by published runtime, so use additive migrations and never seed fixtures.

### Resume storage and retrieval-augmented analysis

Fix the encryption guard to accept the platform-provided session secret at a minimum of 16 characters and continue deriving purpose-specific AES-256-GCM keys with HKDF. Do not ask the user to create or disclose another key. Store encrypted resume bytes, encrypted extracted profile JSON and encrypted text chunks in owner-indexed MySQL records. Keep the current PDF/DOCX validation, 5 MiB request limit, bounded extraction, and owner-scoped deletion; remove the object-storage dependency for new uploads. Keep legacy rows readable where possible. Provide clear progress, extraction review, upload history, and recovery messages.

Split extracted text into bounded, overlapping chunks and persist the chunks encrypted, keyed by owner and resume version. For each confirmed job requirement, retrieve only the most relevant chunks from the signed-in user's selected resume version, using deterministic term relevance ranking, and provide those passages to the server-side structured LLM as supporting context. Do not use resume statements as GitHub evidence or proof of skill. Store resume version context with the assessment, label resume mentions as self-reported, and keep code citations pinned to exact GitHub commits, paths and line ranges. Add a same-user resume-version comparison view that compares extracted profile changes and retrieved passages against one selected job; never compare or disclose another user's resume.

### GitHub public-link workflow

Replace the default App-configuration block with a simple GitHub repository URL field. Parse only canonical `https://github.com/{owner}/{repo}` links, verify the repository through the fixed public GitHub REST API, reject private/nonexistent repositories, show canonical owner/name/default branch, load branches, and require explicit selection before source inspection. Use unauthenticated requests for public-link repositories so a pre-existing user's OAuth token is not implicitly reused. Store an owner-scoped, public-link access mode and preserve the existing background assessment/commit pipeline, with honest public API rate-limit and polling status. A pasted URL verifies that a repository is public and reachable; it does not prove the submitter owns or controls the account. Private repositories cannot be inspected by URL alone and still need an optional, explicitly configured user grant; public-link use must not require a GitHub App client ID, secret, slug or webhook secret.

### Profile, privacy and connections

Add an owner-scoped profile record and `/student/profile` route with editable display name, headline, target role, location, bio, and validated personal links. Show the authenticated Manus account name/email as account identity, not as editable verified identity. Include account/repository/resume/assessment history and a side-by-side comparison of the user's resume versions. Simplify `/student/settings` into interactive source controls: resume-context use toggle, selected public repository monitoring pause/resume, current source state, last sync, and safe resume removal; retain clear private-by-default/consent and evidence limitations. User data, repository selections and resume history stay strictly owner-scoped.

### Public job-source intake

Keep and improve the existing SSRF-safe public HTML/text importer. Accept user-provided public listing URLs from AICTE, Internshala, Naukri or another compatible source and preserve the exact source URL and retrieval time. Communicate that only publicly readable pages are fetched; do not log into job sites, scrape private accounts, bypass CAPTCHAs/anti-bot systems/paywalls, or claim third-party source certification. If a page blocks fetch or contains little readable description, provide a paste-description fallback and retain the source attribution.

### Homepage animation

Add one silent, lightweight 5-second 3D evidence-path loop behind the landing hero, using restrained indigo/teal/amber network nodes and commit-to-evidence motion. Keep foreground copy/cards readable, add a poster/fallback, avoid text/logos in the generated video, and disable playback under `prefers-reduced-motion` or when media fails. No unrelated artwork or heavy runtime dependency.

### Existing assessment and reliability contract

Preserve the existing source-grounded job extraction, exact commit/path/line citations, user ownership checks, durable work queue, lease fencing, renewable/idempotent GitHub webhook processing, polling recovery, failure/stale states and no fabricated live records. If unavailable sources, model calls or schema validation fail, retain the last successful assessment and do not convert failures into a negative skill finding. Do not execute repository code. Do not present absence of a finding as absence of skill.

## Project structure

- `client/src/App.tsx`: public and authenticated page routes, including `/student/profile`.
- `client/src/pages/`: existing setup, assessment, evidence/history and new editable profile/connection screens.
- `client/src/components/`: role-aware shell, uploader, forms, status badges, history/comparison views and accessible animation controls.
- `client/src/lib/`: typed tRPC client and API contracts.
- `client/public/manus-routes.json`: exact route manifest including the new profile page.
- `server/routers.ts`: owner-derived profile, resume library/compare, public repository link, job import and assessment procedures.
- `server/features/`: AES-GCM encryption, MySQL resume storage/chunking/retrieval, job-source SSRF protection, public GitHub URL verification/API transport and existing assessment/webhook/worker policies.
- `drizzle/schema.ts` and `drizzle/`: additive profile, encrypted resume/chunk and public repository schema changes with checked-in MySQL migrations.
- `docs/API.md`, `docs/SETUP.md`, `.env.example`: accurate endpoint, public-only source, key, data and migration documentation; no real secrets.

## Design direction

Reuse the current premium calm-developer aesthetic rather than restyling the application. Extend the branching-path mark into a subtle animated evidence graph: thin indigo/teal paths, precise commit nodes and small amber review markers. Keep code, forms, tables and evidence cards solid and legible; use animation only as atmospheric depth in the landing hero and as purposeful status feedback. Motion should be slow, low-contrast, reduced-motion aware and never obscure text. Profile/settings should prioritize editable labels, clear ownership and obvious saved/error state. Use semantic labels, visible keyboard focus, readable mobile layouts and explicit helper text about what public URLs verify and what resume context can/cannot prove.

Brand essence: **Evidence-led career progress for developers, grounded in inspected code rather than opaque scores.** Personality: calm, rigorous, encouraging. Voice examples: “Add a public repository link; ProofPath checks it before reading.” “Resume context can guide the comparison, but only cited code supports a demonstrated skill.”
