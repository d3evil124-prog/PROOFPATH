# ProofPath setup and deployment

## Current integration state

ProofPath has no preinstalled jobs, resumes, repositories, assessment records, accounts, or synthetic product results. GitHub OAuth, repository access, and webhook processing are implemented but **disabled until a GitHub App is configured**. No GitHub credentials were provided or saved. Until the protected configuration is complete, the UI reports that the integration is unavailable and will not claim a connection or assessment succeeded.

## Runtime and database

The project is a React/TypeScript client served by the existing Express/tRPC application. It uses the existing Manus OAuth session, Drizzle ORM, MySQL, Manus's server-side LLM helper, and private object-storage helper. It does not require a separate Supabase project or external application server.

Use Node 22 and the pinned pnpm version in the lockfile/Dockerfile.

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm dev
```

The Preview listener defaults to port 3000 and serves the client and `/api/*` from the Express application. Confirm runtime readiness at `/api/health`.

The managed MySQL database is shared by the project development and published application. On a new empty database, apply the checked-in migrations once:

```bash
pnpm db:migrate
```

The additive migrations create the ProofPath tables and owner indexes, add current GitHub repository authorization and webhook processing-lease fields, and do not seed users or sample records. Do not run destructive test data against the managed database. Avoid `pnpm db:push` as an unreviewed production schema shortcut; change the Drizzle schema, generate and review a migration, then apply it through the approved deployment process.

Build and serve the existing container entrypoint with `pnpm build` / `pnpm start`; the checked-in `Dockerfile` installs dependencies, builds the Vite client and serves `dist/index.js` on `PORT` (default 3000). Keep the active production application server running for background processing. The database-backed work queue survives process restarts; its in-process worker resumes when the server starts. A fallback loop checks for due authorized, selected repositories about once per minute; each repository becomes due on a roughly five-minute schedule. Transient network/API failures keep the watcher retryable with a ten-minute backoff, including previously selected rows marked `failed`; HTTP 401 marks the watcher `stale`, stops polling it, and marks the linked GitHub connection for reauthorization. GitHub push webhooks are preferred for prompt detection. If the host scales the application to zero, in-process polling pauses until an instance starts again.

## GitHub App setup (optional until an administrator has credentials)

Create a GitHub App in GitHub **Settings → Developer settings → GitHub Apps → New GitHub App**. For a new app configured with repository selection, use these settings:

1. Set the public application homepage to the ProofPath HTTPS origin.
2. Set the **User authorization callback URL** to the exact URL `https://<public-app-origin>/api/github/callback`. It must be HTTPS, with no query string or fragment. This exact URL must match `GITHUB_CALLBACK_URL`.
3. Grant only **Repository permissions → Contents: Read-only** and **Metadata: Read-only**. Do not grant write permissions.
4. Allow installation on the account types the product intends to support (a user's account and, where authorized, an organization).
5. Enable the GitHub App webhook at `https://<public-app-origin>/api/github/webhook`; choose a strong webhook secret and subscribe to `push`, `installation` (deletion), and `installation_repositories` (`added`/`removed`) events. Added/removed repository events refresh the linked user's authorized repository grants; unsupported event/action pairs are acknowledged but ignored and are not marked processed.
6. Record the App's client ID, client secret, and URL slug in the platform's protected project environment—not in this repository, a browser variable, a ticket, or chat.
7. Install the App on the desired GitHub account/organization and choose the repositories GitHub is permitted to expose. In ProofPath, sign in with Manus, authorize GitHub, select one of the granted repositories and a branch, then explicitly select that repository for assessment. If the repository list is empty, the setup step provides an App installation link.

When a repository is removed from an installation grant, ProofPath marks that grant unauthorized and unselects it; it is omitted from future repository/branch choices and cannot be used for new assessments. Existing commit-pinned assessment history remains available to the same authenticated owner. Deleting the whole installation likewise stops monitoring and revokes new repository access while retaining history.

Provide these **server-only** values through Webdev's protected project environment/secrets. `.env.example` lists names only; it intentionally contains no credentials.

| Variable | Purpose |
| --- | --- |
| `GITHUB_APP_CLIENT_ID` | GitHub App user-authorization client ID |
| `GITHUB_APP_CLIENT_SECRET` | Server-side OAuth token exchange and refresh |
| `GITHUB_APP_SLUG` | GitHub App URL slug used for the installation link |
| `GITHUB_CALLBACK_URL` | Exact public HTTPS callback URL ending in `/api/github/callback` |
| `GITHUB_WEBHOOK_SECRET` | HMAC-SHA256 webhook signature verification |

`DATABASE_URL`, the existing Manus session secret, and the built-in Manus LLM/object-storage configuration are platform-managed project values; do not copy them into client-visible `VITE_*` variables. The encryption helpers derive purpose-specific keys server-side from the existing session secret. If that platform secret is rotated, stored GitHub tokens and encrypted resume objects may need to be reauthorized/reuploaded; plan key rotation before changing it.

When values are configured, the authenticated `/student/setup` route starts the OAuth flow. GitHub App authorization and GitHub App installation are distinct steps; select which repositories the App can access in GitHub. Then refresh the repository list and select a repository/branch in ProofPath. To remove the App grant, use GitHub's [installed GitHub Apps settings](https://github.com/settings/installations). Pausing a repository in ProofPath stops monitoring but does not revoke the App's GitHub grant.

**Do not submit actual secret values in chat or commit them to files.** If you do not yet have a GitHub App, the rest of the project can be run and reviewed with that integration visibly unconfigured; live GitHub OAuth/webhook end-to-end behavior remains unverified.

## Data and privacy notes

- Job descriptions, resume-derived text, and bounded source-code excerpts are sent to the configured server-side analysis service. Do not submit credentials or unrelated sensitive information.
- Resume files are encrypted before private storage. MySQL holds the parsed profile and opaque encrypted-object reference. The current storage helper does not expose a physical object deletion operation; removing the resume deletes the application record/key so remaining ciphertext is inaccessible through ProofPath, but does not promise physical object deletion.
- Repository code is fetched only after user authorization and repository selection. Repository code is never executed.
- MySQL does not offer the requested native row-level security in this setup. Each product query and mutation enforces the authenticated owner ID server-side and the schema adds owner indexes and foreign keys. Do not treat a client-side route guard as an access boundary.
- An assessment represents evidence in inspected files at a particular commit; it is not a complete skill test, hiring prediction, or claim that absent evidence means the skill is absent.

## Verification

```bash
pnpm check
pnpm test
pnpm build
```

Automated tests use isolated inputs and do not insert synthetic user data into the managed database. The GitHub account-authorization, installation, push webhook delivery, real job-page availability, live resume submission, and end-to-end commit-update scenarios require configured external resources and must not be reported as passed until actually exercised against them.
