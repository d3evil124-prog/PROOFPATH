import { and, eq, gt } from "drizzle-orm";
import { workItems } from "../../drizzle/schema";

type LeaseOwner = Pick<typeof workItems.$inferSelect, "id" | "ownerId" | "status" | "leaseToken">;

export class LeaseLostError extends Error {
  constructor() {
    super("The assessment worker no longer owns this work-item lease.");
    this.name = "LeaseLostError";
  }
}

export function leaseCondition(item: LeaseOwner, now = new Date()) {
  if (!item.leaseToken) throw new LeaseLostError();
  return and(
    eq(workItems.ownerId, item.ownerId),
    eq(workItems.id, item.id),
    eq(workItems.status, "running"),
    eq(workItems.leaseToken, item.leaseToken),
    gt(workItems.leaseUntil, now),
  )!;
}

export function singleFlight(operation: () => Promise<void>): () => Promise<void> {
  let inProgress = false;
  return async () => {
    if (inProgress) return;
    inProgress = true;
    try {
      await operation();
    } finally {
      inProgress = false;
    }
  };
}

export function pollFailureDisposition(status: number | undefined) {
  if (status === 401) {
    return { watcherStatus: "stale" as const, retryDelayMs: null };
  }
  return { watcherStatus: "active" as const, retryDelayMs: 10 * 60_000 };
}
