import { z } from "zod";
import { invokeLLM, listLLMModels, type ResponseFormat } from "../_core/llm";

let cachedModel: { id: string; expiresAt: number } | undefined;

async function selectModel(): Promise<string> {
  if (cachedModel && cachedModel.expiresAt > Date.now()) return cachedModel.id;
  const catalog = await listLLMModels();
  const entries = (catalog.data ?? []) as (typeof catalog.data[number] & { status?: string })[];
  const usable = new Set(entries.filter(model => model.status !== "temporarily_unavailable").map(model => model.id));
  const selected = ["gpt-5-mini", "gemini-3-flash-preview", "gpt-5", "gemini-3.1-pro-preview"].find(id => usable.has(id));
  if (!selected) throw new Error("No supported structured-analysis model is currently available.");
  cachedModel = { id: selected, expiresAt: Date.now() + 5 * 60_000 };
  return selected;
}

function textFromResponse(response: unknown): string {
  const result = response as { error?: { message?: string }; choices?: { message?: { content?: unknown } }[] };
  if (result.error) throw new Error(result.error.message || "The analysis service returned an error.");
  const content = result.choices?.[0]?.message?.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content.map(part => typeof part === "object" && part && "text" in part ? String((part as { text: unknown }).text) : "").join("\n").trim();
  }
  return "";
}

function parseObject(text: string): unknown {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  try {
    return JSON.parse(cleaned);
  } catch {
    const first = cleaned.indexOf("{");
    const last = cleaned.lastIndexOf("}");
    if (first >= 0 && last > first) return JSON.parse(cleaned.slice(first, last + 1));
    throw new Error("The analysis service returned no valid structured result.");
  }
}

export async function requestStructured<T>(input: {
  name: string;
  system: string;
  user: string;
  jsonSchema: Record<string, unknown>;
  validator: z.ZodType<T>;
  maxCompletionTokens?: number;
}): Promise<T> {
  const model = await selectModel();
  const responseFormat: ResponseFormat = {
    type: "json_schema",
    json_schema: {
      name: input.name,
      strict: true,
      schema: input.jsonSchema,
    },
  };
  const tokenLimit = input.maxCompletionTokens ?? 4096;
  const tokenArgs = model.startsWith("gpt-")
    ? { max_completion_tokens: tokenLimit }
    : { maxTokens: tokenLimit };
  const messages = [
    { role: "system" as const, content: input.system },
    { role: "user" as const, content: input.user },
  ];
  const initial = await invokeLLM({ model, messages, response_format: responseFormat, ...tokenArgs });
  let content = textFromResponse(initial);
  if (!content) {
    // Documented recovery: retry once without response_format only when the
    // model returned no content. The resulting text is still parsed and validated.
    const retry = await invokeLLM({
      model,
      messages: [...messages, { role: "user", content: "Return the requested result as one JSON object only." }],
      ...tokenArgs,
    });
    content = textFromResponse(retry);
  }
  if (!content) throw new Error("The analysis service returned an empty result.");
  return input.validator.parse(parseObject(content));
}

export const boundedString = (value: string, max: number) => value.replace(/\u0000/g, "").trim().slice(0, max);
