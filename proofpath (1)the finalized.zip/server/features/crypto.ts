import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  hkdfSync,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";

function deriveKey(purpose: string, salt: Buffer): Buffer {
  const sessionSecret = process.env.MANUS_JWT_SECRET;
  if (!sessionSecret || Buffer.byteLength(sessionSecret, "utf8") < 16) {
    throw new Error("Server-side resume encryption is unavailable because the managed session secret is missing or too short. No user-supplied encryption key is needed; the site administrator must restore the built-in server session secret before retrying.");
  }
  return Buffer.from(
    hkdfSync("sha256", Buffer.from(sessionSecret, "utf8"), salt, Buffer.from(`proofpath:${purpose}:v1`), 32),
  );
}

export function encryptObject(plain: Buffer, purpose: string): { saltHex: string; bytes: Buffer } {
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", deriveKey(purpose, salt), iv);
  cipher.setAAD(Buffer.from(`proofpath:${purpose}:v1`));
  const encrypted = Buffer.concat([cipher.update(plain), cipher.final()]);
  return { saltHex: salt.toString("hex"), bytes: Buffer.concat([iv, cipher.getAuthTag(), encrypted]) };
}

export function decryptObject(bytes: Buffer, saltHex: string, purpose: string): Buffer {
  if (!/^[a-f0-9]{32}$/i.test(saltHex) || bytes.length < 28) {
    throw new Error("Stored encrypted object is invalid.");
  }
  const salt = Buffer.from(saltHex, "hex");
  const iv = bytes.subarray(0, 12);
  const tag = bytes.subarray(12, 28);
  const ciphertext = bytes.subarray(28);
  const decipher = createDecipheriv("aes-256-gcm", deriveKey(purpose, salt), iv);
  decipher.setAAD(Buffer.from(`proofpath:${purpose}:v1`));
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

export function encryptText(value: string, purpose: string): string {
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", deriveKey(purpose, salt), iv);
  cipher.setAAD(Buffer.from(`proofpath:${purpose}:v1`));
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return [salt, iv, cipher.getAuthTag(), encrypted].map(part => part.toString("base64url")).join(".");
}

export function decryptText(value: string, purpose: string): string {
  const [saltPart, ivPart, tagPart, ciphertextPart, extra] = value.split(".");
  if (!saltPart || !ivPart || !tagPart || !ciphertextPart || extra) {
    throw new Error("Stored encrypted value is invalid.");
  }
  const salt = Buffer.from(saltPart, "base64url");
  const iv = Buffer.from(ivPart, "base64url");
  const tag = Buffer.from(tagPart, "base64url");
  const ciphertext = Buffer.from(ciphertextPart, "base64url");
  if (salt.length !== 16 || iv.length !== 12 || tag.length !== 16) {
    throw new Error("Stored encrypted value is invalid.");
  }
  const decipher = createDecipheriv("aes-256-gcm", deriveKey(purpose, salt), iv);
  decipher.setAAD(Buffer.from(`proofpath:${purpose}:v1`));
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
}

export const sha256Hex = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");

export function verifyGithubSignature(rawBody: Buffer, signature: string | undefined, secret: string): boolean {
  if (!signature || !/^sha256=[a-f0-9]{64}$/i.test(signature) || !secret) return false;
  const expected = `sha256=${createHmac("sha256", secret).update(rawBody).digest("hex")}`;
  const suppliedBytes = Buffer.from(signature, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  return suppliedBytes.length === expectedBytes.length && timingSafeEqual(suppliedBytes, expectedBytes);
}
