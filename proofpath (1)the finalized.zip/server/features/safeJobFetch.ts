import { lookup } from "node:dns/promises";
import { isIP, type LookupFunction } from "node:net";
import * as http from "node:http";
import * as https from "node:https";

const MAX_BYTES = 1_000_000;
const MAX_REDIRECTS = 3;
const TIMEOUT_MS = 9_000;

function publicIp(address: string): boolean {
  if (isIP(address) === 4) {
    const parts = address.split(".").map(Number);
    const [a, b] = parts;
    if (a === 0 || a === 10 || a === 127 || a >= 224) return false;
    if (a === 169 && b === 254) return false;
    if (a === 172 && b >= 16 && b <= 31) return false;
    if (a === 192 && b === 168) return false;
    if (a === 100 && b >= 64 && b <= 127) return false;
    if (a === 198 && (b === 18 || b === 19)) return false;
    if (a === 192 && b === 0) return false;
    return parts.length === 4;
  }
  if (isIP(address) === 6) {
    const normalized = address.toLowerCase();
    if (normalized.startsWith("::ffff:")) {
      const mapped = normalized.slice(7);
      if (isIP(mapped) === 4) return publicIp(mapped);
      const groups = mapped.split(":");
      if (groups.length === 2) {
        const high = Number.parseInt(groups[0], 16);
        const low = Number.parseInt(groups[1], 16);
        return publicIp(`${high >> 8}.${high & 255}.${low >> 8}.${low & 255}`);
      }
      return false;
    }
    if (normalized === "::" || normalized === "::1") return false;
    if (/^(fc|fd|fe8|fe9|fea|feb|ff)/i.test(normalized)) return false;
    if (/^2001:(db8|0|10)(:|$)/i.test(normalized)) return false;
    // Global unicast allocations are in 2000::/3. Discard the remaining
    // special-use/reserved ranges rather than attempting to fetch them.
    return /^[23]/.test(normalized);
  }
  return false;
}

async function resolvePublicAddress(hostname: string) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (!host || isIP(host) || host === "localhost" || /\.(localhost|local|internal|test|invalid)$/.test(host)) {
    throw new Error("Enter a publicly reachable HTTP(S) job posting URL.");
  }
  const addresses = await lookup(host, { all: true, verbatim: true });
  if (!addresses.length || addresses.some(entry => !publicIp(entry.address))) {
    throw new Error("The job posting host did not resolve to a public address.");
  }
  return addresses[0];
}

function oneRequest(url: URL): Promise<{ status: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
  return new Promise(async (resolve, reject) => {
    let address;
    try {
      address = await resolvePublicAddress(url.hostname);
    } catch (error) {
      reject(error);
      return;
    }
    const pinnedLookup = ((_: string, __: unknown, callback: (error: NodeJS.ErrnoException | null, address: string, family: number) => void) => {
      callback(null, address.address, address.family);
    }) as unknown as LookupFunction;
    const options: http.RequestOptions = {
      protocol: url.protocol,
      hostname: url.hostname,
      port: url.port || undefined,
      path: `${url.pathname || "/"}${url.search}`,
      method: "GET",
      headers: {
        "User-Agent": "ProofPath/1.0 (+job-posting import)",
        Accept: "text/html,application/xhtml+xml,text/plain;q=0.9",
        "Accept-Encoding": "identity",
      },
      lookup: pinnedLookup,
      timeout: TIMEOUT_MS,
    };
    const req = url.protocol === "https:"
      ? https.request({ ...options, servername: url.hostname })
      : http.request(options);
    let settled = false;
    const finish = (error?: Error, result?: { status: number; headers: http.IncomingHttpHeaders; body: Buffer }) => {
      if (settled) return;
      settled = true;
      if (error) reject(error);
      else if (result) resolve(result);
    };
    req.on("timeout", () => req.destroy(new Error("The job page took too long to respond.")));
    req.on("error", error => finish(error));
    req.on("response", response => {
      const chunks: Buffer[] = [];
      let size = 0;
      response.on("data", (chunk: Buffer) => {
        size += chunk.length;
        if (size > MAX_BYTES) {
          req.destroy(new Error("The job page exceeds the 1 MB import limit."));
          return;
        }
        chunks.push(Buffer.from(chunk));
      });
      response.on("end", () => finish(undefined, {
        status: response.statusCode ?? 0,
        headers: response.headers,
        body: Buffer.concat(chunks),
      }));
      response.on("error", error => finish(error));
    });
    req.end();
  });
}

function decodeEntities(value: string): string {
  return value.replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_, number: string) => String.fromCodePoint(Math.min(0x10ffff, Number(number))))
    .replace(/&#x([0-9a-f]+);/gi, (_, number: string) => String.fromCodePoint(Math.min(0x10ffff, Number.parseInt(number, 16))));
}

export function htmlToReadableText(html: string): { title: string | null; text: string } {
  const titleRaw = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? null;
  const text = html
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(script|style|noscript|svg|nav|footer|header|form|iframe)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article|br)\s*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\s*\n\s*/g, "\n")
    .trim();
  return {
    title: titleRaw ? decodeEntities(titleRaw.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim().slice(0, 255) : null,
    text: decodeEntities(text).slice(0, 150_000),
  };
}

function standardPort(url: URL): boolean {
  return !url.port || (url.protocol === "http:" && url.port === "80") || (url.protocol === "https:" && url.port === "443");
}

export async function fetchJobPosting(urlValue: string): Promise<{ finalUrl: string; title: string | null; text: string }> {
  let url: URL;
  try {
    url = new URL(urlValue);
  } catch {
    throw new Error("Enter a valid public job posting URL.");
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || !standardPort(url)) {
    throw new Error("Only public HTTP(S) job posting URLs on standard ports are supported.");
  }
  const startsHttps = url.protocol === "https:";
  for (let redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
    const response = await oneRequest(url);
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      if (redirect === MAX_REDIRECTS) throw new Error("The job page redirected too many times.");
      const location = response.headers.location;
      if (!location) throw new Error("The job page returned an invalid redirect.");
      const next = new URL(location, url);
      if (!["http:", "https:"].includes(next.protocol) || next.username || next.password || !standardPort(next) || (startsHttps && next.protocol !== "https:")) {
        throw new Error("The job page attempted an unsafe redirect.");
      }
      url = next;
      continue;
    }
    if (response.status < 200 || response.status >= 300) {
      throw new Error(`The job page could not be fetched (HTTP ${response.status}). Paste the description instead.`);
    }
    const contentType = String(response.headers["content-type"] ?? "").toLowerCase();
    if (!/^(text\/html|application\/xhtml\+xml|text\/plain)(;|$)/.test(contentType)) {
      throw new Error("This job source is not a supported HTML or text page. Paste the job description instead.");
    }
    const html = response.body.toString("utf8");
    const parsed = htmlToReadableText(html);
    if (parsed.text.length < 120) throw new Error("The job page did not contain readable description text. Paste the job description instead.");
    return { finalUrl: url.toString(), ...parsed };
  }
  throw new Error("The job page could not be fetched.");
}
