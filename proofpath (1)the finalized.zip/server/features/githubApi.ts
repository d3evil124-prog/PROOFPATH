import { and, desc, eq, inArray, isNull, ne } from "drizzle-orm";
import { githubConnections, githubInstallations, githubRepositories } from "../../drizzle/schema";
import { getDb } from "../db";
import { decryptText, encryptText } from "./crypto";
import { isVerifiedPublicRepository, parsePublicRepositoryUrl } from "./githubPublicPolicy";

const API = "https://api.github.com";
const API_VERSION = "2022-11-28";
const APP_POLL_INTERVAL_MS = 30_000;
const PUBLIC_LINK_POLL_INTERVAL_MS = 60_000;

export function pollInterval(repository: Pick<typeof githubRepositories.$inferSelect, "accessMode">) {
  return repository.accessMode === "public_link"
    ? PUBLIC_LINK_POLL_INTERVAL_MS
    : APP_POLL_INTERVAL_MS;
}

export class GitHubApiError extends Error {
  constructor(message: string, readonly status?: number, readonly rateLimited = false) {
    super(message);
    this.name = "GitHubApiError";
  }
}

export type GitHubRepository = {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  default_branch: string;
  owner: { login: string };
};
export type GitHubTreeEntry = { path: string; mode: string; type: "blob" | "tree" | "commit"; sha: string; size?: number };
export type GitHubChangedFile = { filename: string; status: string; previous_filename?: string; patch?: string };

export function githubConfigurationMissing(includeWebhook = false): string[] {
  const names = ["GITHUB_APP_CLIENT_ID", "GITHUB_APP_CLIENT_SECRET", "GITHUB_APP_SLUG", "GITHUB_CALLBACK_URL"];
  if (includeWebhook) names.push("GITHUB_WEBHOOK_SECRET");
  return names.filter(name => !process.env[name]?.trim());
}

export function githubTokenConfigured(): boolean {
  return Boolean(process.env.GITHUB_TOKEN?.trim());
}

export function githubInstallUrl(): string | null {
  const slug = process.env.GITHUB_APP_SLUG?.trim();
  return slug && /^[a-zA-Z0-9-]+$/.test(slug) ? `https://github.com/apps/${slug}/installations/new` : null;
}

function parseJson<T>(value: unknown, message: string): T {
  if (!value || typeof value !== "object") throw new GitHubApiError(message);
  return value as T;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function githubRequest<T>(token: string | null, route: string, init: RequestInit = {}): Promise<T> {
  if (!route.startsWith("/") || route.startsWith("//")) throw new Error("Invalid GitHub API path.");
  const url = new URL(route, API);
  if (url.origin !== API) throw new Error("Invalid GitHub API host.");
  for (let attempt = 0; attempt < 4; attempt++) {
    let response: Response;
    try {
      response = await fetch(url, {
        ...init,
        signal: AbortSignal.timeout(15_000),
        headers: {
          Accept: "application/vnd.github+json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          "X-GitHub-Api-Version": API_VERSION,
          "User-Agent": "ProofPath",
          ...(init.headers ?? {}),
        },
      });
    } catch {
      if (attempt === 3) throw new GitHubApiError("GitHub could not be reached. Retry synchronization later.");
      await sleep(400 * 2 ** attempt);
      continue;
    }
    if (response.ok) return (await response.json()) as T;
    const remaining = response.headers.get("x-ratelimit-remaining");
    const retryAfter = Number(response.headers.get("retry-after") ?? 0);
    const rateLimited = response.status === 429 || response.status === 403 && (remaining === "0" || retryAfter > 0);
    if (rateLimited && attempt < 3) {
      const resetAt = Number(response.headers.get("x-ratelimit-reset") ?? 0) * 1000;
      const wait = retryAfter > 0 ? retryAfter * 1000 : remaining === "0" && resetAt > Date.now() ? resetAt - Date.now() : 1_000 * 2 ** attempt;
      if (wait <= 30_000) {
        await sleep(wait);
        continue;
      }
      throw new GitHubApiError("GitHub API rate limit reached. ProofPath will retry during a later sync.", response.status, true);
    }
    if (response.status >= 500 && attempt < 3) {
      await sleep(400 * 2 ** attempt);
      continue;
    }
    if (response.status === 401) throw new GitHubApiError(token ? "GitHub authorization expired or was revoked. Reconnect the account." : "GitHub did not allow anonymous access to this repository. Private repositories need an authenticated grant.", 401);
    if (response.status === 403) throw new GitHubApiError(token ? "GitHub denied this operation. Check the app's repository permissions and installation." : "GitHub's public API denied this request or reached its anonymous rate limit. Retry later.", 403, rateLimited);
    if (response.status === 404) throw new GitHubApiError("This repository, branch or commit is not publicly available.", 404);
    throw new GitHubApiError(`GitHub API request failed (HTTP ${response.status}).`, response.status);
  }
  throw new GitHubApiError("GitHub API request failed after retries.");
}

async function connectionForOwner(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [connection] = await db.select().from(githubConnections)
    .where(and(eq(githubConnections.ownerId, ownerId), eq(githubConnections.status, "connected")))
    .orderBy(desc(githubConnections.connectedAt)).limit(1);
  if (!connection) throw new GitHubApiError("No GitHub account is connected.");
  return connection;
}

async function refreshConnection(connection: typeof githubConnections.$inferSelect) {
  const refreshToken = connection.encryptedRefreshToken
    ? decryptText(connection.encryptedRefreshToken, "github-refresh-token")
    : "";
  const clientId = process.env.GITHUB_APP_CLIENT_ID?.trim();
  const clientSecret = process.env.GITHUB_APP_CLIENT_SECRET?.trim();
  if (!refreshToken || !clientId || !clientSecret) {
    const db = await getDb();
    if (db) await db.update(githubConnections).set({ status: "needs_reauthorization" }).where(eq(githubConnections.id, connection.id));
    throw new GitHubApiError("GitHub authorization expired. Reconnect the account.", 401);
  }
  const response = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, grant_type: "refresh_token", refresh_token: refreshToken }),
    signal: AbortSignal.timeout(15_000),
  });
  const body = await response.json().catch(() => ({})) as { access_token?: string; refresh_token?: string; expires_in?: number; refresh_token_expires_in?: number; error?: string };
  if (!response.ok || !body.access_token || !body.refresh_token) {
    const db = await getDb();
    if (db) await db.update(githubConnections).set({ status: "needs_reauthorization" }).where(eq(githubConnections.id, connection.id));
    throw new GitHubApiError("GitHub token refresh failed. Reconnect the account.", response.status);
  }
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  await db.update(githubConnections).set({
    encryptedAccessToken: encryptText(body.access_token, "github-access-token"),
    encryptedRefreshToken: encryptText(body.refresh_token, "github-refresh-token"),
    accessTokenExpiresAt: new Date(Date.now() + Math.max(60, body.expires_in ?? 28_800) * 1000),
    refreshTokenExpiresAt: new Date(Date.now() + Math.max(60, body.refresh_token_expires_in ?? 15_552_000) * 1000),
    status: "connected",
    lastCheckedAt: new Date(),
  }).where(eq(githubConnections.id, connection.id));
  return body.access_token;
}

export async function accessTokenForOwner(ownerId: number): Promise<string> {
  let connection: Awaited<ReturnType<typeof connectionForOwner>>;
  try {
    connection = await connectionForOwner(ownerId);
  } catch (error) {
    const token = process.env.GITHUB_TOKEN?.trim();
    if (token) return token;
    throw error;
  }
  if (connection.accessTokenExpiresAt && connection.accessTokenExpiresAt.getTime() < Date.now() + 90_000) {
    return refreshConnection(connection);
  }
  return decryptText(connection.encryptedAccessToken, "github-access-token");
}

export async function githubGet<T>(ownerId: number, route: string): Promise<T> {
  const token = await accessTokenForOwner(ownerId);
  return githubRequest<T>(token, route);
}

export async function githubGetForRepository<T>(
  ownerId: number,
  repository: typeof githubRepositories.$inferSelect,
  route: string,
): Promise<T> {
  return repository.accessMode === "public_link"
    ? githubRequest<T>(process.env.GITHUB_TOKEN?.trim() || null, route)
    : githubGet<T>(ownerId, route);
}

async function allPages<T>(ownerId: number, route: string, collectionName: string, repository?: typeof githubRepositories.$inferSelect): Promise<T[]> {
  const result: T[] = [];
  for (let page = 1; page <= 10; page++) {
    const separator = route.includes("?") ? "&" : "?";
    const path = `${route}${separator}per_page=100&page=${page}`;
    const response = repository
      ? await githubGetForRepository<unknown>(ownerId, repository, path)
      : await githubGet<unknown>(ownerId, path);
    const rows = Array.isArray(response) ? response : parseJson<Record<string, unknown>>(response, "Unexpected GitHub response.")[collectionName];
    if (!Array.isArray(rows)) throw new GitHubApiError("GitHub returned an unexpected list response.");
    result.push(...rows as T[]);
    if (rows.length < 100 || result.length >= 1000) break;
  }
  return result;
}

export async function syncAuthorizedRepositories(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const connection = await connectionForOwner(ownerId);
  const installations = await allPages<{ id: number; account?: { login?: string; type?: string } }>(ownerId, "/user/installations", "installations");
  const presentIds = new Set<number>();
  const repoIdsByInstallation: { installationRowId: number; installationId: number; repos: GitHubRepository[] }[] = [];

  for (const installation of installations) {
    const accountLogin = installation.account?.login ?? "unknown";
    const [existing] = await db.select().from(githubInstallations)
      .where(and(eq(githubInstallations.ownerId, ownerId), eq(githubInstallations.installationId, installation.id))).limit(1);
    let installationRowId = existing?.id;
    if (existing) {
      await db.update(githubInstallations).set({ connectionId: connection.id, accountLogin, accountType: installation.account?.type ?? "User", refreshedAt: new Date() }).where(eq(githubInstallations.id, existing.id));
    } else {
      const inserted = await db.insert(githubInstallations).values({ ownerId, connectionId: connection.id, installationId: installation.id, accountLogin, accountType: installation.account?.type ?? "User" });
      installationRowId = Number(inserted[0].insertId);
    }
    if (!installationRowId) continue;
    const repos = await allPages<GitHubRepository>(ownerId, `/user/installations/${installation.id}/repositories`, "repositories");
    repoIdsByInstallation.push({ installationRowId, installationId: installation.id, repos });
  }

  for (const group of repoIdsByInstallation) {
    for (const repo of group.repos) {
      if (!repo.id || !repo.owner?.login || !repo.name || !repo.default_branch) continue;
      presentIds.add(repo.id);
      const [old] = await db.select().from(githubRepositories)
        .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.githubRepositoryId, repo.id))).limit(1);
      if (old) {
        await db.update(githubRepositories).set({
          connectionId: connection.id,
          installationRowId: group.installationRowId,
          repositoryOwner: repo.owner.login,
          repositoryName: repo.name,
          defaultBranch: repo.default_branch,
          isPrivate: Boolean(repo.private),
          authorized: true,
          watcherStatus: old.selected ? old.watcherStatus : "paused",
        }).where(eq(githubRepositories.id, old.id));
      } else {
        await db.insert(githubRepositories).values({
          ownerId,
          connectionId: connection.id,
          installationRowId: group.installationRowId,
          githubRepositoryId: repo.id,
          repositoryOwner: repo.owner.login,
          repositoryName: repo.name,
          defaultBranch: repo.default_branch,
          isPrivate: Boolean(repo.private),
          authorized: true,
          selected: false,
          watcherStatus: "paused",
        });
      }
    }
  }

  const current = await db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.accessMode, "github_app")));
  for (const repository of current) {
    if (!presentIds.has(repository.githubRepositoryId)) {
      await db.update(githubRepositories).set({ authorized: false, selected: false, watcherStatus: "paused", nextPollAt: null })
        .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repository.id)));
    }
  }
  return db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.authorized, true), eq(githubRepositories.accessMode, "github_app")))
    .orderBy(desc(githubRepositories.selected), githubRepositories.repositoryOwner, githubRepositories.repositoryName);
}

export async function listTokenRepositories(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  if (!githubTokenConfigured()) return [];
  return db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.accessMode, "github_app"),
        eq(githubRepositories.authorized, true),
        isNull(githubRepositories.connectionId),
        isNull(githubRepositories.installationRowId)
      )
    )
    .orderBy(desc(githubRepositories.selected), githubRepositories.repositoryOwner, githubRepositories.repositoryName);
}

type RepositoryGrantState = Pick<typeof githubRepositories.$inferSelect, "ownerId" | "authorized" | "selected">;

export function canUseRepositoryGrant(repository: RepositoryGrantState, ownerId: number, requireSelection = false) {
  return repository.ownerId === ownerId && repository.authorized && (!requireSelection || repository.selected);
}

export async function listBranches(ownerId: number, repositoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [repository] = await db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId), eq(githubRepositories.authorized, true))).limit(1);
  if (!repository || !canUseRepositoryGrant(repository, ownerId)) throw new GitHubApiError("That repository is not in this user's current GitHub installation grant.");
  const rows = await allPages<{ name: string }>(ownerId, `/repos/${encodeURIComponent(repository.repositoryOwner)}/${encodeURIComponent(repository.repositoryName)}/branches`, "branches", repository);
  return rows.map(row => row.name).filter(name => typeof name === "string").slice(0, 200);
}

/** Verify a public repository URL without a GitHub account grant or app credentials. */
export async function addPublicRepositoryLink(ownerId: number, value: string) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const parsed = parsePublicRepositoryUrl(value);
  const repo = await githubRequest<GitHubRepository>(null, `/repos/${encodeURIComponent(parsed.owner)}/${encodeURIComponent(parsed.repository)}`);
  if (!isVerifiedPublicRepository(repo)) {
    throw new GitHubApiError("That repository is private or GitHub could not verify it as publicly accessible.", 404);
  }
  const inserted = await db.insert(githubRepositories).values({
    ownerId,
    connectionId: null,
    installationRowId: null,
    githubRepositoryId: repo.id,
    repositoryOwner: repo.owner.login,
    repositoryName: repo.name,
    defaultBranch: repo.default_branch,
    isPrivate: false,
    accessMode: "public_link",
    authorized: true,
    selected: false,
    branch: repo.default_branch,
    watcherStatus: "paused",
    nextPollAt: null,
  }).onDuplicateKeyUpdate({
    set: {
      connectionId: null,
      installationRowId: null,
      repositoryOwner: repo.owner.login,
      repositoryName: repo.name,
      defaultBranch: repo.default_branch,
      isPrivate: false,
      accessMode: "public_link",
      authorized: true,
      selected: false,
      branch: repo.default_branch,
      watcherStatus: "paused",
      nextPollAt: null,
    },
  });
  const id = Number(inserted[0].insertId);
  const [record] = await db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.githubRepositoryId, repo.id))).limit(1);
  if (!record || (!id && record.accessMode !== "public_link")) {
    throw new GitHubApiError("The public repository was verified but could not be saved to your account.");
  }
  return record;
}

/** Verify and save a private repository using the protected server-side token. */
export async function addTokenRepository(ownerId: number, value: string) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const token = process.env.GITHUB_TOKEN?.trim();
  if (!token) throw new GitHubApiError("A server GitHub token is not configured.", 503);
  const parsed = parsePublicRepositoryUrl(value);
  const repo = await githubRequest<GitHubRepository>(
    token,
    `/repos/${encodeURIComponent(parsed.owner)}/${encodeURIComponent(parsed.repository)}`
  );
  if (!repo.id || !repo.owner?.login || !repo.name || !repo.default_branch) {
    throw new GitHubApiError("GitHub did not return a usable repository.");
  }
  const [old] = await db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.githubRepositoryId, repo.id)
      )
    )
    .limit(1);
  const selected = old?.selected ?? false;
  const branch = old?.branch ?? repo.default_branch;
  await db
    .insert(githubRepositories)
    .values({
      ownerId,
      connectionId: null,
      installationRowId: null,
      githubRepositoryId: repo.id,
      repositoryOwner: repo.owner.login,
      repositoryName: repo.name,
      defaultBranch: repo.default_branch,
      isPrivate: Boolean(repo.private),
      accessMode: "github_app",
      authorized: true,
      selected,
      branch,
      watcherStatus: selected ? "active" : "paused",
      nextPollAt: null,
    })
    .onDuplicateKeyUpdate({
      set: {
        connectionId: null,
        installationRowId: null,
        repositoryOwner: repo.owner.login,
        repositoryName: repo.name,
        defaultBranch: repo.default_branch,
        isPrivate: Boolean(repo.private),
        accessMode: "github_app",
        authorized: true,
        selected,
        branch,
        watcherStatus: selected ? "active" : "paused",
        nextPollAt: null,
      },
    });
  const [record] = await db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.githubRepositoryId, repo.id)
      )
    )
    .limit(1);
  if (!record) throw new GitHubApiError("The repository was verified but could not be saved to your account.");
  return record;
}

export async function selectAuthorizedRepository(ownerId: number, repositoryId: number, branch?: string) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [repository] = await db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId), eq(githubRepositories.authorized, true))).limit(1);
  if (!repository || !canUseRepositoryGrant(repository, ownerId)) throw new GitHubApiError("That repository is not verified and available to this account.");
  const targetBranch = branch?.trim() || repository.defaultBranch;
  const branches = await listBranches(ownerId, repository.id);
  if (!branches.includes(targetBranch)) throw new GitHubApiError("The requested branch is not available in this repository.");
  const selected = await db.update(githubRepositories).set({
    selected: true,
    branch: targetBranch,
    watcherStatus: "active",
    nextPollAt: new Date(Date.now() + pollInterval(repository)),
  }).where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repository.id), eq(githubRepositories.authorized, true)));
  if (!Number((selected[0] as { affectedRows?: number }).affectedRows ?? 0)) {
    throw new GitHubApiError("Repository authorization changed before it could be selected. Refresh the GitHub repository list.");
  }
  return { ...repository, selected: true, branch: targetBranch, watcherStatus: "active" as const };
}

export async function repositoryForOwner(ownerId: number, repositoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [repository] = await db.select().from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId), eq(githubRepositories.authorized, true), eq(githubRepositories.selected, true))).limit(1);
  if (!repository || !canUseRepositoryGrant(repository, ownerId, true)) throw new GitHubApiError("The selected repository is unavailable or no longer authorized.");
  return repository;
}

export async function latestCommit(ownerId: number, repository: typeof githubRepositories.$inferSelect, branch = repository.branch ?? repository.defaultBranch) {
  return githubGetForRepository<{ sha: string; commit: { message: string; committer?: { date?: string } } }>(
    ownerId, repository,
    `/repos/${encodeURIComponent(repository.repositoryOwner)}/${encodeURIComponent(repository.repositoryName)}/commits/${encodeURIComponent(branch)}`,
  );
}

export async function compareCommits(ownerId: number, repository: typeof githubRepositories.$inferSelect, base: string, head: string) {
  const result = await githubGetForRepository<{ files?: GitHubChangedFile[]; commits?: { sha: string; commit: { message: string } }[] }>(
    ownerId, repository,
    `/repos/${encodeURIComponent(repository.repositoryOwner)}/${encodeURIComponent(repository.repositoryName)}/compare/${encodeURIComponent(base)}...${encodeURIComponent(head)}`,
  );
  return { files: (result.files ?? []).slice(0, 300), commits: (result.commits ?? []).slice(0, 100) };
}

export async function repositoryTree(ownerId: number, repository: typeof githubRepositories.$inferSelect, sha: string) {
  const owner = encodeURIComponent(repository.repositoryOwner);
  const name = encodeURIComponent(repository.repositoryName);
  const tree = await githubGetForRepository<{ tree?: GitHubTreeEntry[]; truncated?: boolean }>(ownerId, repository, `/repos/${owner}/${name}/git/trees/${encodeURIComponent(sha)}?recursive=1`);
  return { entries: (tree.tree ?? []).filter(item => item.type === "blob").slice(0, 5000), truncated: Boolean(tree.truncated) };
}

export async function repositoryBlob(ownerId: number, repository: typeof githubRepositories.$inferSelect, blobSha: string): Promise<Buffer> {
  const owner = encodeURIComponent(repository.repositoryOwner);
  const name = encodeURIComponent(repository.repositoryName);
  const blob = await githubGetForRepository<{ encoding?: string; content?: string; size?: number }>(ownerId, repository, `/repos/${owner}/${name}/git/blobs/${encodeURIComponent(blobSha)}`);
  if (blob.encoding !== "base64" || typeof blob.content !== "string" || (blob.size ?? 0) > 120_000) {
    throw new GitHubApiError("A repository file is too large or is not available as text.");
  }
  return Buffer.from(blob.content.replace(/\s/g, ""), "base64");
}

export async function updateRepositoryHead(ownerId: number, repositoryId: number, sha: string) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [repository] = await db.select({ accessMode: githubRepositories.accessMode }).from(githubRepositories)
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId))).limit(1);
  await db.update(githubRepositories).set({
    latestObservedSha: sha,
    lastSyncedAt: new Date(),
    nextPollAt: new Date(Date.now() + pollInterval(repository ?? { accessMode: "github_app" })),
    watcherStatus: "active",
  }).where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId)));
}

export async function pauseRepository(ownerId: number, repositoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  await db.update(githubRepositories).set({ selected: false, watcherStatus: "paused", nextPollAt: null })
    .where(and(eq(githubRepositories.ownerId, ownerId), eq(githubRepositories.id, repositoryId)));
}
