import { and, asc, eq } from "drizzle-orm";
import { resumeChunks } from "../../drizzle/schema";
import { getDb } from "../db";
import { decryptText } from "./crypto";

export type ResumePassage = {
  chunkId: number;
  chunkIndex: number;
  score: number;
  text: string;
};

const MAX_CHUNK_CHARS = 1_600;
const OVERLAP_CHARS = 180;
const MAX_CHUNKS = 120;
const STOP_WORDS = new Set([
  "about", "above", "after", "again", "against", "also", "among", "and", "any", "are", "because", "been", "before", "being", "below", "between", "both", "but", "can", "could", "does", "doing", "during", "each", "few", "for", "from", "further", "have", "having", "here", "into", "itself", "more", "most", "other", "over", "same", "should", "some", "such", "than", "that", "the", "their", "them", "then", "there", "these", "they", "this", "those", "through", "under", "until", "very", "was", "were", "what", "when", "where", "which", "while", "will", "with", "would", "your",
]);

export function splitResumeText(value: string): string[] {
  const text = value
    .replace(/\u0000/g, " ")
    .replace(/\r\n?/g, "\n")
    .replace(/[\t ]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!text) return [];

  const chunks: string[] = [];
  let start = 0;
  while (start < text.length && chunks.length < MAX_CHUNKS) {
    let end = Math.min(text.length, start + MAX_CHUNK_CHARS);
    if (end < text.length) {
      const paragraph = text.lastIndexOf("\n\n", end);
      const sentence = text.lastIndexOf(". ", end);
      const boundary = Math.max(paragraph, sentence);
      if (boundary > start + Math.floor(MAX_CHUNK_CHARS * 0.65)) end = boundary + 1;
    }
    const chunk = text.slice(start, end).trim();
    if (chunk) chunks.push(chunk);
    if (end >= text.length) break;
    start = Math.max(start + 1, end - OVERLAP_CHARS);
  }
  return chunks;
}

function tokenize(value: string): string[] {
  return (value.toLowerCase().match(/[a-z0-9][a-z0-9+#.-]{1,}/g) ?? [])
    .filter(token => token.length > 2 && !STOP_WORDS.has(token));
}

export function rankResumePassages(
  passages: { chunkId: number; chunkIndex: number; text: string }[],
  query: string,
  limit = 2,
): ResumePassage[] {
  const queryTerms = [...new Set(tokenize(query))];
  if (!queryTerms.length || !passages.length) return [];

  const documents = passages.map(passage => ({
    ...passage,
    tokens: tokenize(passage.text),
  }));
  const documentFrequency = new Map<string, number>();
  for (const term of queryTerms) {
    documentFrequency.set(
      term,
      documents.filter(document => document.tokens.includes(term)).length,
    );
  }
  const averageLength = Math.max(
    1,
    documents.reduce((total, document) => total + document.tokens.length, 0) /
      documents.length,
  );

  return documents
    .map(document => {
      let score = 0;
      for (const term of queryTerms) {
        const frequency = document.tokens.filter(token => token === term).length;
        if (!frequency) continue;
        const idf = Math.log(
          1 +
            (documents.length - (documentFrequency.get(term) ?? 0) + 0.5) /
              ((documentFrequency.get(term) ?? 0) + 0.5),
        );
        const lengthNorm =
          1.2 * (0.25 + 0.75 * (document.tokens.length / averageLength));
        score += idf * ((frequency * 2.2) / (frequency + lengthNorm));
      }
      return {
        chunkId: document.chunkId,
        chunkIndex: document.chunkIndex,
        score,
        text: document.text.slice(0, 1_000),
      };
    })
    .filter(item => item.score > 0)
    .sort((left, right) => right.score - left.score || left.chunkIndex - right.chunkIndex)
    .slice(0, Math.max(1, Math.min(limit, 5)))
    .map(item => ({ ...item, score: Math.round(item.score * 1_000) / 1_000 }));
}

export async function retrieveResumePassages(
  ownerId: number,
  resumeId: number,
  requirements: { id: number; skill: string; originalWording: string }[],
): Promise<Map<number, ResumePassage[]>> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const rows = await db
    .select()
    .from(resumeChunks)
    .where(and(eq(resumeChunks.ownerId, ownerId), eq(resumeChunks.resumeId, resumeId)))
    .orderBy(asc(resumeChunks.chunkIndex));
  const passages = rows.map(row => ({
    chunkId: row.id,
    chunkIndex: row.chunkIndex,
    text: decryptText(row.encryptedContent, "resume-chunk"),
  }));
  return new Map(
    requirements.map(requirement => [
      requirement.id,
      rankResumePassages(
        passages,
        `${requirement.skill} ${requirement.originalWording}`,
        2,
      ),
    ]),
  );
}
