import { and, desc, eq, inArray } from "drizzle-orm";
import {
  assessmentVersions,
  jobPostings,
  jobRequirements,
  resumes,
  resumeChunks,
  skillAssessments,
  type ResumeProfileData,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { decryptText, encryptObject, encryptText, sha256Hex } from "./crypto";
import { extractResumeProfile } from "./extraction";
import { retrieveResumePassages, splitResumeText } from "./resumeRag";
import { extractResumeText, type ResumeMime } from "./resumeParser";

export type ResumeSummary = {
  id: number;
  originalName: string;
  mimeType: ResumeMime;
  byteSize: number;
  uploadedAt: Date;
  chunkCount?: number;
  parsedProfile: ResumeProfileData;
};

function safeFileName(value: string): string {
  const name = value.replace(/\\/g, "/").split("/").pop() ?? "resume";
  const safe = name
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/[^\w.() -]/g, "_")
    .trim()
    .slice(0, 240);
  return safe || "resume";
}

function emptyProfile(): ResumeProfileData {
  return {
    technicalSkills: [],
    projects: [],
    experience: [],
    education: [],
    certifications: [],
  };
}

function profileForRow(row: typeof resumes.$inferSelect): ResumeProfileData {
  if (!row.profileCiphertext) return row.parsedProfile;
  try {
    return JSON.parse(
      decryptText(row.profileCiphertext, "resume-profile"),
    ) as ResumeProfileData;
  } catch {
    throw new Error(
      "This resume cannot be decrypted with the current server key. Remove it and upload the file again.",
    );
  }
}

function toSummary(row: typeof resumes.$inferSelect): ResumeSummary {
  return {
    id: row.id,
    originalName: row.originalName,
    mimeType: row.mimeType as ResumeMime,
    byteSize: row.byteSize,
    uploadedAt: row.uploadedAt,
    parsedProfile: profileForRow(row),
  };
}

export async function uploadAndExtractResume(
  ownerId: number,
  originalNameValue: string,
  mimeType: ResumeMime,
  bytes: Buffer,
): Promise<ResumeSummary> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const originalName = safeFileName(originalNameValue);
  const text = await extractResumeText(bytes, mimeType, originalName);
  const parsedProfile = await extractResumeProfile(text);
  const chunks = splitResumeText(text);
  if (!chunks.length) throw new Error("The resume did not contain readable text.");

  const encryptedFile = encryptObject(bytes, "resume-file");
  const profileCiphertext = encryptText(
    JSON.stringify(parsedProfile),
    "resume-profile",
  );
  const storedRow = await db.transaction(async tx => {
    const inserted = await tx.insert(resumes).values({
      ownerId,
      originalName,
      mimeType,
      byteSize: bytes.length,
      fileSha256: sha256Hex(bytes),
      encryptedObjectKey: null,
      encryptionSaltHex: encryptedFile.saltHex,
      encryptedFile: encryptedFile.bytes.toString("base64url"),
      profileCiphertext,
      // Keep the legacy non-null column without duplicating sensitive plaintext.
      parsedProfile: emptyProfile(),
    });
    const resumeId = Number(inserted[0].insertId);
    if (!Number.isSafeInteger(resumeId) || resumeId < 1) {
      throw new Error("The resume could not be stored in the database.");
    }
    await tx.insert(resumeChunks).values(
      chunks.map((chunk, chunkIndex) => ({
        ownerId,
        resumeId,
        chunkIndex,
        encryptedContent: encryptText(chunk, "resume-chunk"),
      })),
    );
    const [row] = await tx
      .select()
      .from(resumes)
      .where(and(eq(resumes.ownerId, ownerId), eq(resumes.id, resumeId)))
      .limit(1);
    if (!row) throw new Error("The stored resume could not be verified.");
    return row;
  });
  return { ...toSummary(storedRow), chunkCount: chunks.length };
}

export async function latestResume(ownerId: number): Promise<ResumeSummary | null> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [row] = await db
    .select()
    .from(resumes)
    .where(eq(resumes.ownerId, ownerId))
    .orderBy(desc(resumes.uploadedAt))
    .limit(1);
  return row ? toSummary(row) : null;
}

export async function listResumes(ownerId: number): Promise<ResumeSummary[]> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const rows = await db
    .select()
    .from(resumes)
    .where(eq(resumes.ownerId, ownerId))
    .orderBy(desc(resumes.uploadedAt))
    .limit(30);
  return rows.map(toSummary);
}

export async function removeResume(ownerId: number, resumeId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const linkedAssessments = await db
    .select({ id: assessmentVersions.id })
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, ownerId),
        eq(assessmentVersions.resumeId, resumeId),
      ),
    );
  if (linkedAssessments.length) {
    await db
      .update(skillAssessments)
      .set({ resumeMentioned: false, resumeSupport: null, resumeChunkIds: null })
      .where(
        and(
          eq(skillAssessments.ownerId, ownerId),
          inArray(
            skillAssessments.assessmentId,
            linkedAssessments.map(item => item.id),
          ),
        ),
      );
  }
  await db
    .delete(resumes)
    .where(and(eq(resumes.ownerId, ownerId), eq(resumes.id, resumeId)));
}

export async function compareResumeVersions(
  ownerId: number,
  firstResumeId: number,
  secondResumeId: number,
  jobId: number,
) {
  if (firstResumeId === secondResumeId) {
    throw new Error("Choose two different resume versions to compare.");
  }
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db
    .select({ id: jobPostings.id, title: jobPostings.title })
    .from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId)))
    .limit(1);
  if (!job) throw new Error("Job posting not found.");
  const owned = await db
    .select()
    .from(resumes)
    .where(
      and(
        eq(resumes.ownerId, ownerId),
        inArray(resumes.id, [firstResumeId, secondResumeId]),
      ),
    );
  const first = owned.find(row => row.id === firstResumeId);
  const second = owned.find(row => row.id === secondResumeId);
  if (!first || !second) throw new Error("Resume version not found.");
  const requirements = await db
    .select({
      id: jobRequirements.id,
      skill: jobRequirements.skill,
      originalWording: jobRequirements.originalWording,
    })
    .from(jobRequirements)
    .where(
      and(
        eq(jobRequirements.ownerId, ownerId),
        eq(jobRequirements.jobId, jobId),
      ),
    );
  const [firstMatches, secondMatches] = await Promise.all([
    retrieveResumePassages(ownerId, firstResumeId, requirements),
    retrieveResumePassages(ownerId, secondResumeId, requirements),
  ]);
  return {
    job,
    first: toSummary(first),
    second: toSummary(second),
    requirements: requirements.map(requirement => ({
      ...requirement,
      firstMatches: firstMatches.get(requirement.id) ?? [],
      secondMatches: secondMatches.get(requirement.id) ?? [],
    })),
  };
}
