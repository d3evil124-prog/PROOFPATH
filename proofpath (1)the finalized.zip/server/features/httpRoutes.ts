import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import { and, eq, gt, isNull, lt, or } from "drizzle-orm";
import {
  githubConnections,
  githubInstallations,
  githubRepositories,
  githubWebhookDeliveries,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { queueCommitForRepository } from "./assessment";
import { authenticateRequestOrNull } from "./httpAuth";
import {
  githubConfigurationMissing,
  syncAuthorizedRepositories,
  type GitHubRepository,
} from "./githubApi";
import { verifyGithubSignature } from "./crypto";
import { uploadAndExtractResume } from "./resumeService";
import { DOCX_MIME, MAX_RESUME_BYTES, PDF_MIME } from "./resumeParser";
import {
  classifyGitHubWebhook,
  processWebhookDelivery,
  type WebhookDeliveryMetadata,
  type WebhookDeliveryStore,
} from "./webhookPolicy";

const resumeRawParser = express.raw({
  type: ["application/octet-stream", PDF_MIME, DOCX_MIME],
  limit: MAX_RESUME_BYTES,
});

function parseResumeBody(req: Request, res: Response, next: NextFunction) {
  resumeRawParser(req, res, error => {
    if (!error) {
      next();
      return;
    }
    const parserError = error as { status?: number; type?: string };
    const tooLarge =
      parserError.status === 413 || parserError.type === "entity.too.large";
    res
      .status(tooLarge ? 413 : 400)
      .set("Cache-Control", "no-store")
      .json({
        error: tooLarge
          ? "Resume uploads cannot exceed 5 MiB (5,242,880 bytes)."
          : "The resume upload body could not be parsed.",
      });
  });
}

function publicError(error: unknown) {
  return error instanceof Error
    ? error.message.slice(0, 500)
    : "The request could not be completed.";
}

type ProofPathDb = NonNullable<Awaited<ReturnType<typeof getDb>>>;

function affectedRows(result: unknown) {
  return Number(
    (result as [{ affectedRows?: number }] | undefined)?.[0]?.affectedRows ?? 0
  );
}

function webhookDeliveryStore(db: ProofPathDb): WebhookDeliveryStore {
  return {
    ensure: async (metadata: WebhookDeliveryMetadata) => {
      await db
        .insert(githubWebhookDeliveries)
        .values(metadata)
        .onDuplicateKeyUpdate({ set: { deliveryId: metadata.deliveryId } });
    },
    tryClaim: async (deliveryId, token, now, leaseUntil) => {
      const updated = await db
        .update(githubWebhookDeliveries)
        .set({ processingToken: token, processingLeaseUntil: leaseUntil })
        .where(
          and(
            eq(githubWebhookDeliveries.deliveryId, deliveryId),
            isNull(githubWebhookDeliveries.processedAt),
            or(
              isNull(githubWebhookDeliveries.processingLeaseUntil),
              lt(githubWebhookDeliveries.processingLeaseUntil, now)
            )
          )
        );
      return affectedRows(updated) > 0;
    },
    renew: async (deliveryId, token, now, leaseUntil) => {
      const updated = await db
        .update(githubWebhookDeliveries)
        .set({ processingLeaseUntil: leaseUntil })
        .where(
          and(
            eq(githubWebhookDeliveries.deliveryId, deliveryId),
            eq(githubWebhookDeliveries.processingToken, token),
            isNull(githubWebhookDeliveries.processedAt),
            gt(githubWebhookDeliveries.processingLeaseUntil, now)
          )
        );
      return affectedRows(updated) > 0;
    },
    isProcessed: async deliveryId => {
      const [row] = await db
        .select({ processedAt: githubWebhookDeliveries.processedAt })
        .from(githubWebhookDeliveries)
        .where(eq(githubWebhookDeliveries.deliveryId, deliveryId))
        .limit(1);
      return Boolean(row?.processedAt);
    },
    complete: async (deliveryId, token, now) => {
      const updated = await db
        .update(githubWebhookDeliveries)
        .set({
          processedAt: now,
          processingToken: null,
          processingLeaseUntil: null,
        })
        .where(
          and(
            eq(githubWebhookDeliveries.deliveryId, deliveryId),
            eq(githubWebhookDeliveries.processingToken, token),
            isNull(githubWebhookDeliveries.processedAt),
            gt(githubWebhookDeliveries.processingLeaseUntil, now)
          )
        );
      return affectedRows(updated) > 0;
    },
    release: async (deliveryId, token) => {
      await db
        .update(githubWebhookDeliveries)
        .set({ processingToken: null, processingLeaseUntil: null })
        .where(
          and(
            eq(githubWebhookDeliveries.deliveryId, deliveryId),
            eq(githubWebhookDeliveries.processingToken, token),
            isNull(githubWebhookDeliveries.processedAt)
          )
        );
    },
  };
}

export function registerProofPathHttpRoutes(app: Express) {
  app.post(
    "/api/resumes/upload",
    parseResumeBody,
    async (req: Request, res: Response) => {
      try {
        const user = await authenticateRequestOrNull(req);
        if (!user) {
          res
            .status(401)
            .set("Cache-Control", "no-store")
            .json({ error: "Sign in before uploading a resume." });
          return;
        }
        if (!Buffer.isBuffer(req.body)) {
          res
            .status(415)
            .set("Cache-Control", "no-store")
            .json({ error: "Upload a PDF or DOCX file as raw file bytes." });
          return;
        }
        const contentType = String(
          req.header("x-resume-mime") ?? req.header("content-type") ?? ""
        )
          .split(";")[0]
          .trim()
          .toLowerCase();
        if (contentType !== PDF_MIME && contentType !== DOCX_MIME) {
          res.status(415).set("Cache-Control", "no-store").json({
            error: "Unsupported resume format. Upload a PDF or DOCX file.",
          });
          return;
        }
        let fileName = req.header("x-file-name") ?? "resume";
        try {
          fileName = decodeURIComponent(fileName);
        } catch {
          /* validation below returns a clear file error */
        }
        const resume = await uploadAndExtractResume(
          user.id,
          fileName,
          contentType,
          req.body
        );
        res.status(201).set("Cache-Control", "no-store").json({ resume });
      } catch (error) {
        const message = publicError(error);
        const code =
          /unsupported|must be between|not a readable|corrupted|unreadable|too little/i.test(
            message
          )
            ? 400
            : 500;
        res
          .status(code)
          .set("Cache-Control", "no-store")
          .json({ error: message });
      }
    }
  );

  app.post(
    "/api/github/webhook",
    express.raw({ type: "application/json", limit: "2mb" }),
    async (req: Request, res: Response) => {
      const secret = process.env.GITHUB_WEBHOOK_SECRET?.trim();
      if (!secret) {
        res
          .status(503)
          .set("Cache-Control", "no-store")
          .json({ error: "GitHub webhook is not configured." });
        return;
      }
      if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
        res
          .status(400)
          .set("Cache-Control", "no-store")
          .json({ error: "Webhook body must be raw JSON bytes." });
        return;
      }
      const signature = req.header("x-hub-signature-256");
      if (!verifyGithubSignature(req.body, signature, secret)) {
        res
          .status(401)
          .set("Cache-Control", "no-store")
          .json({ error: "Invalid GitHub webhook signature." });
        return;
      }
      const deliveryId = req.header("x-github-delivery")?.trim() ?? "";
      const eventName = req.header("x-github-event")?.trim() ?? "";
      if (
        !/^[a-f0-9-]{16,64}$/i.test(deliveryId) ||
        !/^[a-z_]{1,64}$/i.test(eventName)
      ) {
        res
          .status(400)
          .set("Cache-Control", "no-store")
          .json({ error: "GitHub webhook delivery headers are invalid." });
        return;
      }
      let payload: any;
      try {
        payload = JSON.parse(req.body.toString("utf8"));
      } catch {
        res
          .status(400)
          .set("Cache-Control", "no-store")
          .json({ error: "GitHub webhook JSON is invalid." });
        return;
      }
      const action = typeof payload?.action === "string" ? payload.action : "";
      const operation = classifyGitHubWebhook(eventName, action);
      if (!operation) {
        res
          .status(202)
          .set("Cache-Control", "no-store")
          .json({ accepted: true, ignored: true });
        return;
      }
      const db = await getDb();
      if (!db) {
        res.status(503).set("Cache-Control", "no-store").json({
          error:
            "Webhook storage is unavailable; GitHub can retry this delivery.",
        });
        return;
      }
      const repositoryId = Number(payload?.repository?.id);
      const after = typeof payload?.after === "string" ? payload.after : "";
      const metadata: WebhookDeliveryMetadata = {
        deliveryId,
        eventName,
        githubRepositoryId:
          Number.isSafeInteger(repositoryId) && repositoryId > 0
            ? repositoryId
            : null,
        commitSha: /^[a-f0-9]{40}$/i.test(after) ? after : null,
      };
      try {
        const result = await processWebhookDelivery(
          webhookDeliveryStore(db),
          metadata,
          async signal => {
            const assertLeaseActive = () => {
              if (signal.aborted)
                throw new Error(
                  "GitHub webhook delivery lease was lost during processing."
                );
            };
            assertLeaseActive();
            if (operation.kind === "push") {
              const githubRepoId = Number(payload?.repository?.id);
              const before =
                typeof payload?.before === "string" ? payload.before : "";
              const ref = typeof payload?.ref === "string" ? payload.ref : "";
              const branch = ref.startsWith("refs/heads/")
                ? ref.slice("refs/heads/".length)
                : "";
              if (!Number.isSafeInteger(githubRepoId) || githubRepoId <= 0)
                throw new Error(
                  "GitHub push payload did not contain a repository ID."
                );
              const matches = await db
                .select()
                .from(githubRepositories)
                .where(
                  and(
                    eq(githubRepositories.githubRepositoryId, githubRepoId),
                    eq(githubRepositories.authorized, true),
                    eq(githubRepositories.selected, true)
                  )
                );
              assertLeaseActive();
              const deletion =
                Boolean(payload?.deleted) || /^0{40}$/.test(after);
              for (const repository of matches) {
                assertLeaseActive();
                if (!branch || repository.branch !== branch) continue;
                if (deletion) {
                  await db
                    .update(githubRepositories)
                    .set({ watcherStatus: "stale", nextPollAt: null })
                    .where(
                      and(
                        eq(githubRepositories.ownerId, repository.ownerId),
                        eq(githubRepositories.id, repository.id)
                      )
                    );
                  assertLeaseActive();
                  continue;
                }
                if (!/^[a-f0-9]{40}$/i.test(after)) continue;
                const commits = Array.isArray(payload?.commits)
                  ? payload.commits.slice(-20)
                  : [];
                const changedFiles = commits
                  .flatMap((commit: any) => [
                    ...(Array.isArray(commit?.added)
                      ? commit.added.map((path: string) => ({
                          path: String(path).slice(0, 1000),
                          status: "added",
                        }))
                      : []),
                    ...(Array.isArray(commit?.modified)
                      ? commit.modified.map((path: string) => ({
                          path: String(path).slice(0, 1000),
                          status: "modified",
                        }))
                      : []),
                    ...(Array.isArray(commit?.removed)
                      ? commit.removed.map((path: string) => ({
                          path: String(path).slice(0, 1000),
                          status: "removed",
                        }))
                      : []),
                  ])
                  .slice(0, 300);
                const baseSha =
                  /^[a-f0-9]{40}$/i.test(before) && !/^0{40}$/.test(before)
                    ? before
                    : null;
                assertLeaseActive();
                await queueCommitForRepository({
                  ownerId: repository.ownerId,
                  repository,
                  commitSha: after,
                  branch,
                  baseSha,
                  changedFiles,
                });
                assertLeaseActive();
              }
            } else if (operation.kind === "installation_deleted") {
              const installationId = Number(payload?.installation?.id);
              if (Number.isSafeInteger(installationId) && installationId > 0) {
                const rows = await db
                  .select()
                  .from(githubInstallations)
                  .where(
                    eq(githubInstallations.installationId, installationId)
                  );
                assertLeaseActive();
                for (const installation of rows) {
                  assertLeaseActive();
                  await db
                    .update(githubRepositories)
                    .set({
                      authorized: false,
                      selected: false,
                      watcherStatus: "stale",
                      nextPollAt: null,
                    })
                    .where(
                      and(
                        eq(githubRepositories.ownerId, installation.ownerId),
                        eq(
                          githubRepositories.installationRowId,
                          installation.id
                        )
                      )
                    );
                  assertLeaseActive();
                }
              }
            } else if (operation.kind === "installation_repositories_changed") {
              const installationId = Number(payload?.installation?.id);
              if (!Number.isSafeInteger(installationId) || installationId <= 0)
                throw new Error(
                  "GitHub installation repository payload did not contain a valid installation ID."
                );
              const linkedInstallations = await db
                .select()
                .from(githubInstallations)
                .where(eq(githubInstallations.installationId, installationId));
              assertLeaseActive();
              const linkedOwners = [
                ...new Set(
                  linkedInstallations.map(installation => installation.ownerId)
                ),
              ];
              for (const ownerId of linkedOwners) {
                assertLeaseActive();
                await syncAuthorizedRepositories(ownerId);
                assertLeaseActive();
              }
            }
          }
        );
        if (result === "duplicate") {
          res
            .status(202)
            .set("Cache-Control", "no-store")
            .json({ accepted: true, duplicate: true });
          return;
        }
        if (result !== "processed") {
          res.status(503).set("Cache-Control", "no-store").json({
            error:
              "Webhook delivery is already processing or its claim expired; GitHub can retry it.",
          });
          return;
        }
        res
          .status(202)
          .set("Cache-Control", "no-store")
          .json({ accepted: true });
      } catch (error) {
        console.warn(
          "[GitHub webhook] Delivery processing failed:",
          error instanceof Error ? error.message : "unknown error"
        );
        res.status(503).set("Cache-Control", "no-store").json({
          error: "Webhook processing failed; GitHub can retry this delivery.",
        });
      }
    }
  );
}
