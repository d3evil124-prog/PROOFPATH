export function latestAuthorizedSelectedRepositoryId(
  authorizedSelectedRepositoryIds: readonly number[],
  assessmentRepositoryIdsNewestFirst: readonly number[]
): number | null {
  const available = new Set(authorizedSelectedRepositoryIds);
  return assessmentRepositoryIdsNewestFirst.find(repositoryId => available.has(repositoryId)) ?? null;
}
