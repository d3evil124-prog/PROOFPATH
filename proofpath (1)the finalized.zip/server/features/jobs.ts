import { and, desc, eq } from "drizzle-orm";
import { jobPostings, jobRequirements } from "../../drizzle/schema";
import { getDb } from "../db";
import { extractJobRequirements } from "./extraction";
import { fetchJobPosting } from "./safeJobFetch";

export type JobInput = { url?: string; description?: string };
export type JobRequirementInput = { originalWording: string; skill: string; priority: "required" | "preferred" };

function skillKey(value: string): string {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9+#.]+/g, "-").replace(/^-|-$/g, "").slice(0, 180);
}

async function insertRequirements(ownerId: number, jobId: number, requirements: JobRequirementInput[]) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const values = requirements.map(item => ({
    ownerId,
    jobId,
    originalWording: item.originalWording.trim().slice(0, 1000),
    skill: item.skill.trim().slice(0, 160),
    skillKey: skillKey(item.skill),
    priority: item.priority,
  }));
  if (!values.length || values.some(item => !item.originalWording || !item.skill || !item.skillKey)) {
    throw new Error("Each requirement needs source wording and a skill label.");
  }
  if (new Set(values.map(item => item.skillKey)).size !== values.length) {
    throw new Error("Requirements must use distinct skill labels.");
  }
  await db.insert(jobRequirements).values(values);
}

export async function createJobFromSource(ownerId: number, input: JobInput) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const hasUrl = Boolean(input.url?.trim());
  const hasDescription = Boolean(input.description?.trim());
  if (hasUrl === hasDescription) throw new Error("Provide either a public job URL or pasted job description.");
  let sourceUrl: string | null = null;
  let retrievedAt: Date | null = null;
  let sourceText: string;
  let pageTitle: string | null = null;
  if (hasUrl) {
    const fetched = await fetchJobPosting(input.url!.trim());
    sourceUrl = fetched.finalUrl;
    retrievedAt = new Date();
    sourceText = fetched.text;
    pageTitle = fetched.title;
  } else {
    sourceText = input.description!.trim().slice(0, 60_000);
    if (sourceText.length < 120) throw new Error("Paste at least 120 characters of the job description.");
  }
  if (sourceText.length < 120) throw new Error("The source contains too little job description text.");
  const extracted = await extractJobRequirements(sourceText, pageTitle);
  const created = await db.insert(jobPostings).values({
    ownerId,
    sourceKind: hasUrl ? "fetched" : "pasted",
    sourceUrl,
    retrievedAt,
    title: extracted.title,
    company: extracted.company,
    description: sourceText.slice(0, 150_000),
    extractionStatus: "needs_review",
  });
  const jobId = Number(created[0].insertId);
  await insertRequirements(ownerId, jobId, extracted.requirements.map(item => ({
    originalWording: item.wording,
    skill: item.skill,
    priority: item.priority,
  })));
  const saved = await getJob(ownerId, jobId);
  if (!saved) throw new Error("The job was saved but could not be loaded.");
  return saved;
}

export async function listJobs(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const jobs = await db.select().from(jobPostings).where(eq(jobPostings.ownerId, ownerId)).orderBy(desc(jobPostings.updatedAt)).limit(100);
  if (!jobs.length) return [];
  const output = [];
  for (const job of jobs) {
    const requirements = await db.select().from(jobRequirements)
      .where(and(eq(jobRequirements.ownerId, ownerId), eq(jobRequirements.jobId, job.id)));
    output.push({ ...job, requirements });
  }
  return output;
}

export async function getJob(ownerId: number, jobId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db.select().from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId))).limit(1);
  if (!job) return null;
  const requirements = await db.select().from(jobRequirements)
    .where(and(eq(jobRequirements.ownerId, ownerId), eq(jobRequirements.jobId, jobId)));
  return { ...job, requirements };
}

export async function reviewJob(ownerId: number, jobId: number, input: { title: string; company: string | null; requirements: JobRequirementInput[] }) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db.select().from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId))).limit(1);
  if (!job) throw new Error("Job posting not found.");
  if (job.extractionStatus !== "needs_review") throw new Error("This job's requirements have already been confirmed.");
  if (!input.title.trim() || input.title.trim().length > 255 || input.requirements.length < 1 || input.requirements.length > 25) {
    throw new Error("Enter a job title and between 1 and 25 requirements.");
  }
  await db.delete(jobRequirements).where(and(eq(jobRequirements.ownerId, ownerId), eq(jobRequirements.jobId, jobId)));
  await insertRequirements(ownerId, jobId, input.requirements);
  await db.update(jobPostings).set({
    title: input.title.trim(),
    company: input.company?.trim().slice(0, 255) || null,
    extractionStatus: "confirmed",
  }).where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId)));
  return getJob(ownerId, jobId);
}

export async function confirmExtractedJob(ownerId: number, jobId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db.select().from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId))).limit(1);
  if (!job) throw new Error("Job posting not found.");
  const requirements = await db.select().from(jobRequirements)
    .where(and(eq(jobRequirements.ownerId, ownerId), eq(jobRequirements.jobId, jobId)));
  if (!requirements.length) throw new Error("Review at least one extracted requirement before confirming.");
  await db.update(jobPostings).set({ extractionStatus: "confirmed" })
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId)));
  return getJob(ownerId, jobId);
}
