import {
  assessment,
  citations,
  demoJob,
  demoRepository,
  ledger,
  monitoring,
  skillAssessments,
} from "@/data/demoData";
import type {
  AssessmentSummary,
  ChangeEvent,
  JobPosting,
  Repository,
  SkillAssessment,
} from "@/types/domain";

export type ServiceMode = "demo" | "live-not-configured";
export class IntegrationUnavailableError extends Error {
  readonly mode: ServiceMode = "live-not-configured";
  constructor(
    message = "Live job, GitHub and analysis services are not connected in this prototype."
  ) {
    super(message);
    this.name = "IntegrationUnavailableError";
  }
}
const latency = (ms = 180) =>
  new Promise<void>(resolve => window.setTimeout(resolve, ms));

// Swap this adapter for authenticated server calls when the production integrations exist.
// The static prototype deliberately does not fetch or poll GitHub or job sources.
export const proofPathService = {
  async loadDemoPortfolio(): Promise<{
    job: JobPosting;
    repository: Repository;
    assessment: AssessmentSummary;
  }> {
    await latency();
    return { job: demoJob, repository: demoRepository, assessment };
  },
  async importJob(input: {
    url?: string;
    pastedText?: string;
    demo?: boolean;
  }): Promise<JobPosting> {
    await latency();
    if (input.demo) return demoJob;
    if (input.url)
      throw new IntegrationUnavailableError(
        "Live job-page import is unavailable. Paste the job description or load the clearly labelled sample project."
      );
    if (input.pastedText?.trim())
      throw new IntegrationUnavailableError(
        "Requirement extraction requires the future analysis service. Your pasted text has not been analyzed."
      );
    throw new Error("Enter a job URL or paste the job description.");
  },
  async connectRepository(_input: {
    url: string;
    branch: string;
  }): Promise<Repository> {
    await latency();
    throw new IntegrationUnavailableError(
      "Live GitHub access is not connected. No repository permissions or contents were accessed."
    );
  },
  async startAssessment(_input: {
    jobId: string;
    repositoryId: string;
  }): Promise<AssessmentSummary> {
    await latency();
    throw new IntegrationUnavailableError(
      "Live repository inspection and AI assessment are not connected. No live files were inspected."
    );
  },
  async fetchAssessment(assessmentId: string): Promise<AssessmentSummary> {
    await latency();
    if (assessmentId !== assessment.id)
      throw new Error("Assessment not found in sample data.");
    return assessment;
  },
  async loadHistory(): Promise<ChangeEvent[]> {
    await latency();
    return ledger;
  },
  async getMonitoring() {
    await latency();
    return monitoring;
  },
  async getEvidence(requirementId: string) {
    await latency();
    const skill: SkillAssessment | undefined = skillAssessments.find(
      item => item.requirementId === requirementId
    );
    if (!skill) throw new Error("Requirement not found.");
    return {
      skill,
      citations: citations.filter(
        citation => citation.requirementId === requirementId
      ),
    };
  },
};
