import { and, desc, eq, inArray } from "drizzle-orm";
import {
  assessmentVersions,
  changeEvents,
  evidenceCitations,
  githubConnections,
  githubRepositories,
  jobPostings,
  jobRequirements,
  resumes,
  skillAssessments,
  workItems,
  type AssessmentVersionRow,
  type GitHubRepositoryRow,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { latestCommit, pollInterval, repositoryForOwner } from "./githubApi";
import { latestAuthorizedSelectedRepositoryId } from "./overviewPolicy";

export type ChangedPath = {
  path: string;
  status: string;
  previousPath?: string;
};

function validSha(value: string): boolean {
  return /^[a-f0-9]{40}$/i.test(value);
}

async function enqueueOne(input: {
  ownerId: number;
  jobId: number;
  repository: GitHubRepositoryRow;
  commitSha: string;
  branch: string;
  baseSha?: string | null;
  changedFiles?: ChangedPath[];
  retryFailed?: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  if (!validSha(input.commitSha) || (input.baseSha && !validSha(input.baseSha)))
    throw new Error("GitHub returned an invalid commit identifier.");
  const [job] = await db
    .select()
    .from(jobPostings)
    .where(
      and(
        eq(jobPostings.ownerId, input.ownerId),
        eq(jobPostings.id, input.jobId),
        eq(jobPostings.extractionStatus, "confirmed")
      )
    )
    .limit(1);
  if (!job) return null;
  const [existing] = await db
    .select()
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, input.ownerId),
        eq(assessmentVersions.jobId, input.jobId),
        eq(assessmentVersions.repositoryId, input.repository.id),
        eq(assessmentVersions.commitSha, input.commitSha)
      )
    )
    .limit(1);
  const [existingWork] = await db
    .select()
    .from(workItems)
    .where(
      and(
        eq(workItems.ownerId, input.ownerId),
        eq(workItems.repositoryId, input.repository.id),
        eq(workItems.jobId, input.jobId),
        eq(workItems.commitSha, input.commitSha)
      )
    )
    .limit(1);
  if (existingWork && (existingWork.status !== "failed" || !input.retryFailed))
    return existing ?? null;
  if (existing && ["completed", "running", "queued"].includes(existing.state))
    return existing;

  let versionRow = existing;
  if (!versionRow) {
    const [latest] = await db
      .select()
      .from(assessmentVersions)
      .where(
        and(
          eq(assessmentVersions.ownerId, input.ownerId),
          eq(assessmentVersions.jobId, input.jobId),
          eq(assessmentVersions.repositoryId, input.repository.id)
        )
      )
      .orderBy(desc(assessmentVersions.version))
      .limit(1);
    try {
      const created = await db.insert(assessmentVersions).values({
        ownerId: input.ownerId,
        jobId: input.jobId,
        repositoryId: input.repository.id,
        version: (latest?.version ?? 0) + 1,
        branch: input.branch,
        commitSha: input.commitSha,
        state: "queued",
        filesInspected: 0,
        filesExcluded: 0,
        testsDiscovered: false,
        testsExecuted: false,
        scopeSummary: { inspected: [], excluded: [], truncated: false },
      });
      const newId = Number(created[0].insertId);
      [versionRow] = await db
        .select()
        .from(assessmentVersions)
        .where(eq(assessmentVersions.id, newId))
        .limit(1);
    } catch (error) {
      const [raced] = await db
        .select()
        .from(assessmentVersions)
        .where(
          and(
            eq(assessmentVersions.ownerId, input.ownerId),
            eq(assessmentVersions.jobId, input.jobId),
            eq(assessmentVersions.repositoryId, input.repository.id),
            eq(assessmentVersions.commitSha, input.commitSha)
          )
        )
        .limit(1);
      if (raced) versionRow = raced;
      else throw error;
    }
  } else {
    await db
      .update(assessmentVersions)
      .set({ state: "queued", errorMessage: null, completedAt: null })
      .where(
        and(
          eq(assessmentVersions.ownerId, input.ownerId),
          eq(assessmentVersions.id, versionRow.id)
        )
      );
    versionRow = {
      ...versionRow,
      state: "queued",
      errorMessage: null,
      completedAt: null,
    };
  }
  if (!versionRow) throw new Error("Could not queue the portfolio assessment.");

  let eventId: number | null = null;
  if (input.baseSha && input.baseSha !== input.commitSha) {
    const [existingEvent] = await db
      .select()
      .from(changeEvents)
      .where(
        and(
          eq(changeEvents.ownerId, input.ownerId),
          eq(changeEvents.repositoryId, input.repository.id),
          eq(changeEvents.jobId, input.jobId),
          eq(changeEvents.commitSha, input.commitSha)
        )
      )
      .limit(1);
    if (existingEvent) {
      eventId = existingEvent.id;
      await db
        .update(changeEvents)
        .set({
          processingState: "detected",
          errorMessage: null,
          completedAt: null,
        })
        .where(
          and(
            eq(changeEvents.ownerId, input.ownerId),
            eq(changeEvents.id, existingEvent.id)
          )
        );
    } else {
      try {
        const createdEvent = await db.insert(changeEvents).values({
          ownerId: input.ownerId,
          repositoryId: input.repository.id,
          jobId: input.jobId,
          assessmentId: versionRow.id,
          previousSha: input.baseSha,
          commitSha: input.commitSha,
          branch: input.branch,
          commitMessage: null,
          processingState: "detected",
          changedFiles: input.changedFiles ?? [],
          statusChanges: [],
          evidenceAdded: 0,
          evidenceRemoved: 0,
        });
        eventId = Number(createdEvent[0].insertId);
      } catch {
        const [racedEvent] = await db
          .select()
          .from(changeEvents)
          .where(
            and(
              eq(changeEvents.ownerId, input.ownerId),
              eq(changeEvents.repositoryId, input.repository.id),
              eq(changeEvents.jobId, input.jobId),
              eq(changeEvents.commitSha, input.commitSha)
            )
          )
          .limit(1);
        eventId = racedEvent?.id ?? null;
      }
    }
  }

  if (existingWork) {
    const requeued = await db
      .update(workItems)
      .set({
        assessmentId: versionRow.id,
        changeEventId: eventId,
        baseSha: input.baseSha ?? null,
        branch: input.branch,
        status: "queued",
        attempts: 0,
        availableAt: new Date(),
        leaseUntil: null,
        leaseToken: null,
        lastError: null,
      })
      .where(
        and(
          eq(workItems.ownerId, input.ownerId),
          eq(workItems.id, existingWork.id),
          eq(workItems.status, "failed")
        )
      );
    if (!Number((requeued[0] as { affectedRows?: number }).affectedRows ?? 0))
      return versionRow;
  } else {
    await db
      .insert(workItems)
      .values({
        ownerId: input.ownerId,
        repositoryId: input.repository.id,
        jobId: input.jobId,
        assessmentId: versionRow.id,
        changeEventId: eventId,
        commitSha: input.commitSha,
        baseSha: input.baseSha ?? null,
        branch: input.branch,
        status: "queued",
        availableAt: new Date(),
      })
      .onDuplicateKeyUpdate({ set: { updatedAt: new Date() } });
  }
  await db
    .update(githubRepositories)
    .set({
      latestObservedSha: input.commitSha,
      lastSyncedAt: new Date(),
      nextPollAt: new Date(Date.now() + pollInterval(input.repository)),
      watcherStatus: "active",
    })
    .where(
      and(
        eq(githubRepositories.ownerId, input.ownerId),
        eq(githubRepositories.id, input.repository.id)
      )
    );
  return versionRow;
}

export async function queueAssessment(
  ownerId: number,
  jobId: number,
  repositoryId: number
) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db
    .select()
    .from(jobPostings)
    .where(
      and(
        eq(jobPostings.ownerId, ownerId),
        eq(jobPostings.id, jobId),
        eq(jobPostings.extractionStatus, "confirmed")
      )
    )
    .limit(1);
  if (!job)
    throw new Error(
      "Review and confirm this job's requirements before assessing a repository."
    );
  const repository = await repositoryForOwner(ownerId, repositoryId);
  const head = await latestCommit(
    ownerId,
    repository,
    repository.branch ?? repository.defaultBranch
  );
  if (!validSha(head.sha))
    throw new Error("GitHub returned an invalid branch head.");
  const [previous] = await db
    .select()
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, ownerId),
        eq(assessmentVersions.jobId, jobId),
        eq(assessmentVersions.repositoryId, repositoryId),
        eq(assessmentVersions.state, "completed")
      )
    )
    .orderBy(desc(assessmentVersions.createdAt))
    .limit(1);
  return enqueueOne({
    ownerId,
    jobId,
    repository,
    commitSha: head.sha,
    branch: repository.branch ?? repository.defaultBranch,
    baseSha: previous?.commitSha ?? null,
    retryFailed: true,
  });
}

export async function queueCommitForRepository(input: {
  ownerId: number;
  repository: GitHubRepositoryRow;
  commitSha: string;
  branch: string;
  baseSha?: string | null;
  changedFiles?: ChangedPath[];
}) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const repository = await repositoryForOwner(
    input.ownerId,
    input.repository.id
  );
  if ((repository.branch ?? repository.defaultBranch) !== input.branch)
    return [];
  const jobs = await db
    .select()
    .from(jobPostings)
    .where(
      and(
        eq(jobPostings.ownerId, input.ownerId),
        eq(jobPostings.extractionStatus, "confirmed")
      )
    );
  const outcomes: AssessmentVersionRow[] = [];
  for (const job of jobs) {
    const result = await enqueueOne({ ...input, repository, jobId: job.id });
    if (result) outcomes.push(result);
  }
  return outcomes;
}

export async function getLatestAssessment(
  ownerId: number,
  jobId: number,
  repositoryId: number
) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db
    .select()
    .from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId)))
    .limit(1);
  const [repository] = await db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.id, repositoryId)
      )
    )
    .limit(1);
  if (!job || !repository) throw new Error("Job or repository not found.");
  const [latestAttempt] = await db
    .select()
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, ownerId),
        eq(assessmentVersions.jobId, jobId),
        eq(assessmentVersions.repositoryId, repositoryId)
      )
    )
    .orderBy(desc(assessmentVersions.version))
    .limit(1);
  const [latest] = await db
    .select()
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, ownerId),
        eq(assessmentVersions.jobId, jobId),
        eq(assessmentVersions.repositoryId, repositoryId),
        eq(assessmentVersions.state, "completed")
      )
    )
    .orderBy(desc(assessmentVersions.version))
    .limit(1);
  if (!latest) {
    return latestAttempt
      ? { ...latestAttempt, skills: [], latestAttempt: null }
      : null;
  }
  const skills = await db
    .select()
    .from(skillAssessments)
    .where(
      and(
        eq(skillAssessments.ownerId, ownerId),
        eq(skillAssessments.assessmentId, latest.id)
      )
    );
  const enriched = [];
  for (const skill of skills) {
    const [requirement] = await db
      .select()
      .from(jobRequirements)
      .where(
        and(
          eq(jobRequirements.ownerId, ownerId),
          eq(jobRequirements.id, skill.requirementId)
        )
      )
      .limit(1);
    const citations = await db
      .select()
      .from(evidenceCitations)
      .where(
        and(
          eq(evidenceCitations.ownerId, ownerId),
          eq(evidenceCitations.skillAssessmentId, skill.id)
        )
      );
    enriched.push({ ...skill, requirement: requirement ?? null, citations });
  }
  return {
    ...latest,
    skills: enriched,
    latestAttempt:
      latestAttempt && latestAttempt.id !== latest.id
        ? {
            id: latestAttempt.id,
            state: latestAttempt.state,
            commitSha: latestAttempt.commitSha,
            createdAt: latestAttempt.createdAt,
            errorMessage: latestAttempt.errorMessage,
          }
        : null,
  };
}

export async function getAssessmentHistory(
  ownerId: number,
  jobId: number,
  repositoryId: number
) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [job] = await db
    .select()
    .from(jobPostings)
    .where(and(eq(jobPostings.ownerId, ownerId), eq(jobPostings.id, jobId)))
    .limit(1);
  const [repository] = await db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.id, repositoryId)
      )
    )
    .limit(1);
  if (!job || !repository) throw new Error("Job or repository not found.");
  const versions = await db
    .select()
    .from(assessmentVersions)
    .where(
      and(
        eq(assessmentVersions.ownerId, ownerId),
        eq(assessmentVersions.jobId, jobId),
        eq(assessmentVersions.repositoryId, repositoryId)
      )
    )
    .orderBy(desc(assessmentVersions.version))
    .limit(100);
  const events = await db
    .select()
    .from(changeEvents)
    .where(
      and(
        eq(changeEvents.ownerId, ownerId),
        eq(changeEvents.jobId, jobId),
        eq(changeEvents.repositoryId, repositoryId)
      )
    )
    .orderBy(desc(changeEvents.createdAt))
    .limit(100);
  return { versions, events };
}

export async function getConnectionSummary(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [connection] = await db
    .select()
    .from(githubConnections)
    .where(eq(githubConnections.ownerId, ownerId))
    .orderBy(desc(githubConnections.connectedAt))
    .limit(1);
  const [selectedRepository] = await db
    .select({
      id: githubRepositories.id,
      owner: githubRepositories.repositoryOwner,
      name: githubRepositories.repositoryName,
      accessMode: githubRepositories.accessMode,
      connectionId: githubRepositories.connectionId,
    })
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.authorized, true),
        eq(githubRepositories.selected, true)
      )
    )
    .orderBy(desc(githubRepositories.updatedAt))
    .limit(1);
  const repositoryAccess = selectedRepository
    ? selectedRepository.accessMode === "public_link"
      ? "public_link"
      : selectedRepository.connectionId
        ? "github_app"
        : "token"
    : null;
  const selected = selectedRepository
    ? {
        id: selectedRepository.id,
        fullName: `${selectedRepository.owner}/${selectedRepository.name}`,
      }
    : null;
  return connection
    ? {
        connected: connection.status === "connected",
        status: connection.status,
        connectedAt: connection.connectedAt,
        lastCheckedAt: connection.lastCheckedAt,
        selectedRepositoryAccess: repositoryAccess,
        selectedRepository: selected,
      }
    : {
        connected: false as const,
        status: "not_connected" as const,
        connectedAt: null,
        lastCheckedAt: null,
        selectedRepositoryAccess: repositoryAccess,
        selectedRepository: selected,
      };
}

export async function getStudentOverview(ownerId: number) {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const jobs = await db
    .select()
    .from(jobPostings)
    .where(eq(jobPostings.ownerId, ownerId))
    .orderBy(desc(jobPostings.updatedAt))
    .limit(50);
  const repositoryRows = await db
    .select()
    .from(githubRepositories)
    .where(
      and(
        eq(githubRepositories.ownerId, ownerId),
        eq(githubRepositories.authorized, true),
        eq(githubRepositories.selected, true)
      )
    )
    .orderBy(desc(githubRepositories.updatedAt))
    .limit(20);
  const resumeRows = await db
    .select()
    .from(resumes)
    .where(eq(resumes.ownerId, ownerId))
    .orderBy(desc(resumes.uploadedAt))
    .limit(1);
  const connection = await getConnectionSummary(ownerId);
  const results = [];
  for (const job of jobs) {
    const requirements = await db
      .select()
      .from(jobRequirements)
      .where(
        and(
          eq(jobRequirements.ownerId, ownerId),
          eq(jobRequirements.jobId, job.id)
        )
      );
    const versionRows = repositoryRows.length
      ? await db
          .select({ repositoryId: assessmentVersions.repositoryId })
          .from(assessmentVersions)
          .where(
            and(
              eq(assessmentVersions.ownerId, ownerId),
              eq(assessmentVersions.jobId, job.id),
              inArray(
                assessmentVersions.repositoryId,
                repositoryRows.map(repository => repository.id)
              )
            )
          )
          .orderBy(desc(assessmentVersions.createdAt))
          .limit(1)
      : [];
    const repositoryId = latestAuthorizedSelectedRepositoryId(
      repositoryRows.map(repository => repository.id),
      versionRows.map(row => row.repositoryId)
    );
    const selectedRepo = repositoryRows.find(
      repository => repository.id === repositoryId
    );
    const assessment = selectedRepo
      ? await getLatestAssessment(ownerId, job.id, selectedRepo.id)
      : null;
    results.push({
      job,
      requirements,
      repository: selectedRepo ?? null,
      assessment,
    });
  }
  return {
    jobs: results,
    repositories: repositoryRows,
    resume: resumeRows[0]
      ? {
          id: resumeRows[0].id,
          originalName: resumeRows[0].originalName,
          uploadedAt: resumeRows[0].uploadedAt,
          parsedProfile: resumeRows[0].parsedProfile,
        }
      : null,
    github: connection,
  };
}
