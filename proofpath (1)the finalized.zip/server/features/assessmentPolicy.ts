export type EvidenceType = "implementation" | "test" | "configuration" | "documentation";
export type EvidenceStatus =
  | "demonstrated"
  | "partial_or_needs_review"
  | "not_demonstrated_in_analyzed_scope"
  | "unable_to_assess";

export type EvidenceConfidence = "low" | "medium" | "high";

export type EvidenceCitationSummary = {
  evidenceType: EvidenceType;
  confidence: "medium" | "high";
};

const TEST_PATH = /(^|\/)(__tests__|tests?|specs?)(\/|\.)|\.(test|spec)\./i;

export function evidenceTypeForPath(path: string): EvidenceType {
  const normalized = path.replace(/\\/g, "/");
  if (TEST_PATH.test(normalized)) return "test";
  if (/\.md$/i.test(normalized)) return "documentation";
  if (
    /\.(json|ya?ml|toml|xml)$/i.test(normalized) ||
    /(^|\/)(Dockerfile|Makefile|\.env\.example)$/i.test(normalized)
  ) {
    return "configuration";
  }
  return "implementation";
}

export function enforceEvidenceStatus(
  status: EvidenceStatus,
  analysisConfidence: EvidenceConfidence,
  citations: readonly EvidenceCitationSummary[]
): { status: EvidenceStatus; reason: string | null } {
  if (status !== "demonstrated" && status !== "partial_or_needs_review") {
    return { status, reason: null };
  }

  const codeCitations = citations.filter(
    citation => citation.evidenceType === "implementation" || citation.evidenceType === "test"
  );
  if (!codeCitations.length) {
    return {
      status: "unable_to_assess",
      reason:
        "The validated citations do not include inspected implementation or test code; documentation and configuration alone cannot support a positive code-based finding.",
    };
  }

  if (
    status === "demonstrated" &&
    (analysisConfidence !== "high" || !codeCitations.some(citation => citation.confidence === "high"))
  ) {
    return {
      status: "partial_or_needs_review",
      reason:
        "The inspected implementation or test citation does not meet the high-confidence threshold required for a demonstrated status.",
    };
  }

  return { status, reason: null };
}
