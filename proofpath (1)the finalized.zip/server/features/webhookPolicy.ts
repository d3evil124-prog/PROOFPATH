import { randomUUID } from "node:crypto";

export type SupportedGitHubWebhook =
  | { kind: "push" }
  | { kind: "installation_deleted" }
  | { kind: "installation_repositories_changed"; action: "added" | "removed" };

export function classifyGitHubWebhook(
  eventName: string,
  action: string
): SupportedGitHubWebhook | null {
  if (eventName === "push") return { kind: "push" };
  if (eventName === "installation" && action === "deleted")
    return { kind: "installation_deleted" };
  if (
    eventName === "installation_repositories" &&
    (action === "added" || action === "removed")
  ) {
    return { kind: "installation_repositories_changed", action };
  }
  return null;
}

export type WebhookDeliveryMetadata = {
  deliveryId: string;
  eventName: string;
  githubRepositoryId: number | null;
  commitSha: string | null;
};

export interface WebhookDeliveryStore {
  ensure(metadata: WebhookDeliveryMetadata): Promise<void>;
  tryClaim(
    deliveryId: string,
    token: string,
    now: Date,
    leaseUntil: Date
  ): Promise<boolean>;
  renew(
    deliveryId: string,
    token: string,
    now: Date,
    leaseUntil: Date
  ): Promise<boolean>;
  isProcessed(deliveryId: string): Promise<boolean>;
  complete(deliveryId: string, token: string, now: Date): Promise<boolean>;
  release(deliveryId: string, token: string): Promise<void>;
}

export type WebhookDeliveryResult =
  | "processed"
  | "duplicate"
  | "busy"
  | "lease_lost";

export async function processWebhookDelivery(
  store: WebhookDeliveryStore,
  metadata: WebhookDeliveryMetadata,
  handler: (signal: AbortSignal) => Promise<void>,
  options: {
    token?: string;
    now?: () => Date;
    leaseMs?: number;
    heartbeatMs?: number;
  } = {}
): Promise<WebhookDeliveryResult> {
  const now = options.now ?? (() => new Date());
  const leaseMs = options.leaseMs ?? 5 * 60_000;
  const heartbeatMs = options.heartbeatMs ?? Math.max(1, Math.floor(leaseMs / 3));
  if (!Number.isFinite(leaseMs) || leaseMs <= 0 || !Number.isFinite(heartbeatMs) || heartbeatMs <= 0) {
    throw new Error("Webhook delivery lease and heartbeat durations must be positive finite numbers.");
  }

  await store.ensure(metadata);
  const token = options.token ?? randomUUID();
  const claimedAt = now();
  const leaseUntil = new Date(claimedAt.getTime() + leaseMs);
  if (!(await store.tryClaim(metadata.deliveryId, token, claimedAt, leaseUntil))) {
    return (await store.isProcessed(metadata.deliveryId)) ? "duplicate" : "busy";
  }

  const controller = new AbortController();
  let leaseLost = false;
  let renewalInFlight: Promise<void> | null = null;
  const heartbeat = setInterval(() => {
    if (leaseLost || renewalInFlight) return;
    const renewedAt = now();
    renewalInFlight = store
      .renew(metadata.deliveryId, token, renewedAt, new Date(renewedAt.getTime() + leaseMs))
      .then(renewed => {
        if (!renewed) {
          leaseLost = true;
          controller.abort();
        }
      })
      .catch(() => {
        // A transient DB error is retried on the next heartbeat; completion remains token- and lease-fenced.
      })
      .finally(() => {
        renewalInFlight = null;
      });
  }, heartbeatMs);

  const stopHeartbeat = async () => {
    clearInterval(heartbeat);
    if (renewalInFlight) await renewalInFlight;
  };

  try {
    await handler(controller.signal);
    await stopHeartbeat();
    if (leaseLost) return "lease_lost";
    return (await store.complete(metadata.deliveryId, token, now()))
      ? "processed"
      : "lease_lost";
  } catch (error) {
    await stopHeartbeat();
    await store.release(metadata.deliveryId, token);
    throw error;
  }
}
