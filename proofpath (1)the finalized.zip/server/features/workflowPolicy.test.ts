import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import { describe, expect, it, vi } from "vitest";
import { enforceEvidenceStatus, evidenceTypeForPath } from "./assessmentPolicy";
import { latestAuthorizedSelectedRepositoryId } from "./overviewPolicy";
import {
  leaseCondition,
  pollFailureDisposition,
  singleFlight,
} from "./workerPolicy";
import {
  classifyGitHubWebhook,
  processWebhookDelivery,
  type WebhookDeliveryMetadata,
  type WebhookDeliveryStore,
} from "./webhookPolicy";

class MemoryWebhookDeliveryStore implements WebhookDeliveryStore {
  private readonly rows = new Map<
    string,
    { processed: boolean; token: string | null; leaseUntil: Date | null }
  >();

  async ensure(metadata: WebhookDeliveryMetadata) {
    if (!this.rows.has(metadata.deliveryId))
      this.rows.set(metadata.deliveryId, {
        processed: false,
        token: null,
        leaseUntil: null,
      });
  }

  async tryClaim(
    deliveryId: string,
    token: string,
    now: Date,
    leaseUntil: Date
  ) {
    const row = this.rows.get(deliveryId);
    if (
      !row ||
      row.processed ||
      (row.leaseUntil && row.leaseUntil.getTime() >= now.getTime())
    )
      return false;
    row.token = token;
    row.leaseUntil = leaseUntil;
    return true;
  }

  async renew(deliveryId: string, token: string, now: Date, leaseUntil: Date) {
    const row = this.rows.get(deliveryId);
    if (
      !row ||
      row.processed ||
      row.token !== token ||
      !row.leaseUntil ||
      row.leaseUntil.getTime() <= now.getTime()
    )
      return false;
    row.leaseUntil = leaseUntil;
    return true;
  }

  async isProcessed(deliveryId: string) {
    return this.rows.get(deliveryId)?.processed ?? false;
  }

  async complete(deliveryId: string, token: string, now: Date) {
    const row = this.rows.get(deliveryId);
    if (
      !row ||
      row.processed ||
      row.token !== token ||
      !row.leaseUntil ||
      row.leaseUntil.getTime() <= now.getTime()
    )
      return false;
    row.processed = true;
    row.token = null;
    row.leaseUntil = null;
    return true;
  }

  async release(deliveryId: string, token: string) {
    const row = this.rows.get(deliveryId);
    if (row && !row.processed && row.token === token) {
      row.token = null;
      row.leaseUntil = null;
    }
  }
}

describe("assessment worker policy", () => {
  it("fences every lease write to owner, work item, running state, token, and unexpired deadline", () => {
    const now = new Date("2026-10-17T00:00:00.000Z");
    const item = {
      ownerId: 7,
      id: 19,
      status: "running" as const,
      leaseToken: "lease-token-abc",
    };
    const query = new MySqlDialect().sqlToQuery(leaseCondition(item, now));
    for (const column of [
      "ownerId",
      "id",
      "status",
      "leaseToken",
      "leaseUntil",
    ]) {
      expect(query.sql).toContain(column);
    }
    expect(query.params).toContain(7);
    expect(query.params).toContain(19);
    expect(query.params).toContain("running");
    expect(query.params).toContain("lease-token-abc");
  });

  it("does not start overlapping queue drains in one process and releases the guard after completion", async () => {
    let release!: () => void;
    const gate = new Promise<void>(resolve => {
      release = resolve;
    });
    let runs = 0;
    const drain = singleFlight(async () => {
      runs += 1;
      await gate;
    });
    const first = drain();
    await Promise.resolve();
    await drain();
    expect(runs).toBe(1);
    release();
    await first;
    await drain();
    expect(runs).toBe(2);
  });
});

describe("repository polling failure policy", () => {
  it("keeps transient failures eligible for a delayed retry but stops polling on expired authorization", () => {
    expect(pollFailureDisposition(503)).toEqual({
      watcherStatus: "active",
      retryDelayMs: 10 * 60_000,
    });
    expect(pollFailureDisposition(undefined)).toEqual({
      watcherStatus: "active",
      retryDelayMs: 10 * 60_000,
    });
    expect(pollFailureDisposition(401)).toEqual({
      watcherStatus: "stale",
      retryDelayMs: null,
    });
  });
});

describe("assessment evidence policy", () => {
  it("classifies evidence from the inspected path rather than trusting an LLM label", () => {
    expect(evidenceTypeForPath("README.md")).toBe("documentation");
    expect(evidenceTypeForPath(".github/workflows/ci.yml")).toBe(
      "configuration"
    );
    expect(evidenceTypeForPath("src/example.test.ts")).toBe("test");
    expect(evidenceTypeForPath("src/example.ts")).toBe("implementation");
  });

  it("does not accept documentation- or configuration-only positive claims", () => {
    const documentation = [
      { evidenceType: "documentation" as const, confidence: "high" as const },
    ];
    const configuration = [
      { evidenceType: "configuration" as const, confidence: "high" as const },
    ];
    expect(
      enforceEvidenceStatus("demonstrated", "high", documentation).status
    ).toBe("unable_to_assess");
    expect(
      enforceEvidenceStatus("demonstrated", "high", configuration).status
    ).toBe("unable_to_assess");
    expect(
      enforceEvidenceStatus("partial_or_needs_review", "medium", documentation)
        .status
    ).toBe("unable_to_assess");
  });

  it("requires high-confidence implementation or test evidence for demonstrated status", () => {
    const strongImplementation = [
      { evidenceType: "implementation" as const, confidence: "high" as const },
    ];
    const weakImplementation = [
      {
        evidenceType: "implementation" as const,
        confidence: "medium" as const,
      },
    ];
    const strongTest = [
      { evidenceType: "test" as const, confidence: "high" as const },
    ];
    expect(
      enforceEvidenceStatus("demonstrated", "high", strongImplementation).status
    ).toBe("demonstrated");
    expect(
      enforceEvidenceStatus("demonstrated", "high", strongTest).status
    ).toBe("demonstrated");
    expect(
      enforceEvidenceStatus("demonstrated", "medium", strongImplementation)
        .status
    ).toBe("partial_or_needs_review");
    expect(
      enforceEvidenceStatus("demonstrated", "high", weakImplementation).status
    ).toBe("partial_or_needs_review");
  });
});

describe("dashboard repository association", () => {
  it("chooses the newest assessment repo only among live selected grants", () => {
    expect(latestAuthorizedSelectedRepositoryId([4, 8], [12, 8, 4])).toBe(8);
    expect(latestAuthorizedSelectedRepositoryId([4, 8], [12, 13])).toBeNull();
    expect(latestAuthorizedSelectedRepositoryId([], [4, 8])).toBeNull();
  });
});

describe("GitHub webhook action policy", () => {
  it("refreshes grants for installation repository additions and removals", () => {
    expect(classifyGitHubWebhook("installation_repositories", "added")).toEqual(
      { kind: "installation_repositories_changed", action: "added" }
    );
    expect(
      classifyGitHubWebhook("installation_repositories", "removed")
    ).toEqual({ kind: "installation_repositories_changed", action: "removed" });
  });

  it("ignores unsupported event/action pairs", () => {
    expect(classifyGitHubWebhook("issues", "opened")).toBeNull();
    expect(
      classifyGitHubWebhook("installation_repositories", "created")
    ).toBeNull();
    expect(classifyGitHubWebhook("installation", "suspended")).toBeNull();
  });
});

describe("GitHub webhook delivery claims", () => {
  const metadata: WebhookDeliveryMetadata = {
    deliveryId: "0123456789abcdef0123456789abcdef",
    eventName: "push",
    githubRepositoryId: 17,
    commitSha: "a".repeat(40),
  };

  it("permits one active handler, returns busy for a concurrent redelivery, then treats completion as duplicate", async () => {
    const store = new MemoryWebhookDeliveryStore();
    const now = new Date("2026-10-17T00:00:00.000Z");
    let release!: () => void;
    let signalStarted!: () => void;
    const gate = new Promise<void>(resolve => {
      release = resolve;
    });
    const started = new Promise<void>(resolve => {
      signalStarted = resolve;
    });
    let handled = 0;
    const first = processWebhookDelivery(
      store,
      metadata,
      async () => {
        handled += 1;
        signalStarted();
        await gate;
      },
      { token: "first-claim", now: () => now }
    );
    await started;
    const concurrent = await processWebhookDelivery(
      store,
      metadata,
      async () => {
        handled += 1;
      },
      { token: "second-claim", now: () => now }
    );
    expect(concurrent).toBe("busy");
    expect(handled).toBe(1);
    release();
    await expect(first).resolves.toBe("processed");
    const duplicate = await processWebhookDelivery(
      store,
      metadata,
      async () => {
        handled += 1;
      },
      { token: "third-claim", now: () => now }
    );
    expect(duplicate).toBe("duplicate");
    expect(handled).toBe(1);
  });

  it("fences a stale handler when an expired delivery lease is reclaimed", async () => {
    const store = new MemoryWebhookDeliveryStore();
    let now = new Date("2026-10-17T00:00:00.000Z");
    let release!: () => void;
    let signalStarted!: () => void;
    const gate = new Promise<void>(resolve => {
      release = resolve;
    });
    const started = new Promise<void>(resolve => {
      signalStarted = resolve;
    });
    const stale = processWebhookDelivery(
      store,
      metadata,
      async () => {
        signalStarted();
        await gate;
      },
      {
        token: "expired-claim",
        now: () => now,
        leaseMs: 100,
        heartbeatMs: 1000,
      }
    );
    await started;
    now = new Date(now.getTime() + 101);
    const reclaimed = await processWebhookDelivery(
      store,
      metadata,
      async () => {},
      { token: "new-claim", now: () => now }
    );
    expect(reclaimed).toBe("processed");
    release();
    await expect(stale).resolves.toBe("lease_lost");
  });

  it("releases a failed claim so GitHub can retry without preserving a stale lease", async () => {
    const store = new MemoryWebhookDeliveryStore();
    const now = new Date("2026-10-17T00:00:00.000Z");
    await expect(
      processWebhookDelivery(
        store,
        metadata,
        async () => {
          throw new Error("temporary failure");
        },
        { token: "failed-claim", now: () => now }
      )
    ).rejects.toThrow("temporary failure");
    const retry = await processWebhookDelivery(
      store,
      metadata,
      async () => {},
      { token: "retry-claim", now: () => now }
    );
    expect(retry).toBe("processed");
  });

  it("renews a long-running lease so a concurrent redelivery remains busy until completion", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-10-17T00:00:00.000Z"));
    try {
      const store = new MemoryWebhookDeliveryStore();
      let release!: () => void;
      let signalStarted!: () => void;
      const gate = new Promise<void>(resolve => {
        release = resolve;
      });
      const started = new Promise<void>(resolve => {
        signalStarted = resolve;
      });
      const first = processWebhookDelivery(
        store,
        metadata,
        async () => {
          signalStarted();
          await gate;
        },
        { token: "renewed-claim", leaseMs: 90, heartbeatMs: 20 }
      );
      await started;
      await vi.advanceTimersByTimeAsync(70);
      const concurrent = await processWebhookDelivery(
        store,
        metadata,
        async () => {},
        { token: "competing-claim", leaseMs: 90, heartbeatMs: 20 }
      );
      expect(concurrent).toBe("busy");
      release();
      await expect(first).resolves.toBe("processed");
    } finally {
      vi.useRealTimers();
    }
  });
});

describe("repository authorization entry points", () => {
  it("requires a live selected grant for student views, push events, polling, and commit enqueue", () => {
    const root = process.cwd();
    const assessment = readFileSync(
      resolve(root, "server/features/assessment.ts"),
      "utf8"
    );
    const worker = readFileSync(
      resolve(root, "server/features/assessmentWorker.ts"),
      "utf8"
    );
    const webhook = readFileSync(
      resolve(root, "server/features/httpRoutes.ts"),
      "utf8"
    );
    expect(assessment).toContain("eq(githubRepositories.authorized, true)");
    expect(assessment).toMatch(
      /await repositoryForOwner\(\s*input\.ownerId,\s*input\.repository\.id\s*\)/
    );
    expect(worker).toContain("eq(githubRepositories.authorized, true)");
    expect(worker).toMatch(
      /inArray\(\s*githubRepositories\.watcherStatus,\s*\["active",\s*"failed"\]\s*\)/
    );
    expect(worker).toMatch(
      /const authorizedRepository = await repositoryForOwner\(\s*item\.ownerId,\s*item\.repositoryId\s*\)/
    );
    expect(webhook).toContain("eq(githubRepositories.authorized, true)");
  });
});

describe("declared browser routes", () => {
  it("keeps App routes exactly synchronized with the public route manifest and has a not-found fallback", () => {
    const root = process.cwd();
    const app = readFileSync(resolve(root, "client/src/App.tsx"), "utf8");
    const manifest = JSON.parse(
      readFileSync(resolve(root, "client/public/manus-routes.json"), "utf8")
    ) as { routes: { path: string }[] };
    const appRoutes = [...app.matchAll(/<Route\s+path="([^"]+)"/g)].map(
      match => match[1]
    );
    expect(appRoutes).toEqual(manifest.routes.map(route => route.path));
    expect(app).toContain('mode="not-found"');
    expect(app).not.toMatch(/<Route\s+path="\*"/);
  });
});
