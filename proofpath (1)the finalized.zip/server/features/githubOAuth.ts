import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import type { Express, Request, Response } from "express";
import { parse as parseCookieHeader } from "cookie";
import { and, eq } from "drizzle-orm";
import { githubConnections, githubOAuthStates } from "../../drizzle/schema";
import { getDb } from "../db";
import { sdk } from "../_core/sdk";
import { authenticateRequestOrNull } from "./httpAuth";
import { encryptText, sha256Hex } from "./crypto";
import { githubConfigurationMissing, syncAuthorizedRepositories } from "./githubApi";

const STATE_COOKIE = "__Host-proofpath-github-state";
const REDIRECT_AFTER = "/student/setup?github=connected";
const REDIRECT_ERROR = "/student/setup?github_error=authorization_failed";

function getQuery(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function callbackUrl(): string {
  const value = process.env.GITHUB_CALLBACK_URL?.trim();
  if (!value) throw new Error("GitHub callback URL is not configured.");
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || url.pathname !== "/api/github/callback") {
    throw new Error("GitHub callback URL must be an exact HTTPS /api/github/callback URL.");
  }
  return url.toString();
}

function equalSecret(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  return left.length === right.length && timingSafeEqual(left, right);
}

async function exchangeCode(code: string, verifier: string) {
  const clientId = process.env.GITHUB_APP_CLIENT_ID?.trim();
  const clientSecret = process.env.GITHUB_APP_CLIENT_SECRET?.trim();
  if (!clientId || !clientSecret) throw new Error("GitHub OAuth is not configured.");
  const response = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, code, redirect_uri: callbackUrl(), code_verifier: verifier }),
    signal: AbortSignal.timeout(15_000),
  });
  const body = await response.json().catch(() => ({})) as {
    access_token?: string;
    refresh_token?: string;
    expires_in?: number;
    refresh_token_expires_in?: number;
    error?: string;
  };
  if (!response.ok || body.error || !body.access_token || !body.refresh_token) {
    throw new Error("GitHub authorization exchange failed.");
  }
  return body;
}

export function registerGithubOAuthRoutes(app: Express) {
  app.get("/api/github/connect", async (req: Request, res: Response) => {
    try {
      const user = await authenticateRequestOrNull(req);
      if (!user) {
        res.redirect(302, "/login");
        return;
      }
      const missing = githubConfigurationMissing(false);
      if (missing.length) {
        res.status(503).set("Cache-Control", "no-store").json({
          error: "GitHub App configuration is incomplete.",
          missing,
          callbackPath: "/api/github/callback",
        });
        return;
      }
      const redirectUri = callbackUrl();
      const clientId = process.env.GITHUB_APP_CLIENT_ID!.trim();
      const state = randomBytes(32).toString("base64url");
      const verifier = randomBytes(32).toString("base64url");
      const challenge = createHash("sha256").update(verifier).digest("base64url");
      const db = await getDb();
      if (!db) throw new Error("Database is unavailable.");
      await db.insert(githubOAuthStates).values({
        stateHash: sha256Hex(state),
        ownerId: user.id,
        encryptedVerifier: encryptText(verifier, "github-oauth-pkce"),
        expiresAt: new Date(Date.now() + 10 * 60_000),
      });
      res.cookie(STATE_COOKIE, state, {
        httpOnly: true,
        secure: true,
        sameSite: "none",
        path: "/",
        maxAge: 10 * 60_000,
      });
      const authorize = new URL("https://github.com/login/oauth/authorize");
      authorize.searchParams.set("client_id", clientId);
      authorize.searchParams.set("redirect_uri", redirectUri);
      authorize.searchParams.set("state", state);
      authorize.searchParams.set("code_challenge", challenge);
      authorize.searchParams.set("code_challenge_method", "S256");
      authorize.searchParams.set("allow_signup", "false");
      res.redirect(302, authorize.toString());
    } catch (error) {
      console.warn("[GitHub OAuth] Start failed:", error instanceof Error ? error.message : "unknown error");
      if (!res.headersSent) res.status(503).set("Cache-Control", "no-store").json({ error: "GitHub authorization could not be started. Check the GitHub App setup and try again." });
    }
  });

  app.get("/api/github/callback", async (req: Request, res: Response) => {
    const code = getQuery(req, "code");
    const state = getQuery(req, "state");
    const cookieState = parseCookieHeader(req.headers.cookie ?? "")[STATE_COOKIE];
    if (!code || !state || !cookieState || !equalSecret(state, cookieState)) {
      res.clearCookie(STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });
      res.status(403).set("Cache-Control", "no-store").send("GitHub authorization state is invalid. Return to ProofPath and try again.");
      return;
    }
    res.clearCookie(STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });
    try {
      const user = await authenticateRequestOrNull(req);
      if (!user) {
        res.redirect(302, "/login?next=%2Fstudent%2Fsetup");
        return;
      }
      const db = await getDb();
      if (!db) throw new Error("Database is unavailable.");
      const hash = sha256Hex(state);
      const [stored] = await db.select().from(githubOAuthStates)
        .where(and(eq(githubOAuthStates.stateHash, hash), eq(githubOAuthStates.ownerId, user.id))).limit(1);
      if (!stored || stored.expiresAt.getTime() <= Date.now()) {
        res.status(403).set("Cache-Control", "no-store").send("GitHub authorization expired. Return to ProofPath and try again.");
        return;
      }
      await db.delete(githubOAuthStates).where(eq(githubOAuthStates.stateHash, hash));
      const verifier = (await import("./crypto")).decryptText(stored.encryptedVerifier, "github-oauth-pkce");
      const token = await exchangeCode(code, verifier);
      const profileResponse = await fetch("https://api.github.com/user", {
        headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${token.access_token!}`, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "ProofPath" },
        signal: AbortSignal.timeout(15_000),
      });
      if (!profileResponse.ok) throw new Error("GitHub account lookup failed.");
      const profile = await profileResponse.json() as { id?: number; login?: string };
      if (!profile.id || !profile.login) throw new Error("GitHub account identity was unavailable.");
      const values = {
        ownerId: user.id,
        githubUserId: profile.id,
        login: profile.login,
        encryptedAccessToken: encryptText(token.access_token!, "github-access-token"),
        encryptedRefreshToken: encryptText(token.refresh_token!, "github-refresh-token"),
        accessTokenExpiresAt: new Date(Date.now() + Math.max(60, token.expires_in ?? 28_800) * 1000),
        refreshTokenExpiresAt: new Date(Date.now() + Math.max(60, token.refresh_token_expires_in ?? 15_552_000) * 1000),
        status: "connected" as const,
        lastCheckedAt: new Date(),
      };
      await db.insert(githubConnections).values(values).onDuplicateKeyUpdate({
        set: {
          encryptedAccessToken: values.encryptedAccessToken,
          encryptedRefreshToken: values.encryptedRefreshToken,
          accessTokenExpiresAt: values.accessTokenExpiresAt,
          refreshTokenExpiresAt: values.refreshTokenExpiresAt,
          login: values.login,
          status: "connected",
          lastCheckedAt: new Date(),
        },
      });
      try {
        await syncAuthorizedRepositories(user.id);
      } catch (syncError) {
        console.warn("[GitHub OAuth] Repository grant refresh deferred:", syncError instanceof Error ? syncError.message : "unknown error");
      }
      res.redirect(302, REDIRECT_AFTER);
    } catch (error) {
      console.warn("[GitHub OAuth] Callback failed:", error instanceof Error ? error.message : "unknown error");
      res.redirect(302, REDIRECT_ERROR);
    }
  });
}
