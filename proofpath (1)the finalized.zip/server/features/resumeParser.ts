import mammoth from "mammoth";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

export const PDF_MIME = "application/pdf" as const;
export const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document" as const;
export const MAX_RESUME_BYTES = 5 * 1024 * 1024;
const MAX_PDF_PAGES = 40;
const MAX_EXTRACTED_CHARS = 120_000;

export type ResumeMime = typeof PDF_MIME | typeof DOCX_MIME;

export function validateResumeFile(bytes: Buffer, mimeType: string, fileName: string): asserts mimeType is ResumeMime {
  if (bytes.length < 16 || bytes.length > MAX_RESUME_BYTES) {
    throw new Error("Resume file must be between 16 bytes and 5 MiB (5,242,880 bytes).");
  }
  const extension = fileName.toLowerCase().split(".").pop();
  if (mimeType === PDF_MIME) {
    if (extension !== "pdf" || !bytes.subarray(0, 1024).includes(Buffer.from("%PDF-"))) {
      throw new Error("The selected file is not a readable PDF. Choose a valid .pdf file.");
    }
    return;
  }
  if (mimeType === DOCX_MIME) {
    if (extension !== "docx" || bytes.subarray(0, 4).toString("binary") !== "PK\u0003\u0004") {
      throw new Error("The selected file is not a readable DOCX. Choose a valid .docx file.");
    }
    return;
  }
  throw new Error("Unsupported resume format. Upload a PDF or DOCX file.");
}

function normalizeExtractedText(value: string): string {
  return value
    .replace(/\u0000/g, " ")
    .replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim()
    .slice(0, MAX_EXTRACTED_CHARS);
}

async function readPdf(bytes: Buffer): Promise<string> {
  let loading: ReturnType<typeof getDocument> | undefined;
  try {
    loading = getDocument({
      data: new Uint8Array(bytes),
      disableAutoFetch: true,
      disableFontFace: true,
      useSystemFonts: false,
      stopAtErrors: true,
    });
    const document = await loading.promise;
    if (document.numPages < 1 || document.numPages > MAX_PDF_PAGES) {
      throw new Error(`PDFs must contain between 1 and ${MAX_PDF_PAGES} pages.`);
    }
    const pageTexts: string[] = [];
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent({ includeMarkedContent: false });
      const text = content.items.map(item => "str" in item ? item.str : "").join(" ");
      pageTexts.push(text);
      page.cleanup();
      if (pageTexts.join("\n").length >= MAX_EXTRACTED_CHARS) break;
    }
    await document.cleanup();
    return pageTexts.join("\n");
  } catch (error) {
    if (error instanceof Error && /between 1 and/.test(error.message)) throw error;
    throw new Error("The PDF is corrupted, encrypted, or unreadable. Try exporting a text-readable PDF.");
  } finally {
    await loading?.destroy().catch(() => undefined);
  }
}

async function readDocx(bytes: Buffer): Promise<string> {
  try {
    const result = await mammoth.extractRawText({ buffer: bytes });
    return result.value;
  } catch {
    throw new Error("The DOCX is corrupted or unreadable. Re-save it as a standard Word document and try again.");
  }
}

export async function extractResumeText(bytes: Buffer, mimeType: ResumeMime, fileName: string): Promise<string> {
  validateResumeFile(bytes, mimeType, fileName);
  const extracted = mimeType === PDF_MIME ? await readPdf(bytes) : await readDocx(bytes);
  const text = normalizeExtractedText(extracted);
  if (text.length < 80) {
    throw new Error("The file contains too little readable text. Use a text-readable PDF or DOCX.");
  }
  return text;
}
