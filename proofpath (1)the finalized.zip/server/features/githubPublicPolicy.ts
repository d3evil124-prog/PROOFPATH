export type ParsedPublicRepositoryUrl = {
  owner: string;
  repository: string;
};

export function parsePublicRepositoryUrl(value: string): ParsedPublicRepositoryUrl {
  let url: URL;
  try {
    url = new URL(value.trim());
  } catch {
    throw new Error("Enter a valid GitHub repository URL, such as https://github.com/owner/repository.");
  }
  if (
    url.protocol !== "https:" ||
    url.hostname.toLowerCase() !== "github.com" ||
    url.username ||
    url.password ||
    (url.port && url.port !== "443") ||
    url.search ||
    url.hash
  ) {
    throw new Error("Use the canonical HTTPS github.com repository link only.");
  }
  const segments = url.pathname.split("/").filter(Boolean);
  if (segments.length !== 2) {
    throw new Error("Paste a repository link, not a branch, file, organization page or GitHub login page.");
  }
  const owner = decodeURIComponent(segments[0]);
  const repository = decodeURIComponent(segments[1].replace(/\.git$/i, ""));
  if (
    !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37})$/.test(owner) ||
    !/^[A-Za-z0-9_.-]{1,100}$/.test(repository) ||
    repository === "." ||
    repository === ".."
  ) {
    throw new Error("The GitHub owner or repository name is invalid.");
  }
  return { owner, repository };
}

export function isVerifiedPublicRepository(value: {
  id: number;
  private: boolean;
  full_name: string;
  default_branch: string;
  owner?: { login?: string };
}): boolean {
  return (
    Number.isSafeInteger(value.id) &&
    value.id > 0 &&
    value.private === false &&
    Boolean(value.full_name && value.owner?.login && value.default_branch)
  );
}
