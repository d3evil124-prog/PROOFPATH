import { createHmac } from "node:crypto";
import type { Request } from "express";
import { afterEach, describe, expect, it } from "vitest";
import { decryptText, encryptText, verifyGithubSignature } from "./crypto";
import { authenticateRequestOrNull } from "./httpAuth";
import { fetchJobPosting, htmlToReadableText } from "./safeJobFetch";
import { canUseRepositoryGrant, githubConfigurationMissing } from "./githubApi";
import { isVerifiedPublicRepository, parsePublicRepositoryUrl } from "./githubPublicPolicy";
import { DOCX_MIME, extractResumeText, PDF_MIME, validateResumeFile } from "./resumeParser";

const priorKey = process.env.MANUS_JWT_SECRET;
const githubKeys = ["GITHUB_APP_CLIENT_ID", "GITHUB_APP_CLIENT_SECRET", "GITHUB_APP_SLUG", "GITHUB_CALLBACK_URL", "GITHUB_WEBHOOK_SECRET"] as const;
const priorGithubValues = githubKeys.map(key => process.env[key]);
afterEach(() => {
  if (priorKey === undefined) delete process.env.MANUS_JWT_SECRET;
  else process.env.MANUS_JWT_SECRET = priorKey;
  githubKeys.forEach((key, index) => {
    const value = priorGithubValues[index];
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  });
});

describe("ProofPath security primitives", () => {
  it("encrypts and decrypts sensitive values with authenticated encryption", () => {
    process.env.MANUS_JWT_SECRET = "test-only-secret-with-at-least-thirty-two-characters";
    const encrypted = encryptText("private-token-value", "test-token");
    expect(encrypted).not.toContain("private-token-value");
    expect(decryptText(encrypted, "test-token")).toBe("private-token-value");
    expect(() => decryptText(encrypted, "different-purpose")).toThrow();
  });

  it("uses the managed server secret without requiring a user-generated encryption key", () => {
    process.env.MANUS_JWT_SECRET = "0123456789abcdef";
    const encrypted = encryptText("private resume passage", "resume-chunk");
    expect(decryptText(encrypted, "resume-chunk")).toBe("private resume passage");
    process.env.MANUS_JWT_SECRET = "too-short";
    expect(() => encryptText("private resume passage", "resume-chunk")).toThrow(/managed session secret/i);
  });

  it("accepts only the exact HMAC-SHA256 signature for the raw webhook bytes", () => {
    const raw = Buffer.from('{"after":"abc"}', "utf8");
    const signature = `sha256=${createHmac("sha256", "unit-test-webhook-secret").update(raw).digest("hex")}`;
    expect(verifyGithubSignature(raw, signature, "unit-test-webhook-secret")).toBe(true);
    expect(verifyGithubSignature(Buffer.from('{"after":"def"}'), signature, "unit-test-webhook-secret")).toBe(false);
    expect(verifyGithubSignature(raw, undefined, "unit-test-webhook-secret")).toBe(false);
  });

  it("reports missing GitHub configuration rather than enabling a fake connection", () => {
    githubKeys.forEach(key => delete process.env[key]);
    expect(githubConfigurationMissing()).toEqual(githubKeys.slice(0, 4));
    expect(githubConfigurationMissing(true)).toEqual([...githubKeys.slice(0, 4), "GITHUB_WEBHOOK_SECRET"]);
  });
});

describe("HTTP session boundaries", () => {
  it("treats a missing session cookie as an anonymous request", async () => {
    const request = { path: "/api/resumes/upload", headers: {} } as unknown as Request;
    await expect(authenticateRequestOrNull(request)).resolves.toBeNull();
  });
});

describe("GitHub repository grant authorization", () => {
  it("allows branch listing before selection but requires a live selected grant for assessment", () => {
    const granted = { ownerId: 41, authorized: true, selected: false };
    expect(canUseRepositoryGrant(granted, 41)).toBe(true);
    expect(canUseRepositoryGrant(granted, 41, true)).toBe(false);
    expect(canUseRepositoryGrant({ ...granted, selected: true }, 41, true)).toBe(true);
  });

  it("rejects revoked grants and grants belonging to a different account", () => {
    expect(canUseRepositoryGrant({ ownerId: 41, authorized: false, selected: true }, 41)).toBe(false);
    expect(canUseRepositoryGrant({ ownerId: 42, authorized: true, selected: true }, 41, true)).toBe(false);
  });
});

describe("public GitHub link verification", () => {
  it("accepts only canonical repository URLs and removes an optional .git suffix", () => {
    expect(parsePublicRepositoryUrl("https://github.com/example/project.git")).toEqual({ owner: "example", repository: "project" });
    expect(() => parsePublicRepositoryUrl("https://github.com/example/project/tree/main")).toThrow(/branch, file/i);
    expect(() => parsePublicRepositoryUrl("https://github.com.evil.invalid/example/project")).toThrow(/canonical HTTPS/i);
    expect(() => parsePublicRepositoryUrl("http://github.com/example/project")).toThrow(/canonical HTTPS/i);
  });

  it("requires GitHub metadata to explicitly identify a public repository", () => {
    expect(isVerifiedPublicRepository({ id: 7, private: false, full_name: "a/b", default_branch: "main", owner: { login: "a" } })).toBe(true);
    expect(isVerifiedPublicRepository({ id: 7, private: true, full_name: "a/b", default_branch: "main", owner: { login: "a" } })).toBe(false);
  });
});

describe("job source safety", () => {
  it("extracts readable page text while removing executable and navigation blocks", () => {
    const result = htmlToReadableText("<html><head><title>Engineer &amp; Analyst</title></head><body><script>exfiltrate()</script><nav>Menu</nav><h1>Backend Engineer</h1><p>Build APIs and services.</p></body></html>");
    expect(result.title).toBe("Engineer & Analyst");
    expect(result.text).toContain("Backend Engineer");
    expect(result.text).toContain("Build APIs and services.");
    expect(result.text).not.toContain("exfiltrate");
    expect(result.text).not.toContain("Menu");
  });

  it("rejects loopback, non-HTTP and non-standard-port sources before network access", async () => {
    await expect(fetchJobPosting("http://127.0.0.1/private")).rejects.toThrow(/publicly reachable/i);
    await expect(fetchJobPosting("file:///etc/passwd")).rejects.toThrow(/HTTP\(S\)/i);
    await expect(fetchJobPosting("https://example.org:8443/jobs")).rejects.toThrow(/standard ports/i);
    await expect(fetchJobPosting("http://example.org:443/jobs")).rejects.toThrow(/standard ports/i);
    await expect(fetchJobPosting("https://user:pass@example.org/jobs")).rejects.toThrow(/HTTP\(S\)/i);
  });
});

describe("resume file validation", () => {
  it("rejects incorrect signatures, extensions and unsupported formats", () => {
    const bytes = Buffer.from(`%PDF-${"x".repeat(40)}`);
    expect(() => validateResumeFile(bytes, PDF_MIME, "resume.pdf")).not.toThrow();
    expect(() => validateResumeFile(bytes, PDF_MIME, "resume.docx")).toThrow(/readable PDF/i);
    expect(() => validateResumeFile(Buffer.alloc(40, 0x41), PDF_MIME, "resume.pdf")).toThrow(/readable PDF/i);
    expect(() => validateResumeFile(bytes, "text/plain", "resume.txt")).toThrow(/unsupported/i);
  });

  it("returns a clear error for a corrupted PDF instead of treating it as parsed content", async () => {
    const bytes = Buffer.from(`%PDF-1.4\n${"not a real PDF object ".repeat(20)}`);
    await expect(extractResumeText(bytes, PDF_MIME, "resume.pdf")).rejects.toThrow(/corrupted|unreadable/i);
  });

  it("returns a clear error for a corrupted DOCX package", async () => {
    const bytes = Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(64)]);
    await expect(extractResumeText(bytes, DOCX_MIME, "resume.docx")).rejects.toThrow(/corrupted|unreadable|too little/i);
  });
});
