import { and, desc, eq } from "drizzle-orm";
import {
  assessmentVersions,
  changeEvents,
  resumes,
  userProfiles,
} from "../../drizzle/schema";
import { getDb } from "../db";

export type ProfileInput = {
  displayName: string | null;
  headline: string | null;
  targetRole: string | null;
  location: string | null;
  bio: string | null;
  websiteUrl: string | null;
  linkedinUrl: string | null;
  githubUrl: string | null;
  resumeContextEnabled: boolean;
};

export type ProfileValues = ProfileInput & { updatedAt: Date | null };

export type ProfileHistoryItem = {
  id: string;
  kind: "resume" | "assessment" | "commit";
  title: string;
  detail: string;
  occurredAt: Date;
};

export async function getProfile(ownerId: number): Promise<ProfileValues> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [row] = await db
    .select()
    .from(userProfiles)
    .where(eq(userProfiles.ownerId, ownerId))
    .limit(1);
  return {
    displayName: row?.displayName ?? null,
    headline: row?.headline ?? null,
    targetRole: row?.targetRole ?? null,
    location: row?.location ?? null,
    bio: row?.bio ?? null,
    websiteUrl: row?.websiteUrl ?? null,
    linkedinUrl: row?.linkedinUrl ?? null,
    githubUrl: row?.githubUrl ?? null,
    resumeContextEnabled: row?.resumeContextEnabled ?? true,
    updatedAt: row?.updatedAt ?? null,
  };
}

export async function updateProfile(
  ownerId: number,
  input: ProfileInput,
): Promise<ProfileValues> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [existing] = await db
    .select({ id: userProfiles.id })
    .from(userProfiles)
    .where(eq(userProfiles.ownerId, ownerId))
    .limit(1);
  if (existing) {
    await db
      .update(userProfiles)
      .set(input)
      .where(and(eq(userProfiles.ownerId, ownerId), eq(userProfiles.id, existing.id)));
  } else {
    await db.insert(userProfiles).values({ ownerId, ...input });
  }
  return getProfile(ownerId);
}

export async function getProfileHistory(
  ownerId: number,
): Promise<ProfileHistoryItem[]> {
  const db = await getDb();
  if (!db) throw new Error("The database is unavailable.");
  const [resumeRows, assessmentRows, commitRows] = await Promise.all([
    db
      .select({ id: resumes.id, name: resumes.originalName, at: resumes.uploadedAt })
      .from(resumes)
      .where(eq(resumes.ownerId, ownerId))
      .orderBy(desc(resumes.uploadedAt))
      .limit(15),
    db
      .select({ id: assessmentVersions.id, state: assessmentVersions.state, sha: assessmentVersions.commitSha, at: assessmentVersions.createdAt })
      .from(assessmentVersions)
      .where(eq(assessmentVersions.ownerId, ownerId))
      .orderBy(desc(assessmentVersions.createdAt))
      .limit(20),
    db
      .select({ id: changeEvents.id, state: changeEvents.processingState, sha: changeEvents.commitSha, branch: changeEvents.branch, at: changeEvents.createdAt })
      .from(changeEvents)
      .where(eq(changeEvents.ownerId, ownerId))
      .orderBy(desc(changeEvents.createdAt))
      .limit(20),
  ]);
  return [
    ...resumeRows.map(row => ({
      id: `resume-${row.id}`,
      kind: "resume" as const,
      title: "Resume uploaded",
      detail: row.name,
      occurredAt: row.at,
    })),
    ...assessmentRows.map(row => ({
      id: `assessment-${row.id}`,
      kind: "assessment" as const,
      title: `Assessment ${row.state}`,
      detail: `Commit ${row.sha.slice(0, 7)}`,
      occurredAt: row.at,
    })),
    ...commitRows.map(row => ({
      id: `commit-${row.id}`,
      kind: "commit" as const,
      title: `Commit ${row.state}`,
      detail: `${row.sha.slice(0, 7)} · ${row.branch}`,
      occurredAt: row.at,
    })),
  ]
    .sort((left, right) => right.occurredAt.getTime() - left.occurredAt.getTime())
    .slice(0, 30);
}
