import { createHmac } from "node:crypto";
import express from "express";
import { afterEach, describe, expect, it } from "vitest";
import { MAX_RESUME_BYTES } from "./resumeParser";
import { registerProofPathHttpRoutes } from "./httpRoutes";

const originalWebhookSecret = process.env.GITHUB_WEBHOOK_SECRET;
let server: ReturnType<ReturnType<typeof express>['listen']> | undefined;

afterEach(async () => {
  if (server?.listening) await new Promise<void>((resolve, reject) => server!.close(error => error ? reject(error) : resolve()));
  server = undefined;
  if (originalWebhookSecret === undefined) delete process.env.GITHUB_WEBHOOK_SECRET;
  else process.env.GITHUB_WEBHOOK_SECRET = originalWebhookSecret;
});

async function startApp() {
  const app = express();
  registerProofPathHttpRoutes(app);
  server = app.listen(0, "127.0.0.1");
  await new Promise<void>(resolve => server!.once("listening", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Test HTTP server did not bind a TCP port.");
  return `http://127.0.0.1:${address.port}`;
}

describe("raw ProofPath HTTP boundaries", () => {
  it("returns structured HTTP 413 with no-store when the resume body exceeds the exact limit", async () => {
    const base = await startApp();
    const response = await fetch(`${base}/api/resumes/upload`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: new Uint8Array(MAX_RESUME_BYTES + 1),
    });
    expect(response.status).toBe(413);
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(await response.json()).toEqual({ error: "Resume uploads cannot exceed 5 MiB (5,242,880 bytes)." });
  });

  it("acknowledges unsupported signed webhook pairs as ignored before any database lookup", async () => {
    process.env.GITHUB_WEBHOOK_SECRET = "unit-test-webhook-secret";
    const base = await startApp();
    const body = Buffer.from(JSON.stringify({ action: "opened" }));
    const signature = `sha256=${createHmac("sha256", process.env.GITHUB_WEBHOOK_SECRET).update(body).digest("hex")}`;
    const response = await fetch(`${base}/api/github/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-GitHub-Event": "issues",
        "X-GitHub-Delivery": "0123456789abcdef0123456789abcdef",
        "X-Hub-Signature-256": signature,
      },
      body: new Uint8Array(body),
    });
    expect(response.status).toBe(202);
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(await response.json()).toEqual({ accepted: true, ignored: true });
  });
});
