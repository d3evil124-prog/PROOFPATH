import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createJobFromSource, confirmExtractedJob, getJob, listJobs, reviewJob } from "./features/jobs";
import { getAssessmentHistory, getLatestAssessment, getStudentOverview, queueAssessment, getConnectionSummary } from "./features/assessment";
import { addPublicRepositoryLink, addTokenRepository, githubConfigurationMissing, githubInstallUrl, githubTokenConfigured, listBranches, listTokenRepositories, pauseRepository, selectAuthorizedRepository, syncAuthorizedRepositories } from "./features/githubApi";
import { compareResumeVersions, latestResume, listResumes, removeResume } from "./features/resumeService";
import { getProfile, getProfileHistory, updateProfile } from "./features/profileService";
import { getDb } from "./db";
import { githubRepositories, resumes } from "../drizzle/schema";
import { and, eq } from "drizzle-orm";

function asTrpcError(error: unknown): never {
  if (error instanceof TRPCError) throw error;
  const message = error instanceof Error ? error.message : "The operation could not be completed.";
  const safe = message.slice(0, 800);
  const inputFailure = /enter |provide |paste |unsupported|not a readable|corrupted|unreadable|too little|requirement|confirmed|not found|select an authorized|branch is not|public HTTP|repository URL|owner or repository|repository, branch/i.test(safe);
  throw new TRPCError({ code: inputFailure ? "BAD_REQUEST" : "INTERNAL_SERVER_ERROR", message: safe });
}

const idInput = z.object({ id: z.number().int().positive() });
const jobIdInput = z.object({ jobId: z.number().int().positive() });
const repositoryIdInput = z.object({ repositoryId: z.number().int().positive() });
const assessmentPairInput = z.object({ jobId: z.number().int().positive(), repositoryId: z.number().int().positive() });
const requirementInput = z.object({
  originalWording: z.string().trim().min(8).max(1000),
  skill: z.string().trim().min(1).max(160),
  priority: z.enum(["required", "preferred"]),
});
const reviewInput = z.object({
  jobId: z.number().int().positive(),
  title: z.string().trim().min(1).max(255),
  company: z.string().trim().max(255).nullable(),
  requirements: z.array(requirementInput).min(1).max(25),
});
const optionalHttpsUrl = z.string().trim().max(2048).url("Enter a valid URL.")
  .refine(value => { try { return new URL(value).protocol === "https:"; } catch { return false; } }, "Use an HTTPS link.").nullable();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  proofpath: router({
    dashboard: protectedProcedure.query(({ ctx }) => getStudentOverview(ctx.user.id).catch(asTrpcError)),
    jobs: router({
      list: protectedProcedure.query(({ ctx }) => listJobs(ctx.user.id).catch(asTrpcError)),
      get: protectedProcedure.input(idInput).query(({ ctx, input }) => getJob(ctx.user.id, input.id).then(value => {
        if (!value) throw new TRPCError({ code: "NOT_FOUND", message: "Job posting not found." });
        return value;
      }).catch(asTrpcError)),
      import: protectedProcedure.input(z.object({
        url: z.string().trim().max(2048).optional(),
        description: z.string().trim().max(60_000).optional(),
      })).mutation(({ ctx, input }) => createJobFromSource(ctx.user.id, input).catch(asTrpcError)),
      review: protectedProcedure.input(reviewInput).mutation(({ ctx, input }) => reviewJob(ctx.user.id, input.jobId, input).catch(asTrpcError)),
      confirm: protectedProcedure.input(jobIdInput).mutation(({ ctx, input }) => confirmExtractedJob(ctx.user.id, input.jobId).catch(asTrpcError)),
    }),
    resume: router({
      latest: protectedProcedure.query(({ ctx }) => latestResume(ctx.user.id).catch(asTrpcError)),
      list: protectedProcedure.query(({ ctx }) => listResumes(ctx.user.id).catch(asTrpcError)),
      compare: protectedProcedure.input(z.object({ firstResumeId: z.number().int().positive(), secondResumeId: z.number().int().positive(), jobId: z.number().int().positive() }))
        .query(({ ctx, input }) => compareResumeVersions(ctx.user.id, input.firstResumeId, input.secondResumeId, input.jobId).catch(asTrpcError)),
      remove: protectedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
        const [row] = await db.select({ id: resumes.id }).from(resumes)
          .where(and(eq(resumes.ownerId, ctx.user.id), eq(resumes.id, input.id))).limit(1);
        if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Resume not found." });
        await removeResume(ctx.user.id, input.id).catch(asTrpcError);
        return { success: true } as const;
      }),
    }),
    github: router({
      status: protectedProcedure.query(async ({ ctx }) => {
        try {
          const missing = githubConfigurationMissing(false);
          const tokenConfigured = githubTokenConfigured();
          return {
            configured: missing.length === 0 || tokenConfigured,
            missingConfiguration: tokenConfigured ? [] : missing,
            tokenConfigured,
            installationUrl: githubInstallUrl(),
            ...(await getConnectionSummary(ctx.user.id)),
          };
        } catch (error) { asTrpcError(error); }
      }),
      repositories: protectedProcedure.query(async ({ ctx }) => {
        try {
          const missing = githubConfigurationMissing(false);
          const tokenConfigured = githubTokenConfigured();
          const status = missing.length && !tokenConfigured ? { connected: false } : await getConnectionSummary(ctx.user.id);
          const appRepositories = status.connected ? await syncAuthorizedRepositories(ctx.user.id) : [];
          const tokenRepositories = tokenConfigured ? await listTokenRepositories(ctx.user.id) : [];
          const db = await getDb();
          if (!db) throw new Error("The database is unavailable.");
          const publicRepositories = await db.select().from(githubRepositories)
            .where(and(eq(githubRepositories.ownerId, ctx.user.id), eq(githubRepositories.accessMode, "public_link"), eq(githubRepositories.authorized, true)));
          const repositories = [...new Map([...appRepositories, ...tokenRepositories, ...publicRepositories].map(repo => [repo.id, repo])).values()];
          return {
            configured: missing.length === 0 || tokenConfigured,
            connected: status.connected,
            missingConfiguration: tokenConfigured ? [] : missing,
            tokenConfigured,
            installationUrl: githubInstallUrl(),
            repositories: repositories.map(repo => ({
              id: repo.id,
              owner: repo.repositoryOwner,
              name: repo.repositoryName,
              fullName: `${repo.repositoryOwner}/${repo.repositoryName}`,
              private: repo.isPrivate,
              defaultBranch: repo.defaultBranch,
              selected: repo.selected,
              branch: repo.branch,
              watcherStatus: repo.watcherStatus,
              lastSyncedAt: repo.lastSyncedAt,
              latestObservedSha: repo.latestObservedSha,
              accessMode: repo.accessMode,
            })),
          };
        } catch (error) { asTrpcError(error); }
      }),
      addPublicLink: protectedProcedure.input(z.object({ url: z.string().trim().min(1).max(2048) }))
        .mutation(({ ctx, input }) => addPublicRepositoryLink(ctx.user.id, input.url).catch(asTrpcError)),
      addTokenRepository: protectedProcedure.input(z.object({ url: z.string().trim().min(1).max(2048) }))
        .mutation(({ ctx, input }) => addTokenRepository(ctx.user.id, input.url).catch(asTrpcError)),
      branches: protectedProcedure.input(repositoryIdInput).query(({ ctx, input }) => listBranches(ctx.user.id, input.repositoryId).catch(asTrpcError)),
      select: protectedProcedure.input(z.object({ repositoryId: z.number().int().positive(), branch: z.string().trim().min(1).max(255).optional() }))
        .mutation(({ ctx, input }) => selectAuthorizedRepository(ctx.user.id, input.repositoryId, input.branch).catch(asTrpcError)),
      pause: protectedProcedure.input(repositoryIdInput).mutation(async ({ ctx, input }) => {
        await pauseRepository(ctx.user.id, input.repositoryId);
        return { success: true } as const;
      }),
    }),
    profile: router({
      current: protectedProcedure.query(({ ctx }) => getProfile(ctx.user.id).catch(asTrpcError)),
      history: protectedProcedure.query(({ ctx }) => getProfileHistory(ctx.user.id).catch(asTrpcError)),
      update: protectedProcedure.input(z.object({
        displayName: z.string().trim().max(120).nullable(),
        headline: z.string().trim().max(160).nullable(),
        targetRole: z.string().trim().max(160).nullable(),
        location: z.string().trim().max(120).nullable(),
        bio: z.string().trim().max(1000).nullable(),
        websiteUrl: optionalHttpsUrl,
        linkedinUrl: optionalHttpsUrl,
        githubUrl: optionalHttpsUrl,
        resumeContextEnabled: z.boolean(),
      })).mutation(({ ctx, input }) => updateProfile(ctx.user.id, input).catch(asTrpcError)),
    }),
    assessment: router({
      start: protectedProcedure.input(assessmentPairInput).mutation(({ ctx, input }) => queueAssessment(ctx.user.id, input.jobId, input.repositoryId).catch(asTrpcError)),
      latest: protectedProcedure.input(assessmentPairInput).query(({ ctx, input }) => getLatestAssessment(ctx.user.id, input.jobId, input.repositoryId).catch(asTrpcError)),
      history: protectedProcedure.input(assessmentPairInput).query(({ ctx, input }) => getAssessmentHistory(ctx.user.id, input.jobId, input.repositoryId).catch(asTrpcError)),
    }),
  }),
});

export type AppRouter = typeof appRouter;
