import type { Request } from "express";
import { HttpError } from "@shared/_core/errors";
import { sdk, type AuthenticatedUser } from "../_core/sdk";

/**
 * Resolve the current Manus user for cookie-based HTTP handlers. A missing or
 * invalid session is an ordinary anonymous request; database/OAuth failures
 * still propagate as server errors rather than being disguised as 401s.
 */
export async function authenticateRequestOrNull(req: Request): Promise<AuthenticatedUser | null> {
  try {
    return await sdk.authenticateRequest(req);
  } catch (error) {
    if (error instanceof HttpError && error.statusCode === 403 && error.message === "Invalid session cookie") {
      return null;
    }
    throw error;
  }
}
