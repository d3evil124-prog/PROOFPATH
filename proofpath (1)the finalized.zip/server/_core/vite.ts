import fs from "node:fs";
import path from "node:path";
import type { Express } from "express";
import express from "express";
import type { Server } from "node:http";
import { createServer as createViteServer, type ViteDevServer } from "vite";

const root = process.cwd();
const clientRoot = path.resolve(root, "client");
const distRoot = path.resolve(root, "dist/public");

export async function setupVite(app: Express, server: Server) {
  const vite: ViteDevServer = await createViteServer({
    root: clientRoot,
    configFile: path.resolve(root, "vite.config.ts"),
    server: { middlewareMode: true, hmr: { server }, host: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    if (req.originalUrl.startsWith("/api/")) return next();
    try {
      const template = fs.readFileSync(path.resolve(clientRoot, "index.html"), "utf8");
      const html = await vite.transformIndexHtml(req.originalUrl, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(html);
    } catch (error) {
      vite.ssrFixStacktrace(error as Error);
      next(error);
    }
  });
}

export function serveStatic(app: Express) {
  app.use(express.static(distRoot));
  app.get("*", (req, res, next) => {
    if (req.originalUrl.startsWith("/api/")) return next();
    res.sendFile(path.resolve(distRoot, "index.html"));
  });
}
